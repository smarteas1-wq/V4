# SNIPRR V10.6 ULTRA - Déploiement RENDER GRATUIT 24/7

## Wallet
`2Z779hHJDMKnKbpMcw2mzq6Z9RMoHrLQX1BNN9PLQvjh` - Solde actuel 0 SOL (à financer 0.14 SOL = 20€)

## Étapes 2 minutes

### 1. Pousse sur GitHub (1min)
1. Va sur https://github.com/new -> crée repo `snipprr-bot` (Private)
2. Dans ton terminal local ou ici :
```bash
cd snipprr-bot
git init
git add backend/ frontend/
git commit -m "V10.6 ULTRA"
git branch -M main
git remote add origin https://github.com/TON_PSEUDO/snipprr-bot.git
git push -u origin main
```

### 2. Render - 1 clic
1. Va sur https://dashboard.render.com/register (gratuit, pas de CB)
2. `New +` -> `Web Service` -> Connecte ton repo `snipprr-bot`
3. Config :
   - **Root Directory:** `backend`
   - **Build Command:** `npm install`
   - **Start Command:** `node server.js`
   - **Plan:** `Free`
   - **Region:** `Frankfurt` (plus proche de Paris)
4. Clique `Create Web Service` -> Attends 2min -> tu as `https://snipprr-v10-6.onrender.com`

### 3. UptimeRobot - Anti-dodo (30s)
Sans ça Render s'endort après 15min.
1. https://uptimerobot.com/ -> gratuit
2. `Add New Monitor` -> `HTTP(s)` -> URL: `https://TON_APP.onrender.com/api/status` -> Interval 5min -> Create
3. C'est tout, il ping et reste allumé 24/7

### 4. Connecte ton front
Ton front https://snipprr-2026-v4.surge.sh pointe déjà sur localhost. Après Render, change l'URL API dans `frontend/index.html` :
```js
const API = "https://TON_APP.onrender.com"
```

### Vérification
- `https://TON_APP.onrender.com/api/status` doit renvoyer `{"running":true,...}`
- `https://TON_APP.onrender.com/api/hedge` -> total/balance
- Solscan : https://solscan.io/account/2Z779hHJDMKnKbpMcw2mzq6Z9RMoHrLQX1BNN9PLQvjh

### Notes
- Render Free = 750h/mois = largement 24/7
- Au premier déploiement, Render met ~50s à se réveiller (normal)
- Garde `wallet.json` PRIVÉ - ne le pousse jamais sur GitHub public (mets backend/wallet.json dans .gitignore si repo public)

---
Généré pour V10.6 ULTRA MAX 62 MCP hedge16 4POS 78% 20min
