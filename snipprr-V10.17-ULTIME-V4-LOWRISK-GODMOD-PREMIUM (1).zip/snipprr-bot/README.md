# SNIPRR BOT — Sniper Memecoin Solana Pump.fun | LIVE H24

**Router Backend API + Pluging Front-End complet** — Trade automatique de A à Z : snipe → swap → take-profit → réinvestissement.

> ⚠️ **MODE LIVE RÉEL** : ce bot utilise ton vrai SOL sur mainnet. Tu peux tout perdre en quelques minutes. Memecoins = casino. Aucune garantie de 20€→50 000€. Utilise uniquement une bankroll que tu peux te permettre de perdre.

---

## 🚀 Stack

- **Backend** : Node.js + Express (router `/api/*`)
- **Frontend** : HTML/CSS/JS SPA (pluging direct, pas de build)
- **Blockchain** : `@solana/web3.js` + Jupiter V6 API (swap live)
- **Scanners** : Pump.fun `frontend-api.pump.fun`, DexScreener, Birdeye, X.com API v2
- **H24** : `node-cron` + polling 8s + hébergement Render/Railway gratuit HTTPS

---

## 📂 Architecture

```
snipprr-bot/
├── backend/server.js      # Router Express + Sniper Engine LIVE
├── backend/package.json
├── frontend/index.html    # Dashboard complet plugé au backend
├── .env.example
└── README.md
```

### Routes Backend

| Route | Méthode | Description |
|-------|---------|-------------|
| `/api/status` | GET | Etat bot, balance, config, logs |
| `/api/wallet/create` | POST | Génère wallet auto (Keypair Solana) |
| `/api/wallet/import` | POST | Importe privateKey base58 |
| `/api/config` | POST | Update buyAmount, TP/SL, slippage |
| `/api/bot/start` | POST | Démarre sniper H24 |
| `/api/bot/stop` | POST | Stoppe bot |
| `/api/trades` | GET | Historique trades |
| `/api/positions` | GET | Positions ouvertes |
| `/api/swap` | POST | Swap manuel Jupiter |
| `/api/scanner/pumpfun` | GET | Nouveaux coins Pump.fun |
| `/api/scanner/dexscreener` | GET | Pairs DexScreener |
| `/api/scanner/birdeye` | GET | Trending Birdeye |
| `/api/scanner/xfomo` | GET | FOMO X.com |

---

## ⚡ Démarrage local

```bash
cd backend
npm install
cp ../.env.example .env   # remplis tes clés
npm start
# => http://localhost:3000  (frontend servi automatiquement)
```

Env minimal pour LIVE :
```
SOLANA_RPC=https://api.mainnet-beta.solana.com
# ou mieux gratuit Helius :
HELIUS_RPC=https://mainnet.helius-rpc.com/?api-key=TA_CLE
BIRDEYE_API_KEY=...
X_BEARER_TOKEN=...
PRIVATE_KEY_BASE58= # laisse vide, génère via UI
```

---

## 🌐 Déploiement H24 HTTPS Gratuit (3 min)

### Option 1 — Render.com (recommandé gratuit)
1. Push ce dossier sur GitHub
2. Va sur **render.com** → New + → Web Service → Connect repo
3. Build Command : `cd backend && npm install`
4. Start Command : `node backend/server.js`
5. Ajoute les Variables d'environnement (.env)
6. Deploy → tu obtiens `https://snipprr-xxxx.onrender.com` en HTTPS gratuit
7. Garde le H24 : ajoute l'URL à **UptimeRobot** (ping `/api/status` toutes les 5 min) sinon Render s'endort après 15min en free tier

### Option 2 — Railway / Fly.io
Même principe, `npm start` et variables d'env. Railway donne 500h gratuites/mois + domaine `up.railway.app` HTTPS.

### Option 3 — Vercel (frontend) + Render (backend)
Si tu veux séparer.

---

## 🤖 Stratégie Auto (de A à Z)

1. **Scan** toutes les 8s : `frontend-api.pump.fun/coins?sort=created_timestamp` + DexScreener
2. **Filtre** : MCAP < 80k$, liquidité >5k, FOMO Birdeye/X si activé
3. **Snipe** : `Jupiter V6 quote + swap` → SOL → Token (slippage 10% par défaut pour être inclus vite)
4. **Hold** : poll prix DexScreener
5. **TP/SL** : +80% / -25% → swap inverse Token → SOL via Jupiter
6. **Réinvest** : si `autoReinvest=true`, 50% du profit ajouté au prochain `buyAmountSol`

---

## 🔑 Plugings API à connecter (gratuits)

- **Helius RPC gratuit** : https://helius.dev → crée clé → colle dans `HELIUS_RPC` (100x plus rapide que public RPC)
- **Birdeye** : https://bds.birdeye.so → API Key gratuite (limité) → `BIRDEYE_API_KEY`
- **DexScreener** : pas de clé, public
- **X.com** : https://developer.twitter.com → Bearer Token → `X_BEARER_TOKEN` pour FOMO
- **GitHub API** : optionnel, pour tracker les nouveaux repos memecoin (ajoute `GITHUB_TOKEN`)

Tous sont déjà câblés dans `server.js`, il suffit de mettre les clés.

---

## 💸 De 20€ à 50 000€ — réalité

Le frontend affiche la progression. Mais sois lucide :
- 90% des tokens Pump.fun sont des rugs / dead en <1h
- Les bots MEV te front-run
- Slippage + fees Solana mangent 2-5% par trade
- Pour faire x2500 (20→50k), il faut ~15 trades x2 consécutifs sans perte — statistiquement quasi impossible sans chance extrême

**Conseil pro** : commence avec 0.05 SOL, test 48h, mesure winrate réel, puis ajuste TP/SL.

---

## 🛡️ Sécurité

- Ne commite jamais `.env` avec `PRIVATE_KEY_BASE58`
- Le wallet bot est serveur-side : garde la clé hors ligne
- Utilise un wallet dédié au bot, pas ton wallet principal
- Active 2FA sur Render/Railway

---

## 📜 Licence

MIT — usage éducatif. Pas de conseil financier.

---

## 🚀 DEPLOY 1-CLICK POUR surfersummit

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://dashboard.render.com/blueprint/new?repo=https://github.com/surfersummit/snipprr-v3)

1. Crée repo `snipprr-v3` sur https://github.com/new (owner: surfersummit)
2. Upload le zip `snipprr-v3-surfersummit.zip` via `Add file → Upload files` sur GitHub
3. Va sur https://dashboard.render.com → New → Blueprint → connecte `surfersummit/snipprr-v3` → Apply
4. Tu obtiens `https://snipprr-v3-xxxx.onrender.com` HTTPS gratuit H24
