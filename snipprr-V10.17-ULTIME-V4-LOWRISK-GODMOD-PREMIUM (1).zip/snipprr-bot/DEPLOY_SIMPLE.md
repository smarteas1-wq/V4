# Déploiement ULTRA SIMPLE 100% GitHub - Gratuit

## Option 1: VERCEL (Le plus simple - 1 clic, 30s)
1. Va sur https://vercel.com/new
2. Clique "Add GitHub Account" → autorise `surfersummit`
3. Cherche `snipprr-v3` → Import
4. Clique Deploy (laisse tout par défaut) → 1 min → tu obtiens `https://snipprr-v3-xxxx.vercel.app` HTTPS gratuit H24
5. C'est tout ! Le bot tourne H24, auto-deploy à chaque push GitHub

Bouton 1-clic:
https://vercel.com/new/clone?repository-url=https://github.com/surfersummit/snipprr-v3

## Option 2: NETLIFY (aussi 1 clic)
1. https://app.netlify.com/start → Import from GitHub → `surfersummit/snipprr-v3`
2. Build: `cd backend && npm install` / Publish: `frontend`
3. Deploy → `https://snipprr-v3-xxxx.netlify.app` HTTPS gratuit

## Option 3: GitHub Pages (Frontend seul, sans serveur - 100% gratuit mais bot seulement quand onglet ouvert)
1. Repo → Settings → Pages → Source: `main` / `root` → Save
2. Ton frontend sera sur `https://surfersummit.github.io/snipprr-v3/` en 2 min
3. Le bot tournera dans ton navigateur (pas H24 serveur)

## RECOMMANDÉ: VERCEL
- Gratuit 100h/mois H24
- HTTPS auto
- Pas de carte bancaire
- Déploiement auto à chaque `git push`
