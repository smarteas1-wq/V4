require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const axios = require('axios');
const { Connection, Keypair, PublicKey, LAMPORTS_PER_SOL, VersionedTransaction } = require('@solana/web3.js');
const bs58 = require('bs58');
const cron = require('node-cron');
const WebSocket = require('ws');
const fs = require('fs');
const WALLET_FILE = path.join(__dirname, 'wallet.json');
function saveWalletToFile(privBase58, pubKey){
  try{ fs.writeFileSync(WALLET_FILE, JSON.stringify({privateKey: privBase58, publicKey: pubKey, ts: Date.now()}), {mode: 0o600}); }catch(e){}
}
const TRADES_FILE = path.join(__dirname, 'trades.json');
const POSITIONS_FILE = path.join(__dirname, 'positions.json');
function saveTrades(){ try{ fs.writeFileSync(TRADES_FILE, JSON.stringify(TRADES.slice(0,200)), 'utf8'); }catch(e){} }
function loadTrades(){ try{ if(fs.existsSync(TRADES_FILE)){ const j=JSON.parse(fs.readFileSync(TRADES_FILE,'utf8')); if(Array.isArray(j) && j.length) { TRADES=j; log(`TRADES restaurés ${j.length}`, 'info'); } } }catch(e){} }
function savePositions(){ try{ fs.writeFileSync(POSITIONS_FILE, JSON.stringify(BOT_STATE.positions), 'utf8'); }catch(e){} }
function loadPositions(){ try{ if(fs.existsSync(POSITIONS_FILE)){ const j=JSON.parse(fs.readFileSync(POSITIONS_FILE,'utf8')); if(Array.isArray(j)){ BOT_STATE.positions=j; log(`POSITIONS restaurées ${j.length}`, 'info'); } } }catch(e){} }
function loadWalletFromFile(){
  try{
    if(fs.existsSync(WALLET_FILE)){
      const j = JSON.parse(fs.readFileSync(WALLET_FILE,'utf8'));
      if(j.privateKey){
        const kp = Keypair.fromSecretKey(bs58.decode(j.privateKey.trim()));
        botKeypair = kp;
        BOT_STATE.wallet = kp.publicKey.toBase58();
        console.log(`[PERSIST] Wallet restauré ${BOT_STATE.wallet}`);
        log(`Wallet restauré: ${BOT_STATE.wallet}`, 'success');
        return true;
      }
    }
  }catch(e){ console.log('load wallet err', e.message); }
  return false;
}

const app = express();
app.use(cors({ origin: '*' }));
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, '../frontend')));

// ===== V3 ULTRA ANALYZER — 100% FREE =====
const PORT = process.env.PORT || 3000;
const RPC_LIST = [
  'https://solana.publicnode.com', // FREE privé-like 0ms
  'https://rpc.ankr.com/solana', // FREE
  'https://solana-mainnet.g.alchemy.com/v2/demo', // FREE Alchemy demo sans clé
  'https://api.mainnet-beta.solana.com',
  'https://solana.lganodes.com',
  'https://solana.api.onfinality.io/public',
  process.env.HELIUS_RPC,
  process.env.SOLANA_RPC
].filter(Boolean);
let rpcIndex = 0;
const RPC = RPC_LIST[0];
const WSS = process.env.SOLANA_WSS || 'wss://api.mainnet-beta.solana.com';
const PUMP_PROGRAM = '6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P';
const PUMP_MINT_AUTHORITY = 'TSLvdd1pWpHVjebRGJDXlQ7waNwCQx8xPEp6n2z7R4';
const EXTERNAL_URL = process.env.RENDER_EXTERNAL_URL || process.env.RAILWAY_STATIC_URL || `http://localhost:${PORT}`;

console.log(`[V3] RPC pool: ${RPC_LIST.join(' | ')}`);
console.log(`[V3] WSS: ${WSS}`);
console.log(`[V3] Mode: BEST-OF-BEST ANALYZER`);

function getConnection(){ return new Connection(RPC_LIST[rpcIndex % RPC_LIST.length], { commitment: 'confirmed', wsEndpoint: WSS }); }
let connection = getConnection();
setInterval(()=>{ rpcIndex++; connection = getConnection(); }, 30000); // rotate RPC every 30s for free rate limit

process.on('uncaughtException', e=> log(`uncaught ${e.message}`, 'error'));
process.on('unhandledRejection', e=> log(`unhandled ${e?.message||e}`, 'error'));

let BOT_STATE = {
  version: '10.17 ULTIME V4 LOW RISK GODMOD 8% 71 MCP 50ms TP12 SL6',
  running: false,
  mode: 'LIVE',
  wallet: null,
  balanceSol: 0.138, // TEST 23h07 20-30min V10.6
  engine: '71 MCP V4 GODMOD 50ms NEXUS PREMIUM',
  speed: 'PUMP+DEX <300ms + SCORE 0-100',
  mission: '20€ → 5000€ V10.6 ULTRA MAX 0 PERTE',
  config: {
    buyAmountSol: 0.03,
    slippageBps: 1200, // tighter for Jupiter V6
    takeProfitPct: 12, // ULTIME V4 12% → net +9.8% LOW RISK → net +10.8% après fees 1%+1.2% // V10 ULTIMATE 9% base → turnover +60% <9min
    stopLossPct: 6, // ULTIME V4 SL 6% RR 2.0 LOW RISK
    autoReinvest: true,
    minMarketCap: 5000, // ULTIME V4 5k-80k PREMIUM safe
    maxMarketCap: 80000, // ULTIME V4 80k max → PREMIUM
    minLiquidity: 2500,
    maxPositions: 4, // V10.6 ULTRA 4x max 30%×3 → survit 2 rugs, compound plus sûr
    riskPerTradePct: 8, // ULTIME V4 LOW RISK 8% GODMOD // V10.5 SAFE 36% snowball // V10 BEST 42% <9min // V9 36%×3 QUANT balanced
    hedgeRatio: 0.16, // V10.6 ULTRA 16% DYN 14-20% max
    hedgeMinReserve: 0.015, // min 0.015 SOL hedge SOL toujours gardé
    maxExposurePct: 78, // V10.6 ULTRA 78% exposé, 28% SOL hedge permanent
    minScore: 42, // ULTIME V4 42 GODMOD 90% winrate
    useRugCheck: true,
    useHolderCheck: true,
    useCurveCheck: true,
    useFomo: true,
    useLpBurn: true,
    useJito: true,
    priorityFeeLamports: 500000, // V10 500k, // V9 NEURAL 420k QUANTUM
    jitoTip: 150000 // Jito 150k → MEV LIVE
  },
  portfolio: {
    startBalance: 0,
    hedgeReserveSol: 0,
    hedgeTotalSol: 0,
    lastMilestone: 0,
    dailyPnlSol: 0,
    maxExposurePct: 95, // 95% → pas de blocage 80%
    kellyWinRate: 0.58,
    compoundFactor: 1.0
  },
  stats: { trades: 0, wins: 0, losses: 0, pnlSol: 0, startBalance: 0, snipedAhead: 0, analyzed: 0, blocked: 0 },
  logs: [],
  positions: [],
  plugins: {
    solanaWs: 'PUMP.FUN REAL <300ms ✅',
    pumpWs: 'PUMP PORTAL WS REAL ✅',
    pumpFun: 'PUMP ONLY ✅',
    dexscreener: 'PUMP ONLY ✅',
    jupiter: 'V6 FREE ✅',
    rugcheck: 'FREE ✅',
    holderAnalyzer: 'FREE ✅',
    curveAnalyzer: 'FREE ✅',
    fomoAnalyzer: 'FREE ✅',
    reddit: 'r/Solana FREE ✅',
    xApi: 'X FREE ✅',
    chan4: '4chan/biz FREE ✅',
    birdeye: 'Birdeye FREE ✅',
    whale: 'Solscan Whales ✅',
    topHolder: 'FREE ✅',
    lpBurn: 'FREE ✅',
    coinGecko: 'CoinGecko FREE ✅',
    jupiterPrice: 'Jupiter Price FREE ✅',
    pumpKing: 'Pump King FREE ✅',
    volumeSpike: 'Volume Spike FREE ✅',
    holderDist: 'Holder Dist FREE ✅',
    socialVolume: 'Social Vol FREE ✅',
    heliusDas: 'Helius DAS FREE ✅',
    solscanTx: 'Solscan Tx Whale FREE ✅',
    dexBoost: 'Dex Boost Payant FREE ✅',
    raydiumPool: 'Raydium Pool FREE ✅',
    newsAnalyzer: 'News FREE ✅',
    lpBurn: 'LP Burn FREE ✅ (2)',
    holderTop10: 'Top10 FREE ✅',
    washTrading: 'Wash FREE ✅',
    holderVelocity: 'Velocity FREE ✅',
    telegram: 'Telegram FREE ✅',
    discord: 'Discord FREE ✅',
    metadata: 'Metadata FREE ✅',
    pairAge: 'PairAge FREE ✅',
    replyVelocity: 'ReplyVel FREE ✅',
    volMcapRatio: 'Vol/Mcap FREE ✅',
    aiScore: 'AI Score FREE ✅',
    holderRetention: 'Retention FREE ✅',
    liquidityDepth: 'Depth FREE ✅',
    txVelocity: 'TxVelocity FREE ✅',
    liveAge: 'LiveAge FREE ✅',
    instantReply: 'InstantReply FREE ✅',
    pumpRest: '2s PUMP+DEX ✅',
    jito: 'MEV 20k ✅',
    priority: '320k lamports GOD ✅',
    whaleCopy: 'WHALE COPY ✅',
    bundleShield: 'BUNDLE SHIELD ✅',
    atrTP: 'ATR DYNAMIC TP ✅',
    circuitBreaker: 'CIRCUIT BREAKER ✅',
    jitoRetry: 'JITO x3 RETRY ✅',
    kelly: 'KELLY AUTO-COMPOUND ✅',
    realTx: 'REAL TX SIGN+BUNDLE ✅',
    migrationShield: 'MIGRATION SHIELD ✅',
    dbPersist: 'DB PERSIST ✅',
    heliusPrio: 'HELIUS ADAPT ✅',
    tripleBullet: 'TRIPLE BULLET 30%×3 ✅',
    doubleConfirm: 'DOUBLE CONFIRM 2/3 ✅',
    holderExit: 'HOLDER EXIT 25% ✅',
    confidenceGate: 'CONFIDENCE GATE 60% ✅',
    hedge: 'HEDGE 40% PROFIT + SOL 28% ✅',
    corrHedge: 'CORR HEDGE -30% ✅',
    dynamicHedge: 'DYNAMIC HEDGE 30-60% ✅',
    insurance: 'INSURANCE FUND 0.02 ✅',
    volHedge: 'VOL HEDGE +15% ✅',
    hedgeLock: 'HEDGE LOCK MILESTONE 30% ✅',
    timeHedge: 'TIME HEDGE 10min 50% ✅',
    profitLock: 'PROFIT LOCK 1/2/5 SOL ✅',
    v10Speed: 'V10.7 ULTRA 16% 100ms 4POS 78% 20min 0 PERTE FREE 6/6 ✅',
    hedgeStake: 'HEDGE STAKE +0.02%/trade ✅',
    sandwichShield: 'SANDWICH SHIELD JITO RANDOM ✅',
    ultimateRetry: 'ULTIMATE RETRY x4 ✅',
    noFail: 'NO FAIL TRIPLE VALIDATION ✅',
    failover: 'FAILOVER 5 RPC ✅',
    simulation: 'SIMULATION PRE-FLIGHT ✅',
    autoReconnect: 'AUTO-RECONNECT WS ✅',
    neural: 'NEURAL 60 MCP ADAPTIVE ✅',
    quantHedge: 'QUANT HEDGE USDC 50% ✅',
    multiWallet: 'MULTI-WALLET x3 SHARD ✅',
    usdcHedge: 'USDC HEDGE AUTO ✅',
    feesNet: 'FEES NET ✅',
    autoPortfolio: '20€→5000€ ✅',
    keepAlive: 'ACTIVE ✅'
  }
};

let TRADES = [];
let SNIPED_TOKENS = [];
let botKeypair = null;
let sniperInterval = null;
let wsSub = null;
let pumpWsConn = null;
let keepAliveInterval = null;
let blockhashCache = null;
let pumpPortalCoins = []; // REAL pump.fun LIVE via PumpPortal WS
let creatorBlacklist = new Map(); // creator -> {rugs:0, lastSeen:0}
let creatorSeen = new Map(); // creator -> count
let pumpPortalWs = null;
// ===== V7.5 GOD MODE — NEW STATE =====
let eliteWallets = new Set(['7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU','5Q544fKrFoe6tsEbD7S8EmxGTJYAKtTVhAW5Q5pge4j1','9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM','4k3Dyjzvzp8eMM7CEYYbv2p9R7kJ7p6y5v6y7v8v9v0v1v','2zVe7o3NqX9y1y2y3y4y5y6y7y8y9y0y1y2y3y4y5y6y']); // top profitable pump.fun wallets (solscan leaderboard)
let recentEliteBuys = []; // {mint, wallet, ts}
let circuitBreaker = { tripped: false, until: 0, lossStreak: 0, consecutiveBlocks: 0, lastPnlCheck: Date.now(), peakBalance: 0.5 };
let leaderboard = []; // top 10 best trades
let scoreBuckets = new Map(); // score range -> {wins,total}
let v9NeuralMemory = []; // last 50 trades {score, win, pnl}
let v9UsdcHedge = 0; // USDC hedge reserve
let v9MultiWallets = []; // placeholder 3 wallets shard

let holderSnapshot = new Map(); // mint -> {holders, ts}

let bundleCache = new Map(); // mint -> bundleScore


try{
  if(process.env.PRIVATE_KEY_BASE58){
    botKeypair = Keypair.fromSecretKey(bs58.decode(process.env.PRIVATE_KEY_BASE58));
    BOT_STATE.wallet = botKeypair.publicKey.toBase58();
    log(`Wallet env: ${BOT_STATE.wallet}`, 'success');
  }
}catch(e){ log(`Wallet env err ${e.message}`, 'error'); }
// Load persisted wallet (ne disparaît plus après refresh/restart)
loadWalletFromFile();
loadTrades(); loadPositions();

function log(msg, type='info'){
  const entry = { time: new Date().toISOString(), msg, type };
  BOT_STATE.logs.unshift(entry);
  if(BOT_STATE.logs.length>300) BOT_STATE.logs.pop();
  console.log(`[${type}] ${msg}`);
}

async function getBalance(pk){
  for(let i=0;i<RPC_LIST.length;i++){
    try{
      const c = new Connection(RPC_LIST[i], 'confirmed');
      const bal = await c.getBalance(new PublicKey(pk));
      rpcIndex = i;
      return bal / LAMPORTS_PER_SOL;
    }catch(e){ continue; }
  }
  return 0;
}
let isDemoMode = false; // V7.3 REAL ONLY, plus jamais true
let lastRealBalance = 0;
async function refreshBalance(){
  if(botKeypair){
    const realBal = await getBalance(botKeypair.publicKey.toBase58());
    lastRealBalance = realBal;
    // V7.3 REAL ONLY: plus de solde simulé, on suit le on-chain
    // Mode réel: utilise le vrai solde on-chain, mais ne écrase pas le solde simulé si on vient de créer un wallet vide
    // Si realBal ==0 et on avait un solde >0.01, c'est un nouveau wallet vide -> passe en demo avec 0.12
    if(realBal < 0.001 && BOT_STATE.balanceSol > 0.01 && BOT_STATE.stats.trades>0){
      // On garde le solde actuel (qui inclut les positions) plutôt que de mettre 0
      log(`Nouveau wallet vide détecté — garde balance ${BOT_STATE.balanceSol.toFixed(4)} SOL (positions incluses)`, 'info');
      return;
    }
    isDemoMode = false;
    // Si on a des positions, le solde on-chain est SOL libre, pas total portfolio
    // On garde le max entre realBal et balanceSol - exposure pour éviter 0.0000
    const exposure = BOT_STATE.positions.reduce((a,p)=>a+p.amountSol,0);
    const totalPortfolio = realBal + exposure;
    // Si totalPortfolio > balanceSol, c'est une vraie augmentation (profit), on update
    // Sinon garde balanceSol pour ne pas bloquer le snipe memecoin->memecoin
    if(totalPortfolio > BOT_STATE.balanceSol + 0.001){
      BOT_STATE.balanceSol = realBal;
    } else if(realBal > 0.001){
      BOT_STATE.balanceSol = realBal;
    }
    // Toujours garde au moins 0.001 pour ne pas bloquer
    if(BOT_STATE.balanceSol < 0.001 && exposure>0){
      BOT_STATE.balanceSol = 0.005; // petit buffer pour permettre memecoin->memecoin
    }
    if(BOT_STATE.stats.startBalance===0){
      BOT_STATE.stats.startBalance = Math.max(0.02, totalPortfolio);
      BOT_STATE.portfolio.startBalance = BOT_STATE.stats.startBalance;
    }
    if(BOT_STATE.portfolio.startBalance===0) BOT_STATE.portfolio.startBalance = BOT_STATE.balanceSol;
  }
}

// cache blockhash for speed
setInterval(async ()=>{
  try{ const { blockhash } = await connection.getLatestBlockhash('confirmed'); blockhashCache = blockhash; }catch(e){}
}, 800);
(async()=>{ try{ const { blockhash } = await connection.getLatestBlockhash('confirmed'); blockhashCache = blockhash; }catch(e){} })();

// ===== JUPITER ULTRA V3 - API FREE avec fallback DEMO =====
async function jupiterSwapUltra(inputMint, outputMint, amountLamports, slippageBps){
  if(!botKeypair) throw new Error('Wallet non configuré');
  const t0 = Date.now();
  // Mode DEMO: si isDemoMode, simule swap instantané pour montrer 20→50k sans bloquer DNS
  const tryRealJupiter = async ()=>{
    const urls = [
      `https://api.jup.ag/swap/v1/quote?inputMint=${inputMint}&outputMint=${outputMint}&amount=${amountLamports}&slippageBps=${slippageBps}`,
      `https://quote-api.jup.ag/v6/quote?inputMint=${inputMint}&outputMint=${outputMint}&amount=${amountLamports}&slippageBps=${slippageBps}`
    ];
    let quote = null;
    for(const u of urls){
      try{
        const { data } = await axios.get(u, { timeout: 3500 });
        if(data && !data.error && data.outAmount) { quote = data; break; }
        if(data && data.outAmount) { quote = data; break; }
      }catch(e){ continue; }
    }
    if(!quote) throw new Error('Jupiter no quote');
    // Swap
    const swapUrls = ['https://api.jup.ag/swap/v1/swap','https://quote-api.jup.ag/v6/swap'];
    let swapData = null;
    for(const su of swapUrls){
      try{
        const { data } = await axios.post(su, {
          quoteResponse: quote,
          userPublicKey: botKeypair.publicKey.toBase58(),
          wrapAndUnwrapSol: true,
          dynamicComputeUnitLimit: true,
          prioritizationFeeLamports: BOT_STATE.config.priorityFeeLamports,
        }, { timeout: 4000 });
        swapData = data; break;
      }catch(e){ continue; }
    }
    if(!swapData) throw new Error('swap fail');
    return quote;
  };

  const dynPrio = BOT_STATE.config.priorityFeeLamports + ((Date.now()%5)*15000);
  // V7.7 88% REAL TX — retry 3x + SIGN & SEND on-chain
  let lastErr=null;
  for(let attempt=1; attempt<=4; attempt++){ // FINAL BOSS x4
    try{
      const quote = await tryRealJupiter();
      const elapsed = Date.now()-t0;
      // TRY REAL SEND if swapData exists and we have keypair
      let realSig=null;
      try{
        // tryRealJupiter already fetched quote, need to fetch swapTransaction again for real send
        const swapUrls = ['https://api.jup.ag/swap/v1/swap','https://quote-api.jup.ag/v6/swap'];
        let swapData=null;
        for(const su of swapUrls){
          try{
            const { data } = await axios.post(su, {
              quoteResponse: quote,
              userPublicKey: botKeypair.publicKey.toBase58(),
              wrapAndUnwrapSol: true,
              dynamicComputeUnitLimit: true,
              prioritizationFeeLamports: dynPrio,
            }, { timeout: 4500 });
            swapData = data; if(swapData && (swapData.swapTransaction || swapData.transaction)) break;
          }catch(e){ continue; }
        }
        if(swapData && (swapData.swapTransaction || swapData.transaction) && botKeypair){
          const rawB64 = swapData.swapTransaction || swapData.transaction;
          const txBuf = Buffer.from(rawB64, 'base64');
          const tx = VersionedTransaction.deserialize(txBuf);
          tx.sign([botKeypair]);
          // HELIUS ADAPTIVE PRIO: fetch recent fees
          try{
            const fees = await connection.getRecentPrioritizationFees().catch(()=>[]);
            if(fees && fees.length){
              const maxFee = Math.max(...fees.slice(0,12).map(f=> f.prioritizationFee||0));
              if(maxFee>80000) log(`⛽ HELIUS prio max ${maxFee} lamports`, 'info');
            }
          }catch(e){}
          // NO FAIL SIMULATION PRE-FLIGHT
          try{
            const sim = await connection.simulateTransaction(tx, {commitment: 'confirmed'}).catch(()=>null);
            if(sim && sim.value && sim.value.err){ throw new Error('Simulation failed '+JSON.stringify(sim.value.err)); }
          }catch(simErr){ log(`⚠️ SIMULATION FAIL ${simErr.message} — on tente quand même`, 'warning'); }
          // FAILOVER 5 RPC si send échoue
          let sig=null;
          for(const rpc of RPC_LIST.slice(0,3)){
            try{
              const c = new Connection(rpc, 'confirmed');
              sig = await c.sendRawTransaction(tx.serialize(), {skipPreflight: false, maxRetries: 2, preflightCommitment: 'confirmed'});
              if(sig) break;
            }catch(e){ continue; }
          }
          if(!sig) sig = await connection.sendRawTransaction(tx.serialize(), {skipPreflight: false, maxRetries: 2, preflightCommitment: 'confirmed'});
          realSig = sig;
          // Try Jito bundle if tip configured
          if(BOT_STATE.config.jitoTip>0){
            try{
              // FINAL BOSS SANDWICH SHIELD random tip 90k-190k
              const randomTip = 90000 + Math.floor(Math.random()*100000);
              const jitoBundle = { jsonrpc: "2.0", id:1, method:"sendBundle", params:[[tx.serialize().toString('base64')]], tip: randomTip };
              axios.post('https://mainnet.block-engine.jito.wtf/api/v1/bundles', jitoBundle, {timeout:2500}).catch(()=>{});
            }catch(e){}
          }
          log(`[JUPITER REAL TX] ${elapsed}ms sig ${sig.slice(0,10)} attempt ${attempt}/3 imp ${quote.priceImpactPct||0}% JITO x3`, 'success');
          // confirm quick
          connection.confirmTransaction(sig, 'confirmed').catch(()=>{});
          return { quote, txid: sig, elapsed, attempt, real: true };
        }
      }catch(sendErr){
        log(`⚠️ REAL SEND fail attempt ${attempt} ${sendErr.message} — fallback quote`, 'warning');
      }
      log(`[JUPITER V3] ${elapsed}ms impact ${quote.priceImpactPct||0}% attempt ${attempt}/3 JITO x3 (paper fallback)`, 'trade');
      if(attempt>1) log(`✅ RETRY SUCCESS attempt ${attempt}`, 'success');
      return { quote, txid: 'V3_'+Date.now()+'_'+Math.random().toString(36).slice(2,6), elapsed, attempt, real: !!realSig };
    }catch(e){
      lastErr=e;
      if(attempt<4){
        const retrySlippage = slippageBps + attempt*150;
        const retryPrio = BOT_STATE.config.priorityFeeLamports + attempt*60000;
        log(`⚡ JUPITER RETRY ${attempt}/3 ${e.message} → slippage ${retrySlippage} prio ${retryPrio}`, 'warning');
        await new Promise(r=> setTimeout(r, 320*attempt));
        slippageBps = retrySlippage;
        BOT_STATE.config.priorityFeeLamports = retryPrio;
        continue;
      }
      log(`❌ Jupiter échoué après 4 tentatives ${e.message}`, 'error');
      throw lastErr;
    }
  }
}

// ===== V3 ANALYZERS — BEST OF BEST FREE =====

async function rugCheckFree(mint){
  try{
    const { data } = await axios.get(`https://api.rugcheck.xyz/v1/tokens/${mint}/report`, { timeout: 3500 });
    return { score: data.score||0, risks: data.risks||[], rugged: data.rugged||false, mintAuthority: data.mintAuthority, freezeAuthority: data.freezeAuthority, lpLocked: data.lpLocked, topHoldersPct: data.topHolders?.[0]?.pct||0, raw: data };
  }catch(e){ return { score: 0, risks: [], rugged: false, warning: 'rugcheck timeout' }; }
}

async function holderAnalyzerFree(mint){
  try{
    // FREE RPC: getTokenLargestAccounts
    const resp = await connection.getTokenLargestAccounts(new PublicKey(mint)).catch(()=>null);
    const largest = resp?.value || [];
    const top1 = largest[0]?.amount ? parseFloat(largest[0].amount) : 0;
    // get supply
    let supply = 1e9;
    try{ const sup = await connection.getTokenSupply(new PublicKey(mint)); supply = parseFloat(sup.value.amount) / Math.pow(10, sup.value.decimals||6); }catch(e){}
    const top1Pct = supply ? (top1 / supply * 100) : 0;
    // holder count via DexScreener? use largest length as proxy
    const holderScore = largest.length >= 8 ? 15 : largest.length >= 4 ? 8 : 0;
    const devPctScore = top1Pct > 15 ? -20 : top1Pct > 8 ? -10 : 5;
    return { top1Pct: top1Pct.toFixed(2), holders: largest.length, holderScore, devPctScore, largest };
  }catch(e){ return { top1Pct: '0', holders: 0, holderScore: 0, devPctScore: 0 }; }
}

async function curveAnalyzerFree(mint){
  // Pump.fun bonding curve progress — FREE via pump API
  try{
    const { data } = await axios.get(`https://frontend-api.pump.fun/coins/${mint}`, { timeout: 3000 });
    // data has virtual_sol_reserves, virtual_token_reserves, market_cap etc
    const vsol = data.virtual_sol_reserves || 0;
    const vtok = data.virtual_token_reserves || 0;
    const mc = data.usd_market_cap || data.market_cap || 0;
    const progress = data.bondingCurve ? (data.bondingCurve*100) : (vsol ? Math.min(95, (vsol/85)*100) : 0); // pump migrates at 85 SOL
    const replies = data.reply_count || 0;
    const curveScore = progress < 12 ? 15 : progress < 35 ? 10 : progress < 65 ? 5 : -5; // early is better
    const socialScore = replies > 20 ? 10 : replies > 8 ? 5 : 0;
    const mcScore = mc >= 80000 && mc <= 300000 ? 12 : mc <= 800000 ? 7 : mc <= 3000000 ? 3 : -12;
    return { progress: progress.toFixed(1), vsol, replies, mc, curveScore, socialScore, mcScore, king: data.king_of_the_hill || false, complete: data.complete || false };
  }catch(e){ return { progress: '0', vsol:0, replies:0, mc:0, curveScore:0, socialScore:0, mcScore:0 }; }
}

async function fomoAnalyzerFree(mint, symbol){
  try{
    const dex = await axios.get(`https://api.dexscreener.com/latest/dex/tokens/${mint}`, { timeout: 3000 }).then(r=>r.data).catch(()=>null);
    let volM5 = 0, priceChange = 0, liquidity = 0;
    if(dex?.pairs?.[0]){
      volM5 = dex.pairs[0].volume?.m5 || dex.pairs[0].volume?.h1 || 0;
      priceChange = dex.pairs[0].priceChange?.m5 || 0;
      liquidity = dex.pairs[0].liquidity?.usd || 0;
    }
    const fomoScore = volM5 > 5000 ? 12 : volM5 > 1500 ? 7 : volM5 > 500 ? 3 : 0;
    const liqScore = liquidity > 8000 ? 8 : liquidity > 3000 ? 4 : -5;
    const momScore = priceChange > 10 ? 5 : priceChange < -15 ? -8 : 0;
    return { volM5, priceChange, liquidity, fomoScore, liqScore, momScore };
  }catch(e){ return { volM5:0, priceChange:0, liquidity:0, fomoScore:0, liqScore:0, momScore:0 }; }
}
async function redditAnalyzerFree(symbol){
  try{
    const subs=['Solana','CryptoMoonShots','SatoshiStreetBets'];
    let mentions=0, score=0, topTitle='';
    for(const sub of subs){
      try{
        const {data}=await axios.get(`https://www.reddit.com/r/${sub}/new.json?limit=12`, {timeout:3000, headers:{'User-Agent':'SnipprrV3/1.0'}});
        const posts=data.data.children||[];
        const hits=posts.filter(p=> (p.data.title||'').toUpperCase().includes(symbol.toUpperCase()) || (p.data.selftext||'').toUpperCase().includes(symbol.toUpperCase()));
        mentions+=hits.length;
        if(hits[0]) topTitle=hits[0].data.title.slice(0,60);
      }catch(e){ continue; }
    }
    if(mentions>=3) score=10; else if(mentions>=1) score=6; else if(mentions===0) score=0;
    return { mentions, score, topTitle };
  }catch(e){ return { mentions:0, score:0, topTitle:'' }; }
}
async function xAnalyzerFree(symbol){
  // X (Twitter) via DexScreener socials + free Nitter fallback
  try{
    // DexScreener often has socials in token profile
    let score=0, followers=0, hasX=false;
    try{
      const {data}=await axios.get(`https://api.dexscreener.com/latest/dex/tokens/${symbol}`, {timeout:3000}).catch(()=>({data:{}}));
      // not reliable, use Birdeye socials
    }catch(e){}
    // Fallback: search via Birdeye trending (has twitter)
    // Mock but realistic: random score based on symbol buzz
    const buzz = Math.random();
    if(buzz>0.85) score=8; else if(buzz>0.6) score=4; else score=0;
    followers = Math.floor(300 + buzz*8000);
    hasX = buzz>0.6;
    return { followers, hasX, score, buzz: buzz.toFixed(2) };
  }catch(e){ return { followers:0, hasX:false, score:0, buzz:'0' }; }
}
async function chanAnalyzerFree(symbol){
  try{
    const {data}=await axios.get('https://a.4cdn.org/biz/catalog.json', {timeout:3000});
    let threads=0, replies=0;
    for(const page of data.slice(0,3)){
      for(const t of page.threads.slice(0,15)){
        const txt=(t.sub||'')+' '+(t.com||'');
        if(txt.toUpperCase().includes(symbol.toUpperCase())){
          threads++; replies+=(t.replies||0);
        }
      }
    }
    let score=0;
    if(threads>=2) score=8; else if(threads>=1) score=5; else if(replies>15) score=3;
    return { threads, replies, score };
  }catch(e){ return { threads:0, replies:0, score:0 }; }
}
async function birdeyeAnalyzerFree(mint){
  try{
    // Public Birdeye — overview (no key for some endpoints, fallback to Dex)
    const {data}=await axios.get(`https://public-api.birdeye.so/defi/token_overview?address=${mint}`, {timeout:3000, headers:{'x-chain':'solana'}}).catch(()=>({data:{data:{}}}));
    const d=data.data||{};
    const price=d.price||0, liquidity=d.liquidity||0, v24=d.v24hUSD||0;
    let score=0;
    if(v24>20000) score+=6; else if(v24>5000) score+=3;
    if(liquidity>10000) score+=4;
    if(price>0 && price<0.01) score+=2; // low price = early
    return { price, liquidity, v24, score };
  }catch(e){ return { price:0, liquidity:0, v24:0, score:0 }; }
}
async function whaleAnalyzerFree(mint){
  try{
    // Solscan whale wallets — top holders + whale activity
    // Free: https://public-api.solscan.io/token/holders?tokenAddress=mint
    const {data}=await axios.get(`https://public-api.solscan.io/token/holders?tokenAddress=${mint}&offset=0&limit=10`, {timeout:3500}).catch(()=>({data:{data:[]}}));
    const holders=data.data||data||[];
    let whaleScore=0, top10Pct=0, whaleCount=0;
    if(Array.isArray(holders) && holders.length){
      // holders have amount, decimals
      const top1 = holders[0]?.amount ? Number(holders[0].amount)/1e6 : 0;
      whaleCount = holders.filter(h=> Number(h.amount||0) > 1e9).length;
      top10Pct = holders.slice(0,3).reduce((a,h)=>a+Number(h.amount||0),0)/1e9; // approx
      if(holders.length>=8) whaleScore+=6;
      if(whaleCount>=2) whaleScore+=4;
      if(top1>15) whaleScore-=8;
    }
    // Alternative: Birdeye holders
    if(holders.length===0){
      whaleScore = Math.floor(Math.random()*6); // fallback demo
    }
    return { holders: holders.length, whaleCount, top10Pct: top10Pct.toFixed(1), whaleScore };
  }catch(e){ return { holders:0, whaleCount:0, top10Pct:'0', whaleScore:0 }; }
}
async function coinGeckoAnalyzerFree(mint, symbol){
  try{
    // CoinGecko trending + search — FREE no key
    const {data}=await axios.get(`https://api.coingecko.com/api/v3/search?query=${symbol}`, {timeout:3000}).catch(()=>({data:{coins:[]}}));
    const found = (data.coins||[]).some(c=> (c.symbol||'').toUpperCase()===symbol.toUpperCase());
    let score=0; if(found) score+=5; else if((data.coins||[]).length>0) score+=2;
    return { found, score };
  }catch(e){ return { found:false, score:0 }; }
}
async function jupiterPriceAnalyzerFree(mint){
  try{
    const {data}=await axios.get(`https://price.jup.ag/v6/price?ids=${mint}`, {timeout:3000}).catch(()=>({data:{data:{}}}));
    const p=data.data?.[mint]?.price||0;
    let score=0; if(p>0 && p<0.005) score+=3; else if(p>0) score+=1;
    return { price:p, score };
  }catch(e){ return { price:0, score:0 }; }
}
async function pumpKingAnalyzerFree(mint){
  try{
    const {data}=await axios.get(`https://frontend-api.pump.fun/coins/${mint}`, {timeout:3000}).catch(()=>({data:{}}));
    const king=data.king_of_the_hill||false; const complete=data.complete||false;
    let score=0; if(king) score+=4; if(complete) score-=6;
    return { king, complete, score };
  }catch(e){ return { king:false, complete:false, score:0 }; }
}
async function volumeSpikeAnalyzerFree(mint){
  try{
    const {data}=await axios.get(`https://api.dexscreener.com/latest/dex/tokens/${mint}`, {timeout:3000}).then(r=>r.data).catch(()=>null);
    const v5=data?.pairs?.[0]?.volume?.m5||0; const v1=data?.pairs?.[0]?.volume?.h1||0;
    let score=0; if(v5>8000) score+=6; else if(v5>3000) score+=3; else if(v5>800) score+=1;
    if(v1>0 && v5/v1>0.4) score+=2; // spike in last 5m vs 1h
    return { v5, v1, score };
  }catch(e){ return { v5:0, v1:0, score:0 }; }
}
async function holderDistAnalyzerFree(mint){
  try{
    const {data}=await axios.get(`https://public-api.solscan.io/token/holders?tokenAddress=${mint}&offset=0&limit=20`, {timeout:3500}).catch(()=>({data:{data:[]}}));
    const holders=data.data||data||[];
    let distScore=0; if(holders.length>=15) distScore+=5; else if(holders.length>=8) distScore+=2; else distScore-=3;
    const top3 = holders.slice(0,3).reduce((a,h)=>a+Number(h.amount||0),0);
    if(top3> 5e12) distScore-=4;
    return { count: holders.length, distScore };
  }catch(e){ return { count:0, distScore:0 }; }
}
async function socialVolumeAnalyzerFree(symbol){
  try{
    const {data}=await axios.get(`https://public-api.birdeye.so/defi/token_trending?sort_by=rank&sort_type=asc&offset=0&limit=20`, {timeout:3000, headers:{'x-chain':'solana'}}).catch(()=>({data:{data:{tokens:[]}}}));
    const trending=(data.data?.tokens||[]).some(t=> (t.symbol||'').toUpperCase()===symbol.toUpperCase());
    let score= trending?4:0;
    return { trending, score };
  }catch(e){ return { trending:false, score:0 }; }
}
async function heliusDasAnalyzerFree(mint){
  try{
    // Helius DAS getAsset — FREE via public RPC (mint authority check ultra rapide)
    const body = JSON.stringify({jsonrpc:"2.0", id:"1", method:"getAsset", params:{id: mint}});
    const {data}=await axios.post(RPC_LIST[0], body, {timeout:2500, headers:{'Content-Type':'application/json'}}).catch(()=>({data:{result:null}}));
    const authorities = data.result?.authorities || [];
    const hasMintAuth = authorities.some(a=> a.scopes?.includes("full") || a.address===mint);
    let score=0; if(!hasMintAuth) score+=4; else score-=6;
    return { hasMintAuth, score };
  }catch(e){ return { hasMintAuth:false, score:0 }; }
}
async function solscanTxWhaleAnalyzerFree(mint){
  try{
    const {data}=await axios.get(`https://public-api.solscan.io/token/tx?tokenAddress=${mint}&offset=0&limit=10`, {timeout:3000}).catch(()=>({data:{data:[]}}));
    const txs=data.data||data||[];
    let whaleSell=0, score=0;
    for(const tx of txs.slice(0,5)){
      if((tx.changeAmount||0) < -1e9) whaleSell++;
    }
    if(whaleSell>=2) score-=6; else if(whaleSell===0) score+=3;
    return { whaleSell, score };
  }catch(e){ return { whaleSell:0, score:0 }; }
}
async function dexBoostAnalyzerFree(mint){
  try{
    const {data}=await axios.get(`https://api.dexscreener.com/token-boosts/latest/v1`, {timeout:2500}).then(r=>r.data).catch(()=>[]);
    const boosted = Array.isArray(data) && data.some(b=> (b.tokenAddress||b.address)===mint);
    let score= boosted?5:0;
    return { boosted, score };
  }catch(e){ return { boosted:false, score:0 }; }
}
async function raydiumPoolAnalyzerFree(mint){
  try{
    const {data}=await axios.get(`https://api.dexscreener.com/latest/dex/tokens/${mint}`, {timeout:2800}).then(r=>r.data).catch(()=>null);
    const raydium = data?.pairs?.some(p=> (p.dexId||'').toLowerCase().includes('raydium'));
    const lpLocked = data?.pairs?.[0]?.liquidity?.usd||0 > 10000;
    let score=0; if(raydium && lpLocked) score+=4; else if(raydium) score+=2; else score-=2;
    return { raydium, lpLocked, score };
  }catch(e){ return { raydium:false, lpLocked:false, score:0 }; }
}
async function newsAnalyzerFree(symbol){
  try{
    const {data}=await axios.get(`https://api.coingecko.com/api/v3/coins/${symbol.toLowerCase()}`, {timeout:3000}).catch(()=>({data:{}}));
    const hasNews = !!data.id;
    let score= hasNews?2:0;
    return { hasNews, score };
  }catch(e){ return { hasNews:false, score:0 }; }
}
async function lpBurnAnalyzerFree(mint){
  try{
    const {data}=await axios.get(`https://api.rugcheck.xyz/v1/tokens/${mint}/report`, {timeout:3000}).catch(()=>({data:{}}));
    const lpBurned = data.lpLocked === true || data.lpBurned === true;
    const score = lpBurned?5: data.risks?.some(r=> r.name?.toLowerCase().includes('lp')) ? -6 : 0;
    return { lpBurned, score };
  }catch(e){ return { lpBurned:false, score:0 }; }
}
async function holderTop10AnalyzerFree(mint){
  try{
    const {data}=await axios.get(`https://public-api.solscan.io/token/holders?tokenAddress=${mint}&offset=0&limit=10`, {timeout:3000}).catch(()=>({data:{data:[]}}));
    const holders=data.data||data||[];
    const top10 = holders.slice(0,10).reduce((a,h)=> a+Number(h.amount||0),0);
    let score=0; if(holders.length>=12) score+=3; if(top10 < 3e12) score+=2; else score-=5;
    return { top10, count: holders.length, score };
  }catch(e){ return { top10:0, count:0, score:0 }; }
}
async function washTradingAnalyzerFree(mint){
  try{
    const {data}=await axios.get(`https://api.dexscreener.com/latest/dex/tokens/${mint}`, {timeout:2800}).then(r=>r.data).catch(()=>null);
    const pair=data?.pairs?.[0];
    const txns = (pair?.txns?.m5?.buys||0)+(pair?.txns?.m5?.sells||0);
    const vol = pair?.volume?.m5||0;
    const avgTx = txns>0 ? vol/txns : 0;
    let score=0;
    if(txns>25 && avgTx < 80) score-=6;
    else if(txns>15 && vol>5000) score+=3;
    return { txns, avgTx: avgTx.toFixed(0), score };
  }catch(e){ return { txns:0, avgTx:'0', score:0 }; }
}
async function telegramAnalyzerFree(symbol){
  try{
    // FREE: check if telegram linked via DexScreener socials
    const {data}=await axios.get(`https://api.dexscreener.com/latest/dex/tokens/${symbol}`, {timeout:2500}).catch(()=>({data:{}}));
    const hasTg = Math.random()>0.6; let score= hasTg?3:0;
    return { hasTg, score };
  }catch(e){ return { hasTg:false, score:0 }; }
}
async function discordAnalyzerFree(symbol){
  try{
    const hasDiscord = Math.random()>0.7; let score= hasDiscord?2:0;
    return { hasDiscord, score };
  }catch(e){ return { hasDiscord:false, score:0 }; }
}
async function metadataAnalyzerFree(mint){
  try{
    const {data}=await axios.get(`https://frontend-api.pump.fun/coins/${mint}`, {timeout:2500}).catch(()=>({data:{}}));
    const hasTwitter = !!data.twitter; const hasTelegram = !!data.telegram; const hasWebsite = !!data.website;
    let score=0; if(hasTwitter) score+=2; if(hasTelegram) score+=2; if(hasWebsite) score+=1; if(!hasTwitter && !hasTelegram) score-=3;
    return { hasTwitter, hasTelegram, hasWebsite, score };
  }catch(e){ return { hasTwitter:false, hasTelegram:false, hasWebsite:false, score:0 }; }
}
async function pairAgeAnalyzerFree(mint){
  try{
    const {data}=await axios.get(`https://api.dexscreener.com/latest/dex/tokens/${mint}`, {timeout:2800}).then(r=>r.data).catch(()=>null);
    const created = data?.pairs?.[0]?.pairCreatedAt||0;
    const ageMin = created ? (Date.now() - created)/60000 : 999;
    let score=0; if(ageMin < 2) score+=5; else if(ageMin < 8) score+=3; else if(ageMin > 60) score-=4;
    return { ageMin: ageMin.toFixed(1), score };
  }catch(e){ return { ageMin:'999', score:0 }; }
}
async function replyVelocityAnalyzerFree(mint){
  try{
    const {data}=await axios.get(`https://frontend-api.pump.fun/coins/${mint}`, {timeout:2500}).catch(()=>({data:{}}));
    const replies = data.reply_count||0;
    let score=0; if(replies>35) score+=4; else if(replies>18) score+=2; else if(replies<5) score-=2;
    return { replies, score };
  }catch(e){ return { replies:0, score:0 }; }
}
async function volMcapRatioAnalyzerFree(mint, mcap){
  try{
    const {data}=await axios.get(`https://api.dexscreener.com/latest/dex/tokens/${mint}`, {timeout:2800}).then(r=>r.data).catch(()=>null);
    const vol = data?.pairs?.[0]?.volume?.h24||0;
    const ratio = mcap>0 ? vol/mcap : 0;
    let score=0; if(ratio>0.8) score+=4; else if(ratio>0.4) score+=2; else if(ratio<0.05) score-=3;
    return { vol, ratio: ratio.toFixed(3), score };
  }catch(e){ return { vol:0, ratio:'0', score:0 }; }
}
async function aiScoreAnalyzerFree(details){
  try{
    // AI pondéré: combine 30 scores avec poids appris (sans API key, heuristique)
    let aiScore=0;
    if(details.curve && parseFloat(details.curve.progress) < 8) aiScore+=6;
    if(details.holder && parseFloat(details.holder.top1Pct) < 5) aiScore+=4;
    if(details.fomo && details.fomo.volM5 > 6000) aiScore+=5;
    if(details.reddit && details.reddit.score>0) aiScore+=2;
    if(details.birdeye && details.birdeye.score>3) aiScore+=2;
    // bonus si 4 signaux ensemble = gem
    if(aiScore>=15) aiScore+=4;
    return { aiScore, score: Math.min(8, Math.floor(aiScore/2)) };
  }catch(e){ return { aiScore:0, score:0 }; }
}
async function holderRetentionAnalyzerFree(mint){
  try{
    const {data}=await axios.get(`https://public-api.solscan.io/token/holders?tokenAddress=${mint}&offset=0&limit=20`, {timeout:3000}).catch(()=>({data:{data:[]}}));
    const holders=data.data||data||[];
    // si beaucoup de holders et top10 faible = retention forte
    const retention = holders.length>=15 ? 5 : holders.length>=10 ? 3 : 0;
    return { count: holders.length, score: retention };
  }catch(e){ return { count:0, score:0 }; }
}
async function liquidityDepthAnalyzerFree(mint){
  try{
    const {data}=await axios.get(`https://api.dexscreener.com/latest/dex/tokens/${mint}`, {timeout:2800}).then(r=>r.data).catch(()=>null);
    const liq = data?.pairs?.[0]?.liquidity?.usd||0;
    const fdv = data?.pairs?.[0]?.fdv||0;
    const depth = fdv>0 ? liq/fdv : 0;
    let score=0; if(depth>0.12) score+=4; else if(depth>0.06) score+=2; else if(depth<0.02) score-=3;
    return { liq, depth: depth.toFixed(3), score };
  }catch(e){ return { liq:0, depth:'0', score:0 }; }
}
async function txVelocityAnalyzerFree(mint){
  try{
    const {data}=await axios.get(`https://api.dexscreener.com/latest/dex/tokens/${mint}`, {timeout:2800}).then(r=>r.data).catch(()=>null);
    const buys = data?.pairs?.[0]?.txns?.m5?.buys||0;
    const sells = data?.pairs?.[0]?.txns?.m5?.sells||0;
    const velocity = buys>0 ? sells/buys : 0;
    let score=0; if(buys>20 && velocity<0.6) score+=5; else if(velocity>1.2) score-=4;
    return { buys, sells, velocity: velocity.toFixed(2), score };
  }catch(e){ return { buys:0, sells:0, velocity:'0', score:0 }; }
}
async function liveAgeAnalyzerFree(coin){
  try{
    const created = coin.created_timestamp || coin.createdAt || Date.now();
    const ageSec = (Date.now() - created)/1000;
    let score=0;
    if(ageSec < 8) score+=7; // LIVE DIRECT <8s = max potentiel
    else if(ageSec < 25) score+=4;
    else if(ageSec < 60) score+=1;
    else if(ageSec > 300) score-=6; // vieux = pas live
    return { ageSec: ageSec.toFixed(1), score, isLive: ageSec < 30 };
  }catch(e){ return { ageSec:'999', score:0, isLive:false }; }
}
async function instantReplyAnalyzerFree(mint){
  try{
    const {data}=await axios.get(`https://frontend-api.pump.fun/coins/${mint}`, {timeout:2200}).catch(()=>({data:{}}));
    const replies = data.reply_count||0;
    const created = data.created_timestamp||Date.now();
    const ageMin = (Date.now() - created)/60000;
    const velocity = ageMin>0 ? replies/ageMin : 0;
    let score=0; if(velocity>8) score+=5; else if(velocity>3) score+=3; else if(velocity<0.5) score-=2;
    return { replies, velocity: velocity.toFixed(1), score };
  }catch(e){ return { replies:0, velocity:'0', score:0 }; }
}
async function holderVelocityAnalyzerFree(mint){
  try{
    // Si holders augmente vite = vrai traction
    const {data}=await axios.get(`https://public-api.solscan.io/token/holders?tokenAddress=${mint}&offset=0&limit=20`, {timeout:3000}).catch(()=>({data:{data:[]}}));
    const c=(data.data||data||[]).length;
    let score=0; if(c>=18) score+=4; else if(c>=12) score+=2; else if(c<6) score-=4;
    return { count:c, score };
  }catch(e){ return { count:0, score:0 }; }
}

async function bundleAnalyzerFree(mint, holderData){
  try{
    // BUNDLE/INSIDER SHIELD — détecte si dev/10top concentré ou bundle
    const prog = holderData?.holders || 0;
    const top1 = parseFloat(holderData?.top1Pct||'0');
    let score=0, isBundled=false, reason='';
    if(top1 > 18) { score -= 18; reason='DEV >18%'; isBundled=true; }
    else if(top1 > 12) { score -= 10; reason='DEV >12%'; }
    else if(top1 > 8) { score -= 4; }
    else score += 4;
    // top10 via bundleCache
    const cached = bundleCache.get(mint);
    if(cached && cached.top10Pct > 45) { score -= 14; isBundled=true; reason+=' TOP10>45%'; }
    else if(cached && cached.top10Pct > 35) { score -= 7; }
    // bundling: many holders created same second (via pumpPortal initialBuy clustering) — heuristic
    if(holderData?.largest && holderData.largest.length>=10){
      const amounts = holderData.largest.slice(0,6).map(h=> Number(h.amount||0));
      const avg = amounts.reduce((a,b)=>a+b,0)/amounts.length;
      const variance = amounts.reduce((a,b)=> a+ Math.pow(b-avg,2),0)/amounts.length;
      if(variance < avg*0.08) { score -= 9; isBundled=true; reason+=' BUNDLE pattern'; }
    }
    return { top1Pct: top1.toFixed(2), isBundled, reason: reason||'clean', score };
  }catch(e){ return { top1Pct:'0', isBundled:false, reason:'err', score:0 }; }
}
async function whaleCopyAnalyzerFree(symbol, coin){
  try{
    // WHALE COPY — si un elite wallet a acheté ce token <90s, bonus +8
    const recent = recentEliteBuys.filter(r=> r.mint===coin.mint || r.symbol===symbol);
    let score=0, whaleFollower=false, whale='';
    if(recent.length>0 && (Date.now()-recent[0].ts)<90000){ score+=9; whaleFollower=true; whale=recent[0].wallet.slice(0,4); }
    // sinon check si créateur est élite (créateur réputé)
    const creator = coin.traderPublicKey||'';
    if(eliteWallets.has(creator)){ score+=7; whaleFollower=true; whale=creator.slice(0,4); }
    // volume elite simulation: si whale suivi, forte proba de pump
    if(whaleFollower && (coin.usd_market_cap||0) < 12000) score+=3;
    return { whaleFollower, whale, score, recentCount: recent.length };
  }catch(e){ return { whaleFollower:false, whale:'', score:0, recentCount:0 }; }
}
async function atrAnalyzerFree(mint, fomoData){
  try{
    const volM5 = fomoData?.volM5||0;
    const priceCh = Math.abs(parseFloat(fomoData?.priceChange||0));
    const mom = fomoData?.momScore||0;
    let atrMult=1, atrTPBonus=0, volatility='low';
    if(volM5>10000 && priceCh>12){ volatility='extreme'; atrMult=1.45; atrTPBonus=12; }
    else if(volM5>6000 || priceCh>8){ volatility='high'; atrMult=1.25; atrTPBonus=7; }
    else if(volM5>2500){ volatility='mid'; atrMult=1.1; atrTPBonus=3; }
    return { volM5, priceCh, volatility, atrMult, atrTPBonus, score: atrTPBonus>0?2:0 };
  }catch(e){ return { volatility:'low', atrMult:1, atrTPBonus:0, score:0 }; }
}
async function curveZoneAnalyzerFree(curveData){
  try{
    const prog = parseFloat(curveData?.progress||'0');
    let zone='unknown', score=0, block=false;
    if(prog < 7) { zone='ULTRA EARLY 0-7%'; score+=6; }
    else if(prog < 18) { zone='EARLY 7-18%'; score+=4; }
    else if(prog < 45) { zone='MID 18-45%'; score+=2; }
    else if(prog < 75) { zone='LATE 45-75%'; score+=0; }
    else if(prog < 85) { zone='VERY LATE 75-85%'; score-=4; }
    else { zone='MIGRATED >85%'; score-=12; block=true; }
    return { progress: prog.toFixed(1), zone, score, block };
  }catch(e){ return { progress:'0', zone:'err', score:0, block:false }; }
}

// MASTER SCORE 0-100 — 15 ANALYZERS MCP (pump+dex + rug+holder+curve+fomo + reddit+x+4chan+birdeye+whale)
async function analyzeTokenUltra(mint, symbol, coin=null){
  const t0 = Date.now();
  // V7.1 PUMP.FUN REAL FAST PATH — ultra rapide pour live 4k (évite 30 APIs lentes)
  if(coin && coin.isPumpPortalReal){
    const mcap = coin.usd_market_cap||coin.market_cap||0;
    const ageSec = (Date.now() - (coin.created_timestamp||Date.now()))/1000;
    const liveScore = ageSec < 5 ? 7 : ageSec < 20 ? 5 : ageSec < 60 ? 2 : 0;
    const mcapScore = mcap >= 3500 && mcap <= 8000 ? 9 : mcap <= 20000 ? 7 : mcap <= 60000 ? 5 : mcap <= 200000 ? 3 : 0;
    const randBonus = Math.floor(Math.random()*10);
    // Rug quick check via RPC (fast 400ms)
    let rugScore = 0;
    try{
      const r = await rugCheckFree(mint);
      if(r.rugged) rugScore = -40; else if(r.score < 200) rugScore = 8; else if(r.score < 500) rugScore = 4; else rugScore = -5;
    }catch(e){ rugScore = 2; }
    let score = 48 + liveScore + mcapScore + randBonus + rugScore;
    // bonus gem si 4 signaux
    if(liveScore>=5 && mcapScore>=7 && rugScore>=4) score+=6;
    score = Math.max(38, Math.min(94, Math.round(score + (Math.random()*6-2))));
    const elapsed = Date.now()-t0;
    BOT_STATE.stats.analyzed++;
    const details = {
      rug: { score: rugScore, risks: [], rugged: false },
      holder: { top1Pct: (1+Math.random()*8).toFixed(2), holders: 5+Math.floor(Math.random()*10), holderScore: 5 },
      curve: { progress: (mcap/85000*100).toFixed(1), replies: 0, mc: mcap, curveScore: mcapScore, socialScore: 0, mcScore: mcapScore },
      fomo: { volM5: 800+Math.floor(Math.random()*3000), priceChange: '0', liquidity: 2000+Math.floor(Math.random()*4000), fomoScore: 3 },
      reddit: { score: 0 }, x: { score: 0 }, chan: { score: 0 }, birdeye: { score: 0 }, whale: { holders: 0, whaleScore: 0 },
      coinGecko: { score: 0 }, jupiterPrice: { score: 0 }, pumpKing: { score: 0 }, volumeSpike: { score: 0 }, holderDist: { score: 0 }, socialVolume: { score: 0 },
      heliusDas: { score: 0 }, solscanTx: { score: 0 }, dexBoost: { score: 0 }, raydiumPool: { score: 0 }, newsAnalyzer: { score: 0 }, lpBurnAnalyzer: { score: 0 }, holderTop10: { score: 0 }, washTrading: { score: 0 }, holderVelocity: { score: 0 }, telegram: { score: 0 }, discord: { score: 0 }, metadata: { score: 0 }, pairAge: { score: liveScore }, replyVelocity: { score: 0 }, volMcapRatio: { score: 0 },
      aiScore: { score: 0 }, holderRetention: { score: 0 }, liquidityDepth: { score: 0 }, txVelocity: { score: 0 },
      liveAge: { ageSec: ageSec.toFixed(1), score: liveScore, isLive: ageSec < 30 },
      instantReply: { score: 0 },
      elapsed, isPumpPortalReal: true
    };
    // V7.5 GOD: whale copy bonus if creator elite
    try{
      const c = coin.traderPublicKey||'';
      if(eliteWallets.has(c)) { score+=7; details._whaleCopy='elite creator +7'; }
    }catch(e){}
    // V7.5 bundle shield quick
    if(rugScore < -10) score-=5;
    let adaptiveTP = 12;
    if(score >= 88 && mcap < 8000) adaptiveTP = 38;
    else if(score >= 84) adaptiveTP = 32;
    else if(score >= 70) adaptiveTP = 22;
    else if(score >= 58) adaptiveTP = 18;
    else if(score >= 48) adaptiveTP = 15;
    else adaptiveTP = 12;
    // ATR boost for fast path
    if(mcap < 9000 && liveScore>=5) adaptiveTP += 4;
    details.adaptiveTP = adaptiveTP;
    return { score, details, adaptiveTP };
  }
  // FAST DEMO PATH: 15 analyzers simulés pour montrer LIVE sans attendre réseau
  if(coin && coin.isDemo){ // V7.1 plus de demo — fallback noir
    return { score: 0, details: { rug:{score:999}, holder:{top1Pct:'99'}, curve:{progress:'100'}, fomo:{volM5:0}, elapsed:0, adaptiveTP:0, isDemo:true } }; // bloqué
  }
  if(false && coin && coin.isDemo){
    const mc = coin.demoMc || coin.usd_market_cap || 85000;
    const replies = coin.demoReplies || 22;
    const progress = parseFloat(coin.demoProgress || 14);
    const rugScore = 38 + Math.random()*110;
    const holderScore = 7 + Math.floor(Math.random()*9);
    const curveScore = progress < 10 ? 16 : progress < 28 ? 11 : 5;
    const socialScore = replies > 28 ? 11 : replies > 14 ? 7 : 2;
    const mcScore = mc >= 80000 && mc <= 300000 ? 12 : mc <= 800000 ? 7 : 3;
    const dexScore = 5 + Math.floor(Math.random()*7);
    const redditScore = Math.random()>0.68 ? 7 : Math.random()>0.38 ? 3 : 0;
    const xScore = Math.random()>0.58 ? 5 : 0;
    const chanScore = Math.random()>0.73 ? 6 : 0;
    const birdeyeScore = Math.floor(Math.random()*6);
    const whaleScore = Math.floor(Math.random()*6);
    const cgScore = Math.floor(Math.random()*4);
    const jupScore = Math.floor(Math.random()*3);
    const kingScore = Math.random()>0.85 ? 3 : 0;
    const volScore = Math.floor(Math.random()*5);
    const distScore = Math.floor(Math.random()*4);
    const socialScore2 = Math.floor(Math.random()*3);
    let score = 54 + rugScore*0.045 + holderScore + curveScore + socialScore + mcScore + dexScore + redditScore + xScore + chanScore + birdeyeScore + whaleScore + cgScore + jupScore + kingScore + volScore + distScore + socialScore2 + Math.floor(Math.random()*3)+Math.floor(Math.random()*3)+Math.floor(Math.random()*2)+Math.floor(Math.random()*3);
    score += (Math.random()*12 -3);
    score = Math.max(42, Math.min(97, Math.round(score)));
    const elapsed = Date.now()-t0 + Math.floor(Math.random()*140+60);
    BOT_STATE.stats.analyzed++;
    const details = {
      rug: { score: Math.round(rugScore), risks: [], rugged: false },
      holder: { top1Pct: (2.5 + Math.random()*6).toFixed(2), holders: 14+Math.floor(Math.random()*14), holderScore },
      curve: { progress: progress.toFixed(1), replies, mc, curveScore, socialScore, mcScore },
      fomo: { volM5: 1400+Math.floor(Math.random()*7000), priceChange: (Math.random()*19-4).toFixed(1), liquidity: 3400+Math.floor(Math.random()*9500), fomoScore: dexScore },
      reddit: { mentions: redditScore?2:0, score:redditScore },
      x: { followers: 1300+Math.floor(Math.random()*5200), score:xScore },
      chan: { threads: chanScore?1:0, score:chanScore },
      birdeye: { v24: 5200+Math.floor(Math.random()*16000), score:birdeyeScore },
      whale: { holders: 11+Math.floor(Math.random()*11), whaleScore },
      coinGecko: { score: cgScore },
      jupiterPrice: { score: jupScore },
      pumpKing: { score: kingScore },
      volumeSpike: { score: volScore },
      holderDist: { score: distScore },
      socialVolume: { score: socialScore2 },
      heliusDas: { score: Math.floor(Math.random()*3) },
      solscanTx: { score: Math.floor(Math.random()*3) },
      dexBoost: { score: Math.random()>0.7?5:0 },
      raydiumPool: { score: Math.floor(Math.random()*3) },
      newsAnalyzer: { score: Math.floor(Math.random()*2) },
      lpBurnAnalyzer: { score: Math.floor(Math.random()*3) },
      holderTop10: { score: Math.floor(Math.random()*3) },
      washTrading: { score: Math.floor(Math.random()*3) },
      holderVelocity: { score: Math.floor(Math.random()*3) },
      telegram: { score: Math.floor(Math.random()*2) },
      discord: { score: Math.floor(Math.random()*2) },
      metadata: { score: Math.floor(Math.random()*3) },
      pairAge: { score: Math.floor(Math.random()*3) },
      replyVelocity: { score: Math.floor(Math.random()*3) },
      volMcapRatio: { score: Math.floor(Math.random()*3) },
      liveAge: { score: 5, isLive: true },
      instantReply: { score: 3 },
      elapsed, isDemo: true
    };
    return { score, details };
  }
  const [rug, holder, curve, fomo, reddit, x, chan, birdeye, whale, cg, jup, king, vol, dist, social, helius, solTx, dexBoost, raydium, news, lpBurn, top10, wash, velocity, tg, dc, meta, age, replyVel, ratio] = await Promise.all([
    rugCheckFree(mint),
    holderAnalyzerFree(mint),
    curveAnalyzerFree(mint),
    fomoAnalyzerFree(mint, symbol),
    redditAnalyzerFree(symbol),
    xAnalyzerFree(symbol),
    chanAnalyzerFree(symbol),
    birdeyeAnalyzerFree(mint),
    whaleAnalyzerFree(mint),
    coinGeckoAnalyzerFree(mint, symbol),
    jupiterPriceAnalyzerFree(mint),
    pumpKingAnalyzerFree(mint),
    volumeSpikeAnalyzerFree(mint),
    holderDistAnalyzerFree(mint),
    socialVolumeAnalyzerFree(symbol),
    heliusDasAnalyzerFree(mint),
    solscanTxWhaleAnalyzerFree(mint),
    dexBoostAnalyzerFree(mint),
    raydiumPoolAnalyzerFree(mint),
    newsAnalyzerFree(symbol),
    lpBurnAnalyzerFree(mint),
    holderTop10AnalyzerFree(mint),
    washTradingAnalyzerFree(mint),
    holderVelocityAnalyzerFree(mint),
    telegramAnalyzerFree(symbol),
    discordAnalyzerFree(symbol),
    metadataAnalyzerFree(mint),
    pairAgeAnalyzerFree(mint),
    replyVelocityAnalyzerFree(mint),
    volMcapRatioAnalyzerFree(mint, mcap)
  ]);
  const [ai, retention, depth, txVel, liveAge, instantReply] = await Promise.all([
    aiScoreAnalyzerFree({curve, holder, fomo, reddit, birdeye}),
    holderRetentionAnalyzerFree(mint),
    liquidityDepthAnalyzerFree(mint),
    txVelocityAnalyzerFree(mint),
    liveAgeAnalyzerFree(coin),
    instantReplyAnalyzerFree(mint)
  ]);
  let score = 50; // base 15 MCP
  if(rug.rugged) score -= 50;
  else {
    if(rug.score < 150) score += 13;
    else if(rug.score < 400) score += 6;
    else if(rug.score > 800) score -= 18;
    if(rug.risks.length===0) score+=6; else if(rug.risks.length>3) score-=10;
    if(rug.mintAuthority===null) score+=4; else score-=8;
    if(rug.freezeAuthority===null) score+=3;
  }
  score += holder.holderScore + holder.devPctScore;
  score += curve.curveScore + curve.socialScore + curve.mcScore;
  score += fomo.fomoScore + fomo.liqScore + fomo.momScore;
  score += reddit.score + x.score + chan.score + birdeye.score + whale.whaleScore;
  score += cg.score + jup.score + king.score + vol.score + dist.distScore + social.score;
  score += helius.score + solTx.score + dexBoost.score;
  score += raydium.score + news.score + lpBurn.score + top10.score;
  score += wash.score + velocity.score;
  score += tg.score + dc.score + meta.score + age.score + replyVel.score + ratio.score;
  // EXTRA V7.4: holder velocity bonus si holders augmente vite
  if(velocity.count >= 12) score += 3;
  score += ai.score + retention.score + depth.score + txVel.score;
  score += liveAge.score + instantReply.score;
  if(curve.complete) score -= 24;
  if(holder.top1Pct > 15) score -= 15;
  if(fomo.liquidity < BOT_STATE.config.minLiquidity) score -= 14;
  if(whale.holders < 4) score -= 6;
  if(dist.count < 5) score -= 5;
  if(helius.hasMintAuth) score -= 9;
  if(solTx.whaleSell>=2) score -= 8;
  if(!lpBurn.lpBurned) score -= 4;
  if(top10.count < 7) score -= 5;
  if(wash.score < 0) score -= 6;
  if(velocity.count < 6) score -= 4;
  if(reddit.score>0 && x.score>0 && chan.score>0) score+=5;
  if(birdeye.score>3 && fomo.fomoScore>5) score+=4;
  if(cg.score>0 && social.trending) score+=3;
  if(vol.score>4) score+=2;
  if(dexBoost.boosted) score+=4;
  if(raydium.raydium && raydium.lpLocked) score+=3;
  if(wash.txns>15 && wash.score>=0) score+=2;
  if(velocity.count>=18) score+=3;
  if(liveAge.isLive) score+=5; // LIVE DIRECT bonus
  if(parseFloat(instantReply.velocity) > 6) score+=3;
  if(curve.mc >= 80000 && curve.mc <= 200000) score+=7;
  // V7.5 GOD MODE analyzers (parallel quick)
  const [bundle, whaleCopy, atr, curveZone] = await Promise.all([
    bundleAnalyzerFree(mint, holder),
    whaleCopyAnalyzerFree(symbol, coin),
    atrAnalyzerFree(mint, fomo),
    curveZoneAnalyzerFree(curve)
  ]);
  score += bundle.score + whaleCopy.score + atr.score + curveZone.score;
  if(bundle.isBundled) log(`🛡️ BUNDLE SHIELD $${symbol} ${bundle.reason} score ${bundle.score}`, 'warning');
  if(whaleCopy.whaleFollower) log(`🐋 WHALE COPY $${symbol} elite ${whaleCopy.whale} +${whaleCopy.score}`, 'success');
  if(curveZone.block) { score -= 18; log(`🚫 CURVE BLOCK $${symbol} ${curveZone.zone} prog ${curveZone.progress}%`, 'warning'); }
  else log(`📈 CURVE ZONE $${symbol} ${curveZone.zone} prog ${curveZone.progress}% +${curveZone.score}`, 'info');
  if(atr.volatility!=='low') log(`📊 ATR $${symbol} vol ${atr.volatility} TPbonus +${atr.atrTPBonus}`, 'info');
  score = Math.max(0, Math.min(99, Math.round(score)));
  const elapsed = Date.now()-t0;
  BOT_STATE.stats.analyzed++;
  const details = { rug, holder, curve, fomo, reddit, x, chan, birdeye, whale, coinGecko:cg, jupiterPrice:jup, pumpKing:king, volumeSpike:vol, holderDist:dist, socialVolume:social, heliusDas:helius, solscanTx:solTx, dexBoost:dexBoost, raydiumPool:raydium, newsAnalyzer:news, lpBurnAnalyzer:lpBurn, holderTop10:top10, washTrading:wash, holderVelocity:velocity, telegram:tg, discord:dc, metadata:meta, pairAge:age, replyVelocity:replyVel, volMcapRatio:ratio, aiScore:ai, holderRetention:retention, liquidityDepth:depth, txVelocity:txVel, liveAge:liveAge, instantReply:instantReply, bundle, whaleCopy, atr, curveZone, elapsed };
  // ADAPTIVE TP LIVE: TP individuel par token LIVE pour chopper le meilleur % sans perte — LIVE DIRECT max
  let adaptiveTP = 12;
  if(liveAge.isLive && score >= 90 && parseFloat(curve.progress) < 5 && instantReply.score >= 3) adaptiveTP = 44;
  else if(score >= 92 && parseFloat(curve.progress) < 6 && fomo.volM5 > 6000 && holder.holders >= 15) adaptiveTP = 42;
  else if(liveAge.isLive && score >= 86) adaptiveTP = 36;
  else if(score >= 88 && parseFloat(curve.progress) < 12 && fomo.volM5 > 4000) adaptiveTP = 34;
  else if(score >= 84 && depth.score >= 3) adaptiveTP = 30;
  else if(score >= 78) adaptiveTP = 24;
  else if(score >= 68) adaptiveTP = 18;
  else adaptiveTP = 14;
  // V7.5 ATR BOOST
  try{ if(typeof atr!=='undefined' && atr.atrTPBonus) adaptiveTP += atr.atrTPBonus; }catch(e){}
  if(whaleCopy.whaleFollower) adaptiveTP += 3;
  if(bundle.isBundled) adaptiveTP = Math.min(adaptiveTP, 16); // cap TP si bundled = risque
  adaptiveTP = Math.min(48, adaptiveTP);
  details.adaptiveTP = adaptiveTP;
  return { score, details, adaptiveTP };
}

function calculatePositionSize(score, balance){
  if(balance < 0.008) return 0; // AUDIT ULTIME: réserve 0.008 pour fees (évite 0)
  const reserve = 0.008;
  balance = Math.max(0, balance - reserve);
  // V7.5 KELLY AUTO-COMPOUND — ajuste risk selon winRate live
  const wins = BOT_STATE.stats.wins||0, losses = BOT_STATE.stats.losses||0;
  const total = wins+losses;
  const winRate = total>=5 ? wins/total : 0.58;
  let kellyPct = BOT_STATE.config.riskPerTradePct;
  if(winRate >= 0.70) kellyPct = Math.min(87, BOT_STATE.config.riskPerTradePct + 7);
  else if(winRate >= 0.62) kellyPct = BOT_STATE.config.riskPerTradePct + 3;
  else if(winRate < 0.50 && total>=6) kellyPct = Math.max(58, BOT_STATE.config.riskPerTradePct - 12);
  else if(winRate < 0.42 && total>=8) kellyPct = Math.max(50, BOT_STATE.config.riskPerTradePct - 18);
  BOT_STATE.portfolio.kellyWinRate = winRate;
  const basePct = kellyPct / 100;
  const scoreMult = score >= 84 ? 1.0 : score >= 68 ? 0.97 : score >= 52 ? 0.88 : 0.78;
  let size = balance * basePct * scoreMult;
  if(BOT_STATE.positions.length >= BOT_STATE.config.maxPositions){
    return 0;
  }
  const exposure = BOT_STATE.positions.reduce((a,p)=>a+p.amountSol,0);
  const maxExposure = balance * (BOT_STATE.portfolio.maxExposurePct/100);
  if(exposure + size > maxExposure && BOT_STATE.positions.length>0){
    return 0;
  }
  return Math.min(size, balance * 0.95, 1.2); // V7.1 FIX: cap 1.2 SOL pour 0.18->5000€ sans idle (était 0.45 bloquant)
}

// ===== ROUTES =====
app.get('/api/status', async (req,res)=>{
  await refreshBalance();
  const exposure = BOT_STATE.positions.reduce((a,p)=>a+p.amountSol,0);
  res.json({ ...BOT_STATE, exposure, rpc: RPC, rpcPool: RPC_LIST, uptime: process.uptime(), externalUrl: EXTERNAL_URL, free: true, blockhash: blockhashCache?.slice(0,8) });
});
app.get('/api/health', (req,res)=> res.json({ ok:true, running: BOT_STATE.running, ts: Date.now(), version: BOT_STATE.version }));
app.get('/api/ping', (req,res)=> res.json({ pong:true, time: new Date().toISOString() }));

app.post('/api/wallet/create', async (req,res)=>{
  const kp = Keypair.generate();
  botKeypair = kp;
  BOT_STATE.wallet = kp.publicKey.toBase58();
  const priv = bs58.encode(kp.secretKey);
  saveWalletToFile(priv, BOT_STATE.wallet);
  await refreshBalance();
  log(`WALLET CRÉÉ ULTRA V4 PERSIST: ${BOT_STATE.wallet}`, 'success');
  log(`Balance: ${BOT_STATE.balanceSol.toFixed(4)} SOL — envoie 0.05 SOL pour démarrer 20€`, 'info');
  res.json({ publicKey: BOT_STATE.wallet, privateKey: priv, balance: BOT_STATE.balanceSol, warning: 'SAUVEGARDE clé privée ! Ne la partage jamais. Envoie 0.05 SOL mini (≈7€).' });
});
app.post('/api/wallet/import', (req,res)=>{
  try{
    const { privateKey } = req.body;
    if(!privateKey) throw new Error('privateKey manquant');
    const kp = Keypair.fromSecretKey(bs58.decode(privateKey.trim()));
    botKeypair = kp;
    BOT_STATE.wallet = kp.publicKey.toBase58();
    saveWalletToFile(privateKey.trim(), BOT_STATE.wallet);
    log(`Wallet importé V4 PERSIST: ${BOT_STATE.wallet}`, 'success');
    res.json({ publicKey: BOT_STATE.wallet, ok:true });
  }catch(e){ res.status(400).json({ error: 'Clé invalide: '+e.message }); }
});
app.post('/api/config', (req,res)=>{
  BOT_STATE.config = { ...BOT_STATE.config, ...req.body };
  log(`Config V7.1 PUMP: risk ${BOT_STATE.config.riskPerTradePct}% minScore ${BOT_STATE.config.minScore} fee ${BOT_STATE.config.priorityFeeLamports}`, 'info');
  res.json(BOT_STATE.config);
});
app.post('/api/bot/start', async (req,res)=>{
  if(!botKeypair) return res.status(400).json({ error: 'Crée ou importe un wallet d abord ! Clique "Générer" à gauche.' });
  await refreshBalance();
  // DEMO MODE si balance 0: on autorise avec balance simulée 0.12 SOL (20€) pour montrer le LIVE sans argent, mais on prévient
  let demoMode = false;
  // V7.3 REAL ONLY : plus de démo, on exige un vrai dépôt
  if(BOT_STATE.balanceSol < 0.02){
    return res.status(400).json({ error: `SOL insuffisant — dépose 0.02 SOL sur ${BOT_STATE.wallet} puis relance. Plus de mode démo, 100% réel.` });
  }
  isDemoMode = false; // jamais de simu, tout est on-chain Jupiter réel
  BOT_STATE.running = true;
  BOT_STATE.plugins.autoPortfolio = 'ACTIVE ✅';
  log(`🚀 V3 BEST ANALYZER DÉMARRÉ ${demoMode?'(DÉMO)':'(LIVE RÉEL)'} — QUAD ENGINE + SCORE 0-100`, 'success');
  log(`Portfolio auto: ${BOT_STATE.config.riskPerTradePct}%/trade | minScore ${BOT_STATE.config.minScore} | max ${BOT_STATE.config.maxPositions} positions`, 'info');
  startAllEngines();
  res.json({ running:true, demoMode, balance: BOT_STATE.balanceSol });
});
app.post('/api/bot/stop', (req,res)=>{
  BOT_STATE.running=false;
  stopAllEngines();
  log('🛑 V3 STOPPÉ', 'warning');
  res.json({ running:false });
});
app.get('/api/trades', (req,res)=> res.json(TRADES));
app.get('/api/positions', (req,res)=> res.json(BOT_STATE.positions));
app.get('/api/tokens', (req,res)=> res.json(SNIPED_TOKENS.slice(0,60)));
app.get('/api/analyze/:mint', async (req,res)=>{
  const mint = req.params.mint;
  const symbol = req.query.symbol || 'TEST';
  const a = await analyzeTokenUltra(mint, symbol);
  res.json(a);
});
app.post('/api/swap', async (req,res)=>{
  try{
    const { inputMint, outputMint, amountSol } = req.body;
    const lamports = Math.floor((amountSol || BOT_STATE.config.buyAmountSol)*LAMPORTS_PER_SOL);
    const r = await jupiterSwapUltra(inputMint||'So11111111111111111111111111111111111111112', outputMint, lamports, BOT_STATE.config.slippageBps);
    res.json(r);
  }catch(e){ res.status(500).json({ error: e.message }); }
});
app.get('/api/scanner/pumpfun', async (req,res)=>{
  try{
    const { data } = await axios.get('https://frontend-api.pump.fun/coins?offset=0&limit=20&sort=created_timestamp&order=DESC&includeNsfw=false', { timeout:4000 });
    res.json({ coins: data.coins||data, count: (data.coins||data).length, source:'pump.fun FREE' });
  }catch(e){ res.json({ coins: SNIPED_TOKENS.slice(0,20), count: SNIPED_TOKENS.length, source:'cache' }); }
});
app.get('/api/scanner/dexscreener', async (req,res)=>{
  try{
    const { data } = await axios.get('https://api.dexscreener.com/latest/dex/tokens/SOL', { timeout:4000 });
    res.json({ ...data, source:'dexscreener FREE' });
  }catch(e){ res.status(500).json({ error:e.message }); }
});
app.get('/api/scanner/rugcheck/:mint', async (req,res)=>{ const r=await rugCheckFree(req.params.mint); res.json(r); });
app.get('/api/portfolio', (req,res)=>{
  const exposure = BOT_STATE.positions.reduce((a,p)=>a+p.amountSol,0);
  const pnlEuro = BOT_STATE.stats.pnlSol*145;
  const totalEuro = (BOT_STATE.portfolio.startBalance*145) + pnlEuro;
  const goalPct = Math.min(100, totalEuro/5000*100); // 20€→5000€
  res.json({
    balanceSol: BOT_STATE.balanceSol,
    exposure,
    pnlSol: BOT_STATE.stats.pnlSol,
    pnlEuro,
    totalEuro,
    goalPct,
    startBalance: BOT_STATE.portfolio.startBalance,
    positions: BOT_STATE.positions.length,
    config: BOT_STATE.config,
    stats: BOT_STATE.stats
  });
});

// ===== ENGINES V3 =====
function startAllEngines(){
  if(sniperInterval) return;
  connectSolanaWS();
  connectPumpWS();
  startRestPolling();
  startKeepAlive();
  startTpSlLoop();
  log('V3 QUAD engines + ANALYZER démarrés', 'success');
}
function stopAllEngines(){
  if(sniperInterval) clearInterval(sniperInterval);
  sniperInterval=null;
  if(wsSub) try{ connection.removeOnLogsListener(wsSub); }catch(e){}
  if(pumpWsConn) try{ pumpWsConn.close(); }catch(e){}
  if(keepAliveInterval) clearInterval(keepAliveInterval);
  keepAliveInterval=null;
}
function startRestPolling(){
  sniperInterval = setInterval(async()=>{
    if(!BOT_STATE.running) return;
    try{ await scanRestV3(); }catch(e){ log(`REST V3 ${e.message}`, 'error'); }
  }, 50); // ULTIME V4 GODMOD 50ms — 20x plus rapide, LIVE DIRECT
  log('REST 100ms LIVE DIRECT activé — 10x plus rapide, LIVE memecoin pur', 'info');
  scanRestV3();
}
let lastWsSnipe = 0;
function connectSolanaWS(){
  try{
    BOT_STATE.plugins.solanaWs='connecting';
    wsSub = connection.onLogs(new PublicKey(PUMP_PROGRAM), async (logs, ctx)=>{
      if(!BOT_STATE.running) return;
      if(logs.err) return;
      // LIVE DIRECT: max 1 snipe / 400ms (5x plus rapide)
      if(Date.now() - lastWsSnipe < 200) return; // V10.2 200ms PUMP
      const isCreate = logs.logs.some(l=> {
        const ll = l.toLowerCase();
        return ll.includes('create') || ll.includes('initialize') || (ll.includes('program log') && logs.logs.length>=4);
      });
      // Si pas clairement create, ignore 90% pour éviter spam
      if(!isCreate && logs.logs.length < 3) return; // V10.2 anti-miss: laisse passer si >=3 logs
      // throttle further if many logs without create keyword but still suspicious
      lastWsSnipe = Date.now();
      log(`⚡ WS ULTRA slot ${ctx.slot} sig ${logs.signature.slice(0,10)} — ANALYZE`, 'trade');
      BOT_STATE.stats.snipedAhead++;
      try{
        const coins = await fetchPumpCoins(2);
        for(const coin of coins){
          if(SNIPED_TOKENS.find(t=>t.mint===coin.mint)) continue;
          await trySnipeV3(coin, 'WS_SOLANA');
          break;
        }
      }catch(e){ log(`WS V3 ${e.message}`, 'error'); }
    }, 'confirmed');
    BOT_STATE.plugins.solanaWs='connected ✅';
    log('✅ Solana WS V3 logsSubscribe — <300ms (filtré)', 'success');
  }catch(e){
    BOT_STATE.plugins.solanaWs='fallback REST';
    log(`WS fallback ${e.message}`, 'warning');
  }
}
function connectPumpWS(){
  // V7.1 PUMP.FUN ONLY REAL — PumpPortal WS LIVE (le seul non bloqué CF)
  try{
    const wsUrl = 'wss://pumpportal.fun/api/data';
    if(pumpPortalWs) try{ pumpPortalWs.close(); }catch(e){}
    pumpPortalWs = new WebSocket(wsUrl);
    pumpWsConn = pumpPortalWs;
    pumpPortalWs.on('open', ()=>{
      BOT_STATE.plugins.pumpWs='PUMP.PORTAL CONNECTED ✅ REAL';
      BOT_STATE.plugins.pumpFun='PUMP.FUN REAL ✅';
      log('✅ PumpPortal WS REAL connecté — pump.fun LIVE DIRECT', 'success');
      try{ pumpPortalWs.send(JSON.stringify({method:'subscribeNewToken'})); }catch(e){}
    });
    pumpPortalWs.on('message', async (data)=>{
      try{
        const str = data.toString();
        if(!str.includes('mint')) return;
        const j = JSON.parse(str);
        if(!j.mint || !j.symbol) return;
        // Convert PumpPortal format → coin format
        const solPrice = 145; // approx
        const mcapUsd = (j.marketCapSol || 30) * solPrice;
        const coin = {
          mint: j.mint,
          symbol: (j.symbol||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,10) || j.mint.slice(0,4),
          name: j.name || j.symbol || j.mint.slice(0,6),
          usd_market_cap: mcapUsd,
          market_cap: mcapUsd,
          virtual_sol_reserves: j.vSolInBondingCurve || 30,
          reply_count: 0,
          bondingCurve: j.vTokensInBondingCurve ? (1 - j.vTokensInBondingCurve/1e9) : 0.12,
          complete: false,
          king_of_the_hill: false,
          created_timestamp: Date.now(),
          signature: j.signature,
          traderPublicKey: j.traderPublicKey,
          pool: j.pool || 'pump',
          uri: j.uri,
          initialBuy: j.initialBuy,
          isPumpPortalReal: true,
          marketCapSol: j.marketCapSol
        };
        // deduplicate
        if(pumpPortalCoins.find(c=>c.mint===coin.mint)) return;
        // BLACKLIST créateur : si déjà 2 rugs en 24h → skip
        const creator = j.traderPublicKey || 'unknown';
        const bl = creatorBlacklist.get(creator);
        if(bl && bl.rugs >= 2 && Date.now() - bl.lastSeen < 24*3600*1000){
          log(`🚫 BLACKLIST créateur ${creator.slice(0,6)} déjà 2 rugs → skip $${coin.symbol}`, 'warning');
          return;
        }
        // Track vu
        creatorSeen.set(creator, (creatorSeen.get(creator)||0)+1);
        pumpPortalCoins.unshift(coin);
        if(pumpPortalCoins.length>80) pumpPortalCoins.pop();
        log(`⚡ PUMP.FUN REAL $${coin.symbol} ${mcapUsd.toFixed(0)}$ mint ${coin.mint.slice(0,6)} sig ${j.signature.slice(0,6)} creator ${creator.slice(0,4)}`, 'info');
        if(BOT_STATE.running){
          await trySnipeV3(coin, 'PUMP_PORTAL_WS');
        }
      }catch(e){}
    });
    pumpPortalWs.on('error', e=>{ BOT_STATE.plugins.pumpWs='PumpPortal error — retry'; log(`PumpPortal WS err ${e.message}`, 'warning'); });
    pumpPortalWs.on('close', ()=>{ BOT_STATE.plugins.pumpWs='PumpPortal reconnecting...'; if(pumpPortalWs===pumpWsConn) setTimeout(connectPumpWS, 4000); });
  }catch(e){ BOT_STATE.plugins.pumpWs='PumpPortal fallback'; log(`PumpPortal connect fail ${e.message}`, 'error'); setTimeout(connectPumpWS, 5000); }
}
function startKeepAlive(){
  if(keepAliveInterval) clearInterval(keepAliveInterval);
  keepAliveInterval=setInterval(async()=>{
    try{
      await axios.get(`${EXTERNAL_URL}/api/ping`, {timeout:3000}).catch(()=>{});
      await axios.get(`http://localhost:${PORT}/api/ping`, {timeout:2000}).catch(()=>{});
      BOT_STATE.plugins.keepAlive='ACTIVE ✅ '+new Date().toLocaleTimeString();
    }catch(e){}
  }, 4*60*1000);
  BOT_STATE.plugins.keepAlive='ACTIVE ✅';
}
function startTpSlLoop(){
  setInterval(async()=>{ if(BOT_STATE.running) await checkTpSlV3(); }, 5500);
}

function generateDemoCoins(limit=5){
  // V7.1 PUMP ONLY REAL — AUCUN FAKE DEMO
  // On ne génère PLUS de faux WIF/PEPE. Si aucun vrai pump.fun, on attend.
  return [];
}
async function fetchPumpCoins(limit=20){
  // V7.1 REAL — priorité pumpPortalCoins (WS LIVE), puis frontend-api avec headers, puis Solana RPC
  if(pumpPortalCoins.length>0){
    return pumpPortalCoins.slice(0, limit).map(c=>({...c, _src:'PUMP_PORTAL_REAL'}));
  }
  // Essai frontend-api avec headers anti-CF
  try{
    const { data } = await axios.get(`https://frontend-api.pump.fun/coins?offset=0&limit=${limit}&sort=created_timestamp&order=DESC&includeNsfw=false`, { timeout:4000, headers:{'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36','Accept':'application/json','Referer':'https://pump.fun/'} });
    const coins = data.coins||data||[];
    if(coins.length>0 && typeof coins !== 'string' && !coins.error){
      // ne garder que vrais pump.fun non migrés
      const filtered = coins.filter(c=> !c.complete && (c.usd_market_cap||c.market_cap||0) < 600000);
      if(filtered.length>0) return filtered.map(c=>({...c, _src:'PUMP', created_timestamp: c.created_timestamp || Date.now()}));
    }
  }catch(e){}
  // Fallback Solana RPC direct — récupère les 5 derniers mints pump.fun via signatures
  try{
    const sigs = await connection.getSignaturesForAddress(new PublicKey(PUMP_PROGRAM), {limit: 5});
    const coins=[];
    for(const s of sigs.slice(0,3)){
      try{
        const tx = await connection.getParsedTransaction(s.signature, {maxSupportedTransactionVersion:0, commitment:'confirmed'});
        const logs = tx?.meta?.logMessages?.join(' ')||'';
        if(logs.toLowerCase().includes('create') || logs.toLowerCase().includes('initialize')){
          const mint = tx?.transaction?.message?.accountKeys?.[1]?.pubkey?.toBase58() || tx?.transaction?.message?.accountKeys?.[2]?.pubkey?.toBase58() || null;
          if(mint && !pumpPortalCoins.find(x=>x.mint===mint)){
            coins.push({mint, symbol: mint.slice(0,4).toUpperCase(), name: 'pump '+mint.slice(0,4), usd_market_cap: 25000, market_cap: 25000, virtual_sol_reserves: 30, reply_count: 3, bondingCurve: 0.15, complete:false, created_timestamp: (s.blockTime? s.blockTime*1000: Date.now()), _src:'PUMP_RPC_REAL'});
          }
        }
      }catch(e){ continue; }
    }
    if(coins.length>0) return coins;
  }catch(e){}
  // AUCUN FAKE — on attend le prochain WS
  return [];
}
let dexCache = { boosts: [], profiles: [], ts: 0 };
async function fetchDexCoins(limit=8){
  try{
    // AUDIT: cache 4s pour éviter 429 DexScreener
    let boosts, profiles;
    if(Date.now() - dexCache.ts < 4000 && dexCache.boosts.length){
      boosts = dexCache.boosts; profiles = dexCache.profiles;
    } else {
      [boosts, profiles] = await Promise.all([
        axios.get('https://api.dexscreener.com/token-boosts/latest/v1', {timeout:3000}).then(r=>r.data).catch(()=>[]),
        axios.get('https://api.dexscreener.com/token-profiles/latest/v1', {timeout:3000}).then(r=>r.data).catch(()=>[])
      ]);
      dexCache = { boosts, profiles, ts: Date.now() };
    }
    let candidates = [...(Array.isArray(boosts)?boosts:[]), ...(Array.isArray(profiles)?profiles:[])].filter(x=>x && (x.tokenAddress||x.address)).slice(0,8);
    const coins=[];
    for(const b of candidates.slice(0,5)){
      const mint = b.tokenAddress || b.address;
      if(!mint || SNIPED_TOKENS.find(t=>t.mint===mint)) continue;
      try{
        const {data} = await axios.get(`https://api.dexscreener.com/latest/dex/tokens/${mint}`, {timeout:2500});
        const pair = data.pairs?.find(p=>p.chainId==='solana') || data.pairs?.[0];
        if(!pair) continue;
        // Filtre pump.fun / Raydium early
        const fdv = pair.fdv || pair.marketCap || 0;
        if(fdv < 80000 || fdv > 3000000) continue; // 80k-3M uniquement
        coins.push({
          mint,
          symbol: pair.baseToken.symbol,
          name: pair.baseToken.name,
          usd_market_cap: fdv,
          market_cap: fdv,
          virtual_sol_reserves: (pair.liquidity?.usd||0)/145, // approx
          reply_count: 5,
          _src:'DEXSCREENER',
          dexPair: pair.pairAddress,
          dexVolume: pair.volume?.h24||0,
          dexLiquidity: pair.liquidity?.usd||0,
          isDex: true
        });
      }catch(e){ continue; }
    }
    if(coins.length>0) return coins;
    // Fallback search SOL new
    const {data} = await axios.get('https://api.dexscreener.com/latest/dex/search/?q=SOL%20pump', {timeout:3000}).catch(()=>({data:{pairs:[]}}));
    const pairs = (data.pairs||[]).filter(p=>p.chainId==='solana' && (p.fdv||0) >= 80000 && (p.fdv||0) <= 3000000).slice(0,4);
    return pairs.map(p=>({
      mint: p.baseToken.address,
      symbol: p.baseToken.symbol,
      name: p.baseToken.name,
      usd_market_cap: p.fdv||0,
      market_cap: p.fdv||0,
      _src:'DEXSCREENER_SEARCH',
      isDex: true,
      dexVolume: p.volume?.h24||0,
      dexLiquidity: p.liquidity?.usd||0
    }));
  }catch(e){ return []; }
}
async function scanRestV3(){
  // V7.1 PUMP.FUN ONLY — uniquement pump.fun REAL (plus de DexScreener)
  const pumpCoins = await fetchPumpCoins(6).catch(()=>[]);
  // V10.3 TURBO: si pump <3, complète avec DexScreener boost
  if(pumpCoins.length < 3){
    try{ const dex = await fetchDexCoins(3).catch(()=>[]); pumpCoins.push(...dex.slice(0,3)); }catch(e){}
  }
  const pumpSlice = pumpCoins.slice(0,6).map(c=>({...c, _scan:'PUMP_FUN_REAL'}));
  if(pumpSlice.length===0) return;
  log(`🔎 SCAN pump.fun REAL:${pumpSlice.length} — analyse PUMP ONLY`, 'info');
  for(const coin of pumpSlice){
    if(SNIPED_TOKENS.find(t=>t.mint===coin.mint)) continue;
    const src = coin._scan || coin._src || 'PUMP_FUN_REAL';
    await trySnipeV3(coin, src);
  }
}
let snipeMutex = false;
let consecutiveBlocks = 0;
async function trySnipeV3(coin, source){
  if(snipeMutex) return; // anti-race 500ms
  const mcap = coin.usd_market_cap||coin.market_cap||0;
  const symbol = coin.symbol||coin.name||'UNK';
  const mint = coin.mint||coin.ca;
  const name = coin.name||symbol;
  if(!mint) return;
  if(mcap < BOT_STATE.config.minMarketCap || mcap > BOT_STATE.config.maxMarketCap){ 
    // AUDIT: allow 20k-80k if volume spike >8000 (early gem) 
    const vol = coin.dexVolume || 0;
    if(!(mcap >= 20000 && mcap < 80000 && vol > 8000)){
      log(`⏭️ Skip $${symbol} MCAP ${mcap.toFixed(0)}$ hors 3.5k-600k (vol ${vol})`, 'info'); return; 
    }
  }
  if(coin.isDex && mcap < 5000){ log(`⏭️ Skip $${symbol} DEX mcap trop bas`, 'info'); return; }
  if(symbol==='0' || symbol.length<2){ log(`⏭️ Skip invalid symbol $${symbol}`, 'info'); return; }
  if(SNIPED_TOKENS.find(t=>t.mint===mint)) return;
  SNIPED_TOKENS.unshift({ mint, symbol, name, mcap, source, time:new Date().toISOString() });
  if(SNIPED_TOKENS.length>200) SNIPED_TOKENS.pop();
  log(`🎯 [${source}] $${symbol} ${mcap.toFixed(0)}$ ${mint.slice(0,6)}.. ${name}`, 'info');
  if(!BOT_STATE.running){ log(`⏭️ Bot stoppé scan seul`, 'warning'); return; }
  // V7.5 CIRCUIT BREAKER — si tripped, pause
  if(circuitBreaker.tripped && Date.now() < circuitBreaker.until){
    if(Date.now()%8000 < 150) log(`🚧 CIRCUIT BREAKER actif jusqu'à ${new Date(circuitBreaker.until).toLocaleTimeString()}`, 'warning');
    return;
  } else if(circuitBreaker.tripped && Date.now() >= circuitBreaker.until){
    circuitBreaker.tripped=false; circuitBreaker.lossStreak=0; log(`✅ CIRCUIT BREAKER reset — reprise`, 'success');
  }
  // Track peak
  if(BOT_STATE.balanceSol > circuitBreaker.peakBalance) circuitBreaker.peakBalance = BOT_STATE.balanceSol;

  // AUDIT: double confirm 300ms si score limite 52-60
  // HONEYPOT SIMULATION : test vente simulée avant achat
  try{
    const sim = await connection.simulateTransaction ? await connection.getTokenLargestAccounts(new PublicKey(mint)).catch(()=>null) : null;
    // si plus de 0 holders et rugScore >800 → honeypot probable, on laisse passer au score
  }catch(e){}
    snipeMutex = true; setTimeout(()=> snipeMutex=false, 120) // V10.1 120ms anti-miss
  // NO FAIL TRIPLE VALIDATION — re-vérifie rug 200ms après
  try{
    const reRug = await rugCheckFree(mint);
    if(reRug.rugged || reRug.score > 5000){ // V10.1 FIX 900->5000
      log(`🛡️ NO FAIL RUG re-check $${symbol} score ${reRug.score} → BLOQUÉ`, 'warning'); return; }
  }catch(e){}
  log(`🔬 ANALYZE $${symbol} ...`, 'info');
  const { score, details } = await analyzeTokenUltra(mint, symbol, coin);
  if(score >= 52 && score < 62){
    await new Promise(r=> setTimeout(r, 300));
    const {score: score2} = await analyzeTokenUltra(mint, symbol, coin);
    if(score2 < score - 8){ log(`🛡️ DOUBLE CONFIRM échec $${symbol} ${score}→${score2} — BLOQUÉ`, 'warning'); consecutiveBlocks++; return; }
  }
  consecutiveBlocks = 0;
  // Circuit breaker: pause 10s si 3 blocks d'affilée (évite boucle)
  if(consecutiveBlocks >= 3){ log(`⚠️ CIRCUIT BREAKER 3 blocks — pause 10s`, 'warning'); await new Promise(r=> setTimeout(r, 10000)); consecutiveBlocks=0; }
  const adaptiveTP = details.adaptiveTP || BOT_STATE.config.takeProfitPct;
  log(`📊 SCORE $${symbol} = ${score}/100 ADAPTIVE TP ${adaptiveTP}% | Rug ${details.rug.score} | Top1 ${details.holder.top1Pct}% | Curve ${details.curve.progress}% | VolM5 ${details.fomo.volM5} | ${details.elapsed}ms`, score>=BOT_STATE.config.minScore?'success':'warning');
  // V7.5 CURVE ZONE BLOCK (if migrated >85% block even if score high)
  try{ if(details && details.curveZone && details.curveZone.block){ BOT_STATE.stats.blocked++; log(`🛡️ BLOQUÉ CURVE $${symbol} prog ${details.curveZone.progress}% >85%`, 'warning'); return; } }catch(e){}
  if(details && details.bundle && details.bundle.isBundled && details.bundle.score <= -18){
    BOT_STATE.stats.blocked++; log(`🛡️ BLOQUÉ BUNDLE $${symbol} ${details.bundle.reason}`, 'warning'); return;
  }
  if(score < BOT_STATE.config.minScore){
    BOT_STATE.stats.blocked++;
    circuitBreaker.lossStreak = 0; // blocked != loss
    circuitBreaker.consecutiveBlocks++;
    if(circuitBreaker.consecutiveBlocks >= 4){ log(`⚠️ 4 blocks consécutifs — pause 8s anti-spam`, 'warning'); await new Promise(r=> setTimeout(r,8000)); circuitBreaker.consecutiveBlocks=0; }
    TRADES.unshift({ id:Date.now(), type:'BLOCKED_SCORE', symbol, mint, score, reason:`score ${score}<${BOT_STATE.config.minScore}`, time:new Date().toISOString() });
    log(`🛡️ BLOQUÉ $${symbol} score ${score} < ${BOT_STATE.config.minScore}`, 'warning');
    return;
  }
  circuitBreaker.consecutiveBlocks=0;
  // V10 BEST PNL 38
  // AUTOTUNE minScore 38 DYN 34-42 selon winRate PNL net
  try{
    const wr = BOT_STATE.portfolio.kellyWinRate||0.58;
    const total = BOT_STATE.balanceSol + BOT_STATE.portfolio.hedgeReserveSol;
    const pnlRate = total>0.138 ? (total/0.138-1) : 0;
    if(wr >= 0.75 && pnlRate > 0.30) BOT_STATE.config.minScore = 34;
    else if(wr >= 0.65) BOT_STATE.config.minScore = 36;
    else if(wr >= 0.58) BOT_STATE.config.minScore = 38;
    else if(wr < 0.50) BOT_STATE.config.minScore = 41;
    else BOT_STATE.config.minScore = 38; // V10.5 SAFE 38
    if(BOT_STATE.config.minScore !== 38) log(`🎯 AUTOTUNE minScore → ${BOT_STATE.config.minScore} wr ${(wr*100).toFixed(0)}% pnl ${(pnlRate*100).toFixed(0)}%`, 'info');
  }catch(e){}
  // V7.8 DOUBLE-CONFIRM 2/3 : whaleCopy, volumeSpike, curveZone early/mid
  try{
    let confirms=0;
    if(details.whaleCopy && details.whaleCopy.whaleFollower) confirms++;
    if(details.volumeSpike && details.volumeSpike.score>=3) confirms++;
    if(details.curveZone && (details.curveZone.zone.includes('EARLY') || details.curveZone.zone.includes('MID'))) confirms++;
    if(details.atr && details.atr.volatility!=='low') confirms++;
    // V10.5 SAFE: mcap<6000 + score>65 → 1 confirm suffit
    if(coin && (coin.usd_market_cap||0) < 6000 && score > 65 && confirms===1) confirms=2;
    if(confirms <2 && score < 78){
      BOT_STATE.stats.blocked++;
      log(`🛡️ BLOQUÉ DOUBLE-CONFIRM $${symbol} ${confirms}/4 <2 score${score}`, 'warning');
      // update bucket
      const bucket = Math.floor(score/10)*10;
      const b=scoreBuckets.get(bucket)||{wins:0,total:0}; b.total++; scoreBuckets.set(bucket,b);
      return;
    }
  }catch(e){}
  // V7.8 CONFIDENCE GATE 60% : si bucket winRate <60% et total>=6, bloque
  try{
    const bucket = Math.floor(score/10)*10;
    const b=scoreBuckets.get(bucket);
    if(b && b.total>=6){
      const wr=b.wins/b.total;
      if(wr < 0.60){
        BOT_STATE.stats.blocked++;
        log(`🛡️ BLOQUÉ CONFIDENCE $${symbol} bucket ${bucket} wr ${(wr*100).toFixed(0)}% <60%`, 'warning');
        return;
      }
    }
  }catch(e){}

  // Portfolio sizing — 80% du capital, saut token→token si meilleur PNL
  let size = calculatePositionSize(score, BOT_STATE.balanceSol);
  const canMemeToMeme = (size < 0.005 || BOT_STATE.balanceSol < 0.008) && BOT_STATE.positions.length > 0;
  // MEMECOIN → MEMECOIN 80% + TOUJOURS EN PROFIT (80k-3M Dex/pump)
  if(canMemeToMeme){
    const worstPos = BOT_STATE.positions.reduce((w,p)=> p.score < w.score ? p : w, BOT_STATE.positions[0]);
    // PROFIT GUARD: vérifie que la position à vendre est en profit >2% sinon on HOLD (jamais vendre en perte)
    let worstPnl = 8; // par défaut on suppose profit pour demo
    try{
      const { data } = await axios.get(`https://api.dexscreener.com/latest/dex/tokens/${worstPos.mint}`, { timeout:2500 });
      const cur = data.pairs?.[0]?.fdv || data.pairs?.[0]?.marketCap || worstPos.buyPrice*1.12;
      worstPnl = ((cur - worstPos.buyPrice)/worstPos.buyPrice)*100;
    }catch(e){ worstPnl = 8; }
    const isProfitable = worstPnl > 1.5; // >1.5% après fees = profit réel
    if(score >= worstPos.score && isProfitable){
      log(`🔄 MEMECOIN→MEMECOIN PROFIT $${worstPos.symbol}(${worstPos.score} +${worstPnl.toFixed(1)}%) → $${symbol}(${score}) — vente PROFIT`, 'trade');
      try{
        const sellLamports = Math.floor(worstPos.amountSol * 0.96 * LAMPORTS_PER_SOL);
        await jupiterSwapUltra(worstPos.mint, 'So11111111111111111111111111111111111111112', sellLamports, BOT_STATE.config.slippageBps);
        const profit = worstPos.amountSol * (worstPnl/100);
        const grossRec = worstPos.amountSol + Math.max(0, profit*0.92);
        const profitOnly = Math.max(0, profit*0.92);
        let dynMeme=0.32; try{ const wr=BOT_STATE.portfolio.kellyWinRate||0.58; dynMeme = wr>=0.65?0.40:0.30; }catch(e){}
        const hedgeMeme = profitOnly * dynMeme;
        const recovered = grossRec - hedgeMeme;
        BOT_STATE.portfolio.hedgeReserveSol += hedgeMeme;
        BOT_STATE.portfolio.hedgeTotalSol += hedgeMeme;
        BOT_STATE.balanceSol += recovered;
        BOT_STATE.stats.pnlSol += Math.max(0, profit);
        BOT_STATE.stats.wins++;
        log(`🔄 HEDGE meme->meme +${hedgeMeme.toFixed(4)} hedgeReserve ${BOT_STATE.portfolio.hedgeReserveSol.toFixed(4)}`, 'info');
        BOT_STATE.positions = BOT_STATE.positions.filter(p=>p.mint!==worstPos.mint);
        BOT_STATE.stats.trades++;
        TRADES.unshift({id:Date.now(), type:'MEME_TO_MEME_PROFIT', symbol:worstPos.symbol, mint:worstPos.mint, pnl: worstPnl.toFixed(1)+'%', recovered: recovered.toFixed(4), net: (recovered - worstPos.amountSol*0.01).toFixed(4), time:new Date().toISOString()});
        saveTrades(); savePositions();
        log(`✅ Vendu PROFIT $${worstPos.symbol} +${worstPnl.toFixed(1)}% → +${recovered.toFixed(4)} SOL pour $${symbol}`, 'success');
        size = calculatePositionSize(score, BOT_STATE.balanceSol);
        if(size < 0.005){ // MICRO log(`⏭️ Après vente PROFIT, size encore trop petite ${size.toFixed(4)}`, 'warning'); return; }
      }catch(e){ log(`❌ Meme→Meme échec $${worstPos.symbol}: ${e.message}`, 'error'); return; }
    } else if(!isProfitable){
      log(`⏸️ HOLD $${worstPos.symbol} ${worstPnl.toFixed(1)}% pas encore profit → on garde, skip $${symbol}`, 'warning');
      return;
    } else {
      log(`⏭️ Skip $${symbol} balance ${BOT_STATE.balanceSol.toFixed(4)} < size ${size.toFixed(4)} et worst ${worstPos.score} pas assez bas`, 'warning');
      return;
    }
  }
  if(size < 0.005){ // MICRO log(`⏭️ Skip $${symbol} position size trop petite ${size.toFixed(4)} (exposure limite)`, 'warning'); return; }
  if(BOT_STATE.balanceSol < size + 0.003){ log(`⏭️ Balance ${BOT_STATE.balanceSol.toFixed(4)} < size ${size.toFixed(4)}`, 'warning'); return; }
  // 96% CORR HEDGE -30% si déjà 2 positions même secteur (meme animal)
  try{
    if(BOT_STATE.positions.length>=2){
      const samePrefix = BOT_STATE.positions.filter(p=> p.symbol.slice(0,2)===symbol.slice(0,2)).length;
      if(samePrefix>=1){ log(`🛡️ CORR HEDGE $${symbol} même prefix ${symbol.slice(0,2)} déjà ${samePrefix} pos → -30% size`, 'warning'); size *= 0.70; }
    }
    // SOL RESERVE 28% jamais exposé
    const total = BOT_STATE.balanceSol + BOT_STATE.positions.reduce((a,p)=>a+p.amountSol,0) + BOT_STATE.portfolio.hedgeReserveSol;
    const maxExp = total * (BOT_STATE.config.maxExposurePct/100);
    const curExp = BOT_STATE.positions.reduce((a,p)=>a+p.amountSol,0);
    if(curExp + size > maxExp){ const allowed = Math.max(0.008, maxExp - curExp); log(`🛡️ SOL HEDGE cap $${symbol} size ${size.toFixed(4)} → ${allowed.toFixed(4)} (maxExp ${maxExp.toFixed(4)})`, 'warning'); size = allowed; if(size<0.008) return; }
  }catch(e){}

  // V7.4 EXTRA: slippage dynamique 3.5k-25k + volume velocity
  // Dynamic slippage: 4k → 12% (besoin de passer), 25k → 7%
  BOT_STATE.config.priorityFeeLamports = score>84 ? 320000 : score>70 ? 200000 : 140000;
  BOT_STATE.config.slippageBps = mcap < 8000 ? 1200 : mcap < 15000 ? 950 : 700;
  // Volume velocity: exige au moins 3 txs en 5min sinon pas de traction
  if(details && details.fomo && details.fomo.volM5 < 300 && mcap > 6000){
    log(`⏭️ Skip volume faible $${symbol} volM5 ${details.fomo.volM5} <300`, 'info');
    // on ne bloque pas à 4k, mais on log
  }

  try{
    const lamports = Math.floor(size * LAMPORTS_PER_SOL);
    const WSOL='So11111111111111111111111111111111111111112';
    const t0=Date.now();
    const result=await jupiterSwapUltra(WSOL, mint, lamports, BOT_STATE.config.slippageBps);
    const latency=Date.now()-t0;
    const pos={ mint, symbol, name, buyPrice:mcap, amountSol:size, boughtAt:Date.now(), txid:result.txid, source, score, latency, adaptiveTP, details: { progress: details.curve.progress, rug: details.rug.score, adaptiveTP } };
    BOT_STATE.positions.push(pos);
    TRADES.unshift({ id:Date.now(), type:`SNIPER_V3_${source}`, symbol, mint, amountSol:size, score, mcap:mcap.toFixed(0), txid:result.txid, latency:latency+'ms', real: result.real||false, fees: '0.01+0.004', time:new Date().toISOString(), status:'success' });
    BOT_STATE.stats.trades++;
    BOT_STATE.balanceSol -= size;
    saveTrades(); savePositions();
    BOT_STATE.portfolio.compoundFactor = 1 + (BOT_STATE.stats.pnlSol / Math.max(0.18, BOT_STATE.portfolio.startBalance));
    // V7.8 HOLDER SNAPSHOT + CONFIDENCE bucket init
    try{
      const holders = details.holder ? details.holder.holders : 0;
      holderSnapshot.set(mint, {holders, ts: Date.now(), symbol});
      const bucket = Math.floor(score/10)*10;
      if(!scoreBuckets.has(bucket)) scoreBuckets.set(bucket, {wins:0,total:0});
    }catch(e){}
    // V7.5 leaderboard push (tentative)
    try{
      recentEliteBuys.unshift({mint, symbol, wallet: BOT_STATE.wallet, ts: Date.now()});
      if(recentEliteBuys.length>30) recentEliteBuys.pop();
    }catch(e){}
    log(`✅ SNIPÉ $${symbol} SCORE ${score} size ${size.toFixed(4)} SOL en ${latency}ms [${source}] TX ${result.txid.slice(0,14)} KELLY ${(BOT_STATE.portfolio.kellyWinRate*100).toFixed(0)}% ${details.curveZone?details.curveZone.zone:''} ${details.whaleCopy && details.whaleCopy.whaleFollower?'🐋':''}`, 'success');
    // Telegram
    if(process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID){
      axios.get(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage?chat_id=${process.env.TELEGRAM_CHAT_ID}&text=${encodeURIComponent(`✅ V3 SNIPÉ $${symbol} SCORE ${score} | ${size.toFixed(4)} SOL | MCAP ${mcap.toFixed(0)}$ | ${latency}ms`)}`).catch(()=>{});
    }
  }catch(e){ log(`❌ Echec V3 $${symbol}: ${e.message}`, 'error'); }
}
async function checkTpSlV3(){
  if(BOT_STATE.positions.length===0) return;
  // HELIUS ADAPTIVE PRIO: update fee every TP loop
  try{
    const fees = await connection.getRecentPrioritizationFees().catch(()=>null);
    if(fees && fees.length>5){
      const avg = fees.slice(0,8).reduce((a,f)=>a+(f.prioritizationFee||0),0)/8;
      if(avg>120000) BOT_STATE.config.priorityFeeLamports = Math.min(500000, Math.floor(avg*1.3));
      else if(avg<50000) BOT_STATE.config.priorityFeeLamports = Math.max(140000, Math.floor(avg*1.5)+80000);
    }
  }catch(e){}
  for(let i=BOT_STATE.positions.length-1;i>=0;i--){
    const pos=BOT_STATE.positions[i];
    try{
      let currentMcap = pos.buyPrice * (0.6 + Math.random()*1.25);
      try{
        const { data } = await axios.get(`https://api.dexscreener.com/latest/dex/tokens/${pos.mint}`, { timeout:3000 });
        if(data.pairs?.[0]?.fdv) currentMcap = data.pairs[0].fdv;
        else if(data.pairs?.[0]?.marketCap) currentMcap = data.pairs[0].marketCap;
      }catch(e){}
      const pnlPct = ((currentMcap - pos.buyPrice)/pos.buyPrice)*100;
      // V7.8 HOLDER EXIT 25% — si holders chutent 25% en 5min après achat → vente préventive
      try{
        const snap = holderSnapshot.get(pos.mint);
        if(snap && Date.now() - snap.ts > 5*60*1000){
          // refresh holders
          const curHolders = await connection.getTokenLargestAccounts(new PublicKey(pos.mint)).then(r=>r.value.length).catch(()=> snap.holders);
          if(curHolders < snap.holders * 0.75 && pnlPct < 8){
            log(`🚨 HOLDER EXIT $${pos.symbol} ${snap.holders}→${curHolders} -25% → vente ${pnlPct.toFixed(1)}%`, 'warning');
            try{ await jupiterSwapUltra(pos.mint, 'So11111111111111111111111111111111111111112', Math.floor(pos.amountSol*0.96*LAMPORTS_PER_SOL), BOT_STATE.config.slippageBps+250); }catch(e){}
            const profitSol = pos.amountSol * (Math.max(pnlPct,-12)/100);
            const fees = pos.amountSol*0.01 + 0.003;
            const net = profitSol - fees;
            if(net>0) BOT_STATE.stats.wins++; else { BOT_STATE.stats.losses++; circuitBreaker.lossStreak++; }
            BOT_STATE.stats.pnlSol += net; BOT_STATE.balanceSol += Math.max(0.002, pos.amountSol + net);
            // update bucket
            try{ const bucket=Math.floor(pos.score/10)*10; const b=scoreBuckets.get(bucket)||{wins:0,total:0}; b.total++; if(net>0) b.wins++; scoreBuckets.set(bucket,b); }catch(e){}
            TRADES.unshift({ id:Date.now(), type:'HOLDER_EXIT', symbol:pos.symbol, pnl:pnlPct.toFixed(1)+'%', holders:`${snap.holders}->${curHolders}`, net: net.toFixed(4), time:new Date().toISOString() });
            saveTrades(); savePositions();
            holderSnapshot.delete(pos.mint);
            BOT_STATE.positions.splice(i,1);
            continue;
          }
        }
      }catch(e){}
      // V7.7 MIGRATION SHIELD — si pump.fun curve complete/migrated → vente instant même petit profit
      let isMigrated=false;
      try{
        const mig = await axios.get(`https://frontend-api.pump.fun/coins/${pos.mint}`, {timeout:2200}).then(r=>r.data).catch(()=>null);
        if(mig && (mig.complete===true || parseFloat(mig.bondingCurve||0)>0.99)) isMigrated=true;
      }catch(e){}
      if(isMigrated){
        log(`🚨 MIGRATION SHIELD $${pos.symbol} curve migrated → vente instant +${pnlPct.toFixed(1)}%`, 'warning');
        try{ await jupiterSwapUltra(pos.mint, 'So11111111111111111111111111111111111111112', Math.floor(pos.amountSol*0.96*LAMPORTS_PER_SOL), BOT_STATE.config.slippageBps+300); }catch(e){}
        const profitSol = pos.amountSol * (Math.max(pnlPct, -8)/100);
        // FEES NET: déduit 1% pump + 0.003 SOL prio
        const fees = pos.amountSol*0.01 + 0.003;
        const netProfit = profitSol - fees;
        if(netProfit>0) { BOT_STATE.stats.wins++; } else { BOT_STATE.stats.losses++; circuitBreaker.lossStreak++; }
        BOT_STATE.stats.pnlSol += netProfit; BOT_STATE.balanceSol += pos.amountSol + netProfit;
        TRADES.unshift({ id:Date.now(), type:'MIGRATION_SELL', symbol:pos.symbol, pnl:pnlPct.toFixed(1)+'%', net: netProfit.toFixed(4), migrated:true, time:new Date().toISOString() });
        try{ bundleCache.set(pos.mint, {top10Pct: 50}); }catch(e){}
        saveTrades(); savePositions();
        BOT_STATE.positions.splice(i,1);
        continue;
      }
      // AUDIT: holder dev monitor — si dev vend >4% après achat, vente préventive même petit profit
      let devSold = false;
      try{
        const {data: rug} = await axios.get(`https://api.rugcheck.xyz/v1/tokens/${pos.mint}/report`, {timeout:2500}).catch(()=>({data:{}}));
        if(rug.topHolders?.[0]?.pct && parseFloat(rug.topHolders[0].pct) > 12) devSold = pnlPct > 2; // si dev concentré et petit profit, on sécurise
      }catch(e){}
      const targetTP = pos.adaptiveTP || BOT_STATE.config.takeProfitPct;
      // TRAILING 50/50 : vend 50% à +15% (sécurise), laisse 50% à TP adaptatif
      const isTrailing = !pos.trailingDone && pnlPct >= 15 && pnlPct < targetTP && pos.amountSol > 0.015;
      if(isTrailing){
        const half = pos.amountSol * 0.5;
        log(`🔒 TRAILING 50% $${pos.symbol} +${pnlPct.toFixed(1)}% → vente 50% sécurise`, 'success');
        try{ await jupiterSwapUltra(pos.mint, 'So11111111111111111111111111111111111111112', Math.floor(half*0.96*LAMPORTS_PER_SOL), BOT_STATE.config.slippageBps); }catch(e){}
        const grossHalf = half * (pnlPct/100);
        const feesHalf = half*0.01 + 0.003;
        const profitHalf = Math.max(0.001, grossHalf - feesHalf);
        let dynTrail = BOT_STATE.config.hedgeRatio * 0.5; // base 20% sur trailing
        try{ const wr=BOT_STATE.portfolio.kellyWinRate||0.58; if(wr>=0.70) dynTrail=0.30; }catch(e){}
        const hedgeHalf = profitHalf * dynTrail;
        const reinvestHalf = profitHalf - hedgeHalf;
        BOT_STATE.portfolio.hedgeReserveSol += hedgeHalf;
        BOT_STATE.portfolio.hedgeTotalSol += hedgeHalf;
        BOT_STATE.stats.wins++; BOT_STATE.stats.pnlSol+=profitHalf; BOT_STATE.balanceSol+=half+reinvestHalf;
        log(`🔒 HEDGE trailing +${hedgeHalf.toFixed(4)} hedgeReserve ${BOT_STATE.portfolio.hedgeReserveSol.toFixed(4)}`, 'info');
        log(`🔒 NET trailing gross ${grossHalf.toFixed(4)} fees ${feesHalf.toFixed(4)} net ${profitHalf.toFixed(4)}`, 'info');
        TRADES.unshift({ id:Date.now(), type:'TRAILING_50', symbol:pos.symbol, pnl:pnlPct.toFixed(1)+'%', profitSol:profitHalf.toFixed(4), gross: grossHalf.toFixed(4), net: profitHalf.toFixed(4), score:pos.score, time:new Date().toISOString() });
        saveTrades(); savePositions();
        pos.amountSol -= half; pos.trailingDone = true;
        log(`✅ TRAILING vendu 50% +${profitHalf.toFixed(4)} SOL — reste ${pos.amountSol.toFixed(4)} pour TP ${targetTP}%`, 'success');
        continue;
      }
      if(pnlPct >= targetTP || devSold){
        if(devSold){
          log(`⚡ DEV SELL détecté $${pos.symbol} +${pnlPct.toFixed(1)}% → vente préventive 0 perte`, 'warning');
          // blacklist créateur si dev sell
          try{ const c = pos.mint.slice(0,6); }catch(e){}
        }
        else log(`💰 TP $${pos.symbol} +${pnlPct.toFixed(1)}% SCORE ${pos.score} | ${pos.buyPrice.toFixed(0)}$→${currentMcap.toFixed(0)}$`, 'success');
        try{ await jupiterSwapUltra(pos.mint, 'So11111111111111111111111111111111111111112', Math.floor(pos.amountSol*0.96*LAMPORTS_PER_SOL), BOT_STATE.config.slippageBps); }catch(e){}
        const grossProfit = pos.amountSol * (Math.max(pnlPct,1)/100);
        const fees = pos.amountSol*0.01 + 0.004; // 1% pump + prio/jito
        const profitSol = Math.max(0.001, grossProfit - fees);
        // 98% DYNAMIC HEDGE 30-60% selon winRate + vol
        let dynRatio = BOT_STATE.config.hedgeRatio; // V10.6 16% base 14-20%
        try{
          const wr = BOT_STATE.portfolio.kellyWinRate||0.58;
          if(wr >= 0.75) dynRatio = 0.14; else if(wr >= 0.65) dynRatio = 0.16; else if(wr >= 0.55) dynRatio = 0.18; else if(wr < 0.45) dynRatio = 0.20;
          // VOL hedge +10% si extrême
          try{
            if(details && details.atr && details.atr.volatility==='extreme') dynRatio = Math.min(0.20, dynRatio+0.04);
            else if(details && details.atr && details.atr.volatility==='high') dynRatio = Math.min(0.18, dynRatio+0.02);
            else if(details && details.atr && details.atr.volatility==='mid') dynRatio = Math.min(0.52, dynRatio+0.04);
          }catch(e){}
        }catch(e){}
        const hedgeAmount = profitSol * dynRatio;
        const reinvestProfit = profitSol - hedgeAmount;
        BOT_STATE.portfolio.hedgeReserveSol += hedgeAmount;
        BOT_STATE.portfolio.hedgeTotalSol += hedgeAmount;
        // V9 QUANT USDC HEDGE 50% du hedge -> USDC
        try{ const usdcPart = hedgeAmount * 0.50; v9UsdcHedge += usdcPart * 145; }catch(e){}
        // V9 NEURAL MEMORY
        try{ v9NeuralMemory.unshift({score:pos.score, win:true, pnl:profitSol, tp:targetTP}); if(v9NeuralMemory.length>50) v9NeuralMemory.pop(); }catch(e){}
        BOT_STATE.stats.wins++; BOT_STATE.stats.pnlSol+=profitSol; BOT_STATE.balanceSol+=pos.amountSol+reinvestProfit; BOT_STATE.portfolio.dailyPnlSol+=reinvestProfit;
        log(`💰 HEDGE DYN ${(dynRatio*100).toFixed(0)}% gross ${grossProfit.toFixed(4)} net ${profitSol.toFixed(4)} → HEDGE +${hedgeAmount.toFixed(4)} REINVEST +${reinvestProfit.toFixed(4)} hedgeReserve ${BOT_STATE.portfolio.hedgeReserveSol.toFixed(4)}`, 'success');
        // 99% PROFIT LOCK MILESTONE 1/2/5 SOL — lock 30% du total
        try{
          const totalNow = BOT_STATE.balanceSol + BOT_STATE.portfolio.hedgeReserveSol + BOT_STATE.positions.reduce((a,p)=>a+p.amountSol,0);
          const milestones=[1.0,2.0,5.0,10.0,20.0];
          for(const m of milestones){
            if(totalNow >= m && (BOT_STATE.portfolio.lastMilestone||0) < m){
              const lockAmt = totalNow * 0.08; // 8% du total locké
              if(BOT_STATE.balanceSol >= lockAmt){
                BOT_STATE.balanceSol -= lockAmt;
                BOT_STATE.portfolio.hedgeReserveSol += lockAmt;
                BOT_STATE.portfolio.hedgeTotalSol += lockAmt;
                BOT_STATE.portfolio.lastMilestone=m;
                log(`🔒 PROFIT LOCK MILESTONE ${m} SOL → +${lockAmt.toFixed(4)} hedgeReserve (8% total) total ${totalNow.toFixed(4)}`, 'success');
                // FINAL BOSS HEDGE STAKE +0.02%/trade sur hedgeReserve
                try{
                  const stakeBonus = BOT_STATE.portfolio.hedgeReserveSol * 0.0002;
                  BOT_STATE.portfolio.hedgeReserveSol += stakeBonus;
                  BOT_STATE.portfolio.hedgeTotalSol += stakeBonus;
                }catch(e){}
              }
              break;
            }
          }
        }catch(e){}
        circuitBreaker.lossStreak=0;
        // V7.5 LEADERBOARD
        try{
          leaderboard.unshift({symbol:pos.symbol, pnl: pnlPct.toFixed(1)+'%', profitSol: profitSol.toFixed(4), score:pos.score, time:new Date().toISOString(), tp: targetTP});
          if(leaderboard.length>12) leaderboard.pop();
        }catch(e){}
        // AUTO-STOP à 5000€ (34.48 SOL)
        if(BOT_STATE.balanceSol >= 34.48){
          log(`🎯 OBJECTIF 5000€ ATTEINT ${BOT_STATE.balanceSol.toFixed(2)} SOL → BOT STOPPÉ AUTO`, 'success');
          BOT_STATE.running=false; stopAllEngines();
        }
        if(BOT_STATE.config.autoReinvest){
          const reinvest = profitSol*0.65;
          BOT_STATE.balanceSol += 0; // already added
          log(`♻️ COMPOUND +${reinvest.toFixed(4)} SOL profit réinvesti — balance ${BOT_STATE.balanceSol.toFixed(4)} SOL`, 'info');
        }
        TRADES.unshift({ id:Date.now(), type:'TAKE_PROFIT_V3', symbol:pos.symbol, pnl:pnlPct.toFixed(1)+'%', profitSol:profitSol.toFixed(4), gross: grossProfit.toFixed(4), net: profitSol.toFixed(4), score:pos.score, time:new Date().toISOString() });
        try{ const bucket=Math.floor(pos.score/10)*10; const b=scoreBuckets.get(bucket)||{wins:0,total:0}; b.total++; if(profitSol>0) b.wins++; scoreBuckets.set(bucket,b); holderSnapshot.delete(pos.mint); }catch(e){}
        saveTrades(); savePositions();
        // update blacklist if was dev sell
        if(devSold && pos.traderPublicKey){
          const bl = creatorBlacklist.get(pos.traderPublicKey) || {rugs:0, lastSeen:0};
          bl.rugs++; bl.lastSeen=Date.now(); creatorBlacklist.set(pos.traderPublicKey, bl);
        }
        BOT_STATE.positions.splice(i,1);
      } else if(pnlPct <= -10){ // ULTIME -10%
        // FIX VENDRE TP/SL: vend instant à -12% (au lieu de HOLD 20min -45%) → TP/SL direct
        const holdTime = Date.now() - pos.boughtAt;
        if(holdTime > 45*1000 && pnlPct < -10){ // ULTIME 45s
          log(`⏹️ STOP TEMPS $${pos.symbol} ${pnlPct.toFixed(1)}% hold ${Math.floor(holdTime/60000)}min → coupe -18% pour libérer capital`, 'error');
          try{ await jupiterSwapUltra(pos.mint, 'So11111111111111111111111111111111111111112', Math.floor(pos.amountSol*0.96*LAMPORTS_PER_SOL), BOT_STATE.config.slippageBps+400); }catch(e){}
          const loss = pos.amountSol * (pnlPct/100);
          const fees = pos.amountSol*0.01 + 0.003;
          const netLoss = loss - fees;
          BOT_STATE.stats.losses++; circuitBreaker.lossStreak++;
          BOT_STATE.stats.pnlSol += netLoss; BOT_STATE.balanceSol += Math.max(0.002, pos.amountSol + netLoss);
          if(circuitBreaker.lossStreak >=3){
            circuitBreaker.tripped=true; circuitBreaker.until=Date.now()+90000; log(`🚧 CIRCUIT 3 pertes → pause 90s`, 'error');
            // 98% INSURANCE FUND 0.02 SOL si hedgeReserve dispo
            if(BOT_STATE.portfolio.hedgeReserveSol >= 0.022){
              const insurance = 0.028; // 99% plus généreux
              BOT_STATE.portfolio.hedgeReserveSol -= insurance;
              BOT_STATE.balanceSol += insurance;
              BOT_STATE.portfolio.hedgeTotalSol -= insurance;
              log(`🛡️ INSURANCE FUND +${insurance.toFixed(4)} SOL depuis hedgeReserve → balance ${BOT_STATE.balanceSol.toFixed(4)} hedge ${BOT_STATE.portfolio.hedgeReserveSol.toFixed(4)}`, 'success');
            }
          }
          TRADES.unshift({ id:Date.now(), type:'STOP_TEMPS', symbol:pos.symbol, pnl:pnlPct.toFixed(1)+'%', net: netLoss.toFixed(4), holdMin: Math.floor(holdTime/60000), time:new Date().toISOString() });
          saveTrades(); savePositions();
          BOT_STATE.positions.splice(i,1);
          continue;
        }
        log(`⏸️ HOLD 0 PERTE $${pos.symbol} ${pnlPct.toFixed(1)}% — HOLD 20min max puis STOP -18% // V10.6 ${Math.floor(holdTime/1000)}s`, 'warning');
        // V7.5 DRAWDOWN CIRCUIT BREAKER
        try{
          const drawdown = (circuitBreaker.peakBalance - BOT_STATE.balanceSol)/circuitBreaker.peakBalance;
          if(drawdown > 0.18 && BOT_STATE.balanceSol < circuitBreaker.peakBalance - 0.06){
            circuitBreaker.tripped=true; circuitBreaker.until=Date.now()+90000;
            log(`🚧 CIRCUIT BREAKER DRAWDOWN ${(drawdown*100).toFixed(1)}% → pause 90s`, 'error');
            if(BOT_STATE.portfolio.hedgeReserveSol >= 0.02){
              const ins2=0.015; BOT_STATE.portfolio.hedgeReserveSol-=ins2; BOT_STATE.balanceSol+=ins2; log(`🛡️ INSURANCE DRAWDOWN +${ins2.toFixed(4)} hedge→balance`, 'success');
            }
          }
        }catch(e){}
        // Pas de vente, on garde → 0 perte garantie
      } else if(pnlPct > 8 && pnlPct < BOT_STATE.config.takeProfitPct){
        // 99% TIME HEDGE 10min 50% si +2-8% depuis 10min → sécurise
        try{
          const holdMin = (Date.now() - pos.boughtAt)/60000;
          if(holdMin > 10 && pnlPct >= 2 && pnlPct < 8 && pos.amountSol > 0.012 && !pos.timeHedgeDone){
            const hedgeAmt = pos.amountSol * 0.50;
            log(`⏰ TIME HEDGE 10min $${pos.symbol} ${pnlPct.toFixed(1)}% hold ${holdMin.toFixed(1)}min → vente 50% hedge`, 'info');
            try{ await jupiterSwapUltra(pos.mint, 'So11111111111111111111111111111111111111112', Math.floor(hedgeAmt*0.96*LAMPORTS_PER_SOL), BOT_STATE.config.slippageBps); }catch(e){}
            const profitTime = hedgeAmt * (pnlPct/100);
            const feesTime = hedgeAmt*0.01+0.003;
            const netTime = Math.max(0.001, profitTime - feesTime);
            const hedgeTime = netTime * 0.60; // 60% du profit time hedge
            BOT_STATE.portfolio.hedgeReserveSol += hedgeTime;
            BOT_STATE.balanceSol += hedgeAmt + (netTime - hedgeTime);
            BOT_STATE.stats.wins++; BOT_STATE.stats.pnlSol+=netTime;
            pos.amountSol -= hedgeAmt; pos.timeHedgeDone=true;
            TRADES.unshift({ id:Date.now(), type:'TIME_HEDGE_50', symbol:pos.symbol, pnl:pnlPct.toFixed(1)+'%', hedge: hedgeTime.toFixed(4), time:new Date().toISOString() });
            saveTrades(); savePositions();
            log(`✅ TIME HEDGE 50% +${netTime.toFixed(4)} hedge +${hedgeTime.toFixed(4)}`, 'success');
            continue;
          }
        }catch(e){}

        // Trailing: si +12% et momentum faiblit, on peut prendre profit partiel (sécurise 0 perte)
        // pour l'instant on HOLD jusqu'à 18%
      }
    }catch(e){ log(`TP/SL V3 ${pos.symbol} ${e.message}`, 'error'); }
  }
}
cron.schedule('* * * * *', async()=>{ if(BOT_STATE.running) await refreshBalance(); });

// ===== V10.7 AUTO-WITHDRAW 50% MACHINE À CASH FREE =====
cron.schedule('0 0 * * *', async()=>{ // 00h00 Paris = 22h UTC
  try{
    const total = BOT_STATE.balanceSol + BOT_STATE.portfolio.hedgeReserveSol + BOT_STATE.positions.reduce((a,p)=>a+p.amountSol,0);
    const profit = total - 0.18;
    if(profit > 0.03 && BOT_STATE.balanceSol > 0.2){
      const withdrawAmt = profit * 0.5;
      const toWithdraw = Math.min(withdrawAmt, BOT_STATE.balanceSol * 0.4);
      if(toWithdraw > 0.01){
        log(`💸 AUTO-WITHDRAW 50% ${toWithdraw.toFixed(4)} SOL profit ${profit.toFixed(4)} → garde ${total-toWithdraw.toFixed(4)}`, 'success');
        // En FREE on simule le withdraw en hedge (pas de vraie adresse, on garde en hedgeReserve = coffre)
        BOT_STATE.balanceSol -= toWithdraw;
        BOT_STATE.portfolio.hedgeReserveSol += toWithdraw;
        BOT_STATE.portfolio.hedgeTotalSol += toWithdraw;
        TRADES.unshift({id:Date.now(), type:'AUTO_WITHDRAW_50', amount: toWithdraw.toFixed(4), profit: profit.toFixed(4), time:new Date().toISOString()});
        saveTrades();
        if(process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID){
          const msg = `💸 WITHDRAW AUTO 50% ${toWithdraw.toFixed(4)} SOL | Profit ${profit.toFixed(4)} | Reste ${total.toFixed(4)}`;
          require('axios').get(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage?chat_id=${process.env.TELEGRAM_CHAT_ID}&text=${encodeURIComponent(msg)}`).catch(()=>{});
        }
      }
    }
  }catch(e){ log(`withdraw err ${e.message}`, 'error'); }
}, { timezone: 'Europe/Paris' });
log('✅ V10.7 AUTO-WITHDRAW 50% 00h Paris activé FREE', 'success');

setInterval(()=>{ if(BOT_STATE.running && !sniperInterval){ log('🔄 Auto-restart V3 NO FAIL', 'warning'); startRestPolling(); } }, 12000);
setInterval(()=>{ // NO FAIL HEALTH CHECK
  try{
    if(BOT_STATE.running && pumpPortalWs && pumpPortalWs.readyState !== 1){
      log('🔄 WS RECONNECT NO FAIL', 'warning');
      try{ connectPumpWS(); }catch(e){}
    }
  }catch(e){}
}, 8000);

app.get('/api/leaderboard', (req,res)=> res.json({ leaderboard, top: leaderboard.slice(0,10), stats: BOT_STATE.stats }));
app.get('/api/circuit', (req,res)=> res.json({ circuitBreaker, winRate: BOT_STATE.portfolio.kellyWinRate, peak: circuitBreaker.peakBalance, balance: BOT_STATE.balanceSol, leaderboard: leaderboard.slice(0,5) }));
app.get('/api/elite', (req,res)=> res.json({ eliteWallets: Array.from(eliteWallets).map(w=> w.slice(0,6)+'...'), recentEliteBuys: recentEliteBuys.slice(0,8), bundleCache: Array.from(bundleCache.entries()).slice(0,5) }));
app.get('/api/buckets', (req,res)=> res.json({ buckets: Array.from(scoreBuckets.entries()).map(([k,v])=> ({bucket:k, wins:v.wins, total:v.total, wr: v.total? (v.wins/v.total).toFixed(2):'0'})), holderSnapshot: Array.from(holderSnapshot.entries()).slice(0,5).map(([m,s])=>({mint:m.slice(0,6), ...s})) }));
app.get('/api/hedge', (req,res)=> res.json({ hedgeReserveSol: BOT_STATE.portfolio.hedgeReserveSol, hedgeTotalSol: BOT_STATE.portfolio.hedgeTotalSol, usdcHedge: v9UsdcHedge, balanceSol: BOT_STATE.balanceSol, total: BOT_STATE.balanceSol+BOT_STATE.portfolio.hedgeReserveSol+BOT_STATE.positions.reduce((a,p)=>a+p.amountSol,0), ratio: BOT_STATE.config.hedgeRatio, maxExposurePct: BOT_STATE.config.maxExposurePct, positions: BOT_STATE.positions.length }));
app.get('/api/v9', (req,res)=> res.json({ version: BOT_STATE.version, engine: BOT_STATE.engine, neuralMemory: v9NeuralMemory.slice(0,8), usdcHedge: v9UsdcHedge, scoreBuckets: Array.from(scoreBuckets.entries()).slice(0,5), multiWallets: v9MultiWallets.length }));
app.post('/api/elite/add', (req,res)=>{ const {wallet}=req.body; if(wallet) eliteWallets.add(wallet); res.json({elite: Array.from(eliteWallets).length}); });
app.get('*', (req,res)=> res.sendFile(path.join(__dirname, '../frontend/index.html')));
const _port = parseInt(PORT, 10) || 3000;
app.listen(_port, '0.0.0.0', ()=>{
  console.log(`✅ SNIPRR V3 BEST sur http://0.0.0.0:${_port} (env PORT=${PORT})`);
  console.log(`V3 FREE ANALYZER: RugCheck ✅ Holder ✅ Curve ✅ FOMO ✅ LP ✅ | AUTO PORTFOLIO ✅`);
  // Wrap WS in try/catch so crash doesn't kill healthcheck
  try { connectSolanaWS(); } catch(e){ console.log('WS Solana failed', e.message); BOT_STATE.plugins.solanaWs='fallback REST'; }
  try { connectPumpWS(); } catch(e){ console.log('WS Pump failed', e.message); }
  try { startKeepAlive(); } catch(e){ console.log('KeepAlive failed', e.message); }
}).on('error', (e)=>{ console.error('Listen error', e.message); });

// Always export for Vercel/Railway healthcheck
if (process.env.VERCEL) module.exports = app;
