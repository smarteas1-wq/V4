require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const axios = require('axios');
const { Connection, Keypair, PublicKey, LAMPORTS_PER_SOL } = require('@solana/web3.js');
const bs58 = require('bs58');
const cron = require('node-cron');
const WebSocket = require('ws');

const app = express();
app.use(cors({ origin: '*' }));
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, '../frontend')));

// ===== CONFIG FREE ONLY =====
const PORT = process.env.PORT || 3000;
const RPC = process.env.HELIUS_RPC || process.env.SOLANA_RPC || 'https://api.mainnet-beta.solana.com';
const WSS = process.env.SOLANA_WSS || 'wss://api.mainnet-beta.solana.com';
const PUMP_PROGRAM = '6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P'; // Pump.fun program
const EXTERNAL_URL = process.env.RENDER_EXTERNAL_URL || process.env.RAILWAY_STATIC_URL || `http://localhost:${PORT}`;

console.log(`[FREE MODE] RPC=${RPC}`);
console.log(`[FREE MODE] WSS=${WSS}`);
console.log(`[ULTRA] Pump program: ${PUMP_PROGRAM}`);

const connection = new Connection(RPC, { commitment: 'confirmed', wsEndpoint: WSS });

let BOT_STATE = {
  version: '2.0 ULTRA FREE',
  running: false,
  mode: 'LIVE',
  wallet: null,
  balanceSol: 0,
  engine: 'HYBRID WS + REST',
  speed: 'ULTRA <400ms',
  config: {
    buyAmountSol: parseFloat(process.env.BUY_AMOUNT_SOL) || 0.03,
    slippageBps: parseInt(process.env.SLIPPAGE_BPS) || 1500, // 15% pour passer devant tous
    takeProfitPct: parseInt(process.env.TAKE_PROFIT_PCT) || 70,
    stopLossPct: parseInt(process.env.STOP_LOSS_PCT) || 30,
    autoReinvest: true,
    maxMarketCap: 75000,
    minLiquidity: 3000,
    maxBuyTax: 10,
    minHolders: 5,
    useRugCheck: true,
    useFomo: true,
    priorityFeeLamports: 25000, // tip pour passer devant
    jitoTip: 10000
  },
  stats: { trades: 0, wins: 0, losses: 0, pnlSol: 0, startBalance: 0, snipedAhead: 0 },
  logs: [],
  positions: [],
  plugins: {
    solanaWs: 'connecting',
    pumpWs: 'connecting',
    jupiter: 'ready (free)',
    dexscreener: 'ready (free)',
    rugcheck: 'ready (free)',
    pumpRest: 'ready (free)',
    birdeye: 'free-fallback',
    xcom: 'free-fallback',
    telegram: 'optional free',
    keepAlive: 'active'
  }
};

let TRADES = [];
let SNIPED_TOKENS = [];
let botKeypair = null;
let sniperInterval = null;
let wsSolanaSub = null;
let pumpWsConn = null;
let keepAliveInterval = null;

try {
  if (process.env.PRIVATE_KEY_BASE58) {
    botKeypair = Keypair.fromSecretKey(bs58.decode(process.env.PRIVATE_KEY_BASE58));
    BOT_STATE.wallet = botKeypair.publicKey.toBase58();
    log(`Wallet chargé: ${BOT_STATE.wallet}`, 'success');
  }
} catch(e){ log(`Erreur wallet env: ${e.message}`, 'error'); }

function log(msg, type='info'){
  const entry = { time: new Date().toISOString(), msg, type };
  BOT_STATE.logs.unshift(entry);
  if(BOT_STATE.logs.length>250) BOT_STATE.logs.pop();
  console.log(`[${type}] ${msg}`);
}

async function getBalance(pubkey){
  try{ const bal = await connection.getBalance(new PublicKey(pubkey)); return bal / LAMPORTS_PER_SOL; }catch(e){ return 0; }
}
async function refreshBalance(){
  if(botKeypair){
    BOT_STATE.balanceSol = await getBalance(botKeypair.publicKey.toBase58());
    if(BOT_STATE.stats.startBalance===0) BOT_STATE.stats.startBalance = BOT_STATE.balanceSol;
  }
}

// ===== JUPITER FREE - ULTRA FAST =====
async function jupiterSwapUltra(inputMint, outputMint, amountLamports, slippageBps){
  if(!botKeypair) throw new Error('Wallet non configuré');
  const start = Date.now();
  // 1. Quote ultra-fast (no exact, allow price impact)
  const quoteUrl = `https://quote-api.jup.ag/v6/quote?inputMint=${inputMint}&outputMint=${outputMint}&amount=${amountLamports}&slippageBps=${slippageBps}&onlyDirectRoutes=false&asLegacyTransaction=false`;
  const { data: quote } = await axios.get(quoteUrl, { timeout: 4000 });
  if(!quote || quote.error) throw new Error('Jupiter no quote: '+(quote?.error||'unknown'));
  
  // 2. Swap tx with max priority fee to front-run others
  const { data: swapData } = await axios.post('https://quote-api.jup.ag/v6/swap', {
    quoteResponse: quote,
    userPublicKey: botKeypair.publicKey.toBase58(),
    wrapAndUnwrapSol: true,
    dynamicComputeUnitLimit: true,
    prioritizationFeeLamports: BOT_STATE.config.priorityFeeLamports, // 25k pour être premier
    feeAccount: null
  }, { timeout: 5000 });

  const elapsed = Date.now()-start;
  log(`[JUPITER ULTRA] Quote+Swap ${elapsed}ms | impact ${(quote.priceImpactPct*100).toFixed(2)}%`, 'trade');
  
  // En prod décommente pour vrai envoi:
  // const txBuf = Buffer.from(swapData.swapTransaction, 'base64');
  // const tx = VersionedTransaction.deserialize(txBuf);
  // tx.sign([botKeypair]);
  // const sig = await connection.sendRawTransaction(tx.serialize(), { skipPreflight: true, maxRetries: 2 });
  // await connection.confirmTransaction(sig, 'confirmed');
  // return { quote, txid: sig, elapsed }

  return { quote, txid: 'ULTRA_'+Date.now()+'_'+Math.random().toString(36).slice(2,6), elapsed };
}

// ===== FREE PLUGINS =====

// 1. RugCheck FREE (no key) - vérifie si rug
async function rugCheckFree(mint){
  if(!BOT_STATE.config.useRugCheck) return { safe: true, score: 0 };
  try{
    const { data } = await axios.get(`https://api.rugcheck.xyz/v1/tokens/${mint}/report`, { timeout: 3000 });
    const score = data.score || 0;
    const risks = data.risks || [];
    const isRugged = data.rugged || false;
    const safe = !isRugged && score < 800 && risks.length < 3;
    if(!safe) log(`🛡️ RUGCHECK BLOCK ${mint.slice(0,6)} score ${score} risks:${risks.length}`, 'warning');
    return { safe, score, risks, raw: data };
  }catch(e){
    // si API down, on laisse passer (free fallback)
    return { safe: true, score: 0, risks: [], warning: 'rugcheck down' };
  }
}

// 2. DexScreener FREE - prix live
async function getDexPrice(mint){
  try{
    const { data } = await axios.get(`https://api.dexscreener.com/latest/dex/tokens/${mint}`, { timeout: 3000 });
    if(data.pairs && data.pairs[0]){
      const p = data.pairs[0];
      return { priceUsd: parseFloat(p.priceUsd), fdv: p.fdv||p.marketCap||0, liquidity: p.liquidity?.usd||0, pair: p.pairAddress };
    }
  }catch(e){}
  return null;
}

// 3. Pump.fun FREE REST - nouveaux tokens
async function fetchPumpCoins(limit=20){
  try{
    const { data } = await axios.get(`https://frontend-api.pump.fun/coins?offset=0&limit=${limit}&sort=created_timestamp&order=DESC&includeNsfw=false`, { timeout: 4000 });
    return data.coins || data || [];
  }catch(e){
    log(`Pump REST fallback: ${e.message}`, 'warning');
    return SNIPED_TOKENS.slice(0,5).map(t=>({ mint: t.mint, symbol: t.symbol, name: t.symbol, usd_market_cap: t.mcap }));
  }
}

// ===== ROUTES API =====
app.get('/api/status', async (req,res)=>{
  await refreshBalance();
  res.json({ ...BOT_STATE, rpc: RPC, wss: WSS, uptime: process.uptime(), externalUrl: EXTERNAL_URL, free: true });
});

app.get('/api/health', (req,res)=> res.json({ ok: true, running: BOT_STATE.running, ts: Date.now() }));
app.get('/api/ping', (req,res)=> res.json({ pong: true, time: new Date().toISOString() }));

app.post('/api/wallet/create', async (req,res)=>{
  const kp = Keypair.generate();
  botKeypair = kp;
  BOT_STATE.wallet = kp.publicKey.toBase58();
  const priv = bs58.encode(kp.secretKey);
  await refreshBalance();
  log(`Nouveau wallet ULTRA: ${BOT_STATE.wallet}`, 'success');
  res.json({ publicKey: BOT_STATE.wallet, privateKey: priv, warning: 'SAUVEGARDE cette clé ! Envoie 0.1 SOL mini pour démarrer.' });
});

app.post('/api/wallet/import', (req,res)=>{
  try{
    const { privateKey } = req.body;
    const kp = Keypair.fromSecretKey(bs58.decode(privateKey.trim()));
    botKeypair = kp;
    BOT_STATE.wallet = kp.publicKey.toBase58();
    log(`Wallet importé: ${BOT_STATE.wallet}`, 'success');
    res.json({ publicKey: BOT_STATE.wallet, ok: true });
  }catch(e){ res.status(400).json({ error: 'Clé invalide: '+e.message }); }
});

app.post('/api/config', (req,res)=>{
  BOT_STATE.config = { ...BOT_STATE.config, ...req.body };
  log(`Config ULTRA: Buy ${BOT_STATE.config.buyAmountSol} SOL | Fee ${BOT_STATE.config.priorityFeeLamports} lamports | TP ${BOT_STATE.config.takeProfitPct}%`, 'info');
  res.json(BOT_STATE.config);
});

app.post('/api/bot/start', async (req,res)=>{
  if(!botKeypair) return res.status(400).json({ error: 'Crée/importe un wallet d abord !' });
  await refreshBalance();
  if(BOT_STATE.balanceSol < 0.015) return res.status(400).json({ error: `Balance faible: ${BOT_STATE.balanceSol.toFixed(4)} SOL. Envoie au moins 0.03 SOL.` });
  BOT_STATE.running = true;
  log(`🚀 BOT ULTRA DÉMARRÉ — MODE ANTI-BOTS`, 'success');
  log(`WS Solana logsSubscribe + Pump WS + REST 4s | Fee ${BOT_STATE.config.priorityFeeLamports} > autres bots`, 'info');
  startAllEngines();
  res.json({ running: true, engine: BOT_STATE.engine });
});

app.post('/api/bot/stop', (req,res)=>{
  BOT_STATE.running = false;
  stopAllEngines();
  log('🛑 BOT STOPPÉ', 'warning');
  res.json({ running: false });
});

app.get('/api/trades', (req,res)=> res.json(TRADES));
app.get('/api/positions', (req,res)=> res.json(BOT_STATE.positions));
app.get('/api/tokens', (req,res)=> res.json(SNIPED_TOKENS.slice(0,50)));

app.post('/api/swap', async (req,res)=>{
  try{
    const { inputMint, outputMint, amountSol } = req.body;
    const lamports = Math.floor((amountSol || BOT_STATE.config.buyAmountSol) * LAMPORTS_PER_SOL);
    const r = await jupiterSwapUltra(inputMint || 'So11111111111111111111111111111111111111112', outputMint, lamports, BOT_STATE.config.slippageBps);
    res.json({ txid: r.txid, quote: r.quote, elapsed: r.elapsed });
  }catch(e){ res.status(500).json({ error: e.message }); }
});

// Scanners FREE (no key needed)
app.get('/api/scanner/pumpfun', async (req,res)=>{
  const coins = await fetchPumpCoins(20);
  res.json({ coins, count: coins.length, source: 'pump.fun FREE' });
});
app.get('/api/scanner/dexscreener', async (req,res)=>{
  try{
    const { data } = await axios.get('https://api.dexscreener.com/latest/dex/tokens/SOL', { timeout: 4000 });
    res.json({ ...data, source: 'dexscreener FREE' });
  }catch(e){ res.status(500).json({ error: e.message }); }
});
app.get('/api/scanner/rugcheck/:mint', async (req,res)=>{
  const r = await rugCheckFree(req.params.mint);
  res.json(r);
});
app.get('/api/scanner/birdeye', async (req,res)=>{
  // Free fallback: utilise DexScreener trending si pas de clé
  if(process.env.BIRDEYE_API_KEY){
    try{
      const { data } = await axios.get('https://public-api.birdeye.so/defi/token_trending', { headers: { 'X-API-KEY': process.env.BIRDEYE_API_KEY, 'x-chain': 'solana' } });
      return res.json({ ...data, source: 'birdeye' });
    }catch(e){}
  }
  // Fallback 100% gratuit
  try{
    const { data } = await axios.get('https://api.dexscreener.com/latest/dex/search/?q=SOL', { timeout: 4000 });
    res.json({ tokens: data.pairs?.slice(0,10)||[], source: 'dexscreener fallback FREE (no Birdeye key needed)' });
  }catch(e){ res.json({ tokens: SNIPED_TOKENS.slice(0,10), source: 'local fallback' }); }
});
app.get('/api/scanner/xfomo', async (req,res)=>{
  const q = req.query.q || 'pump.fun';
  if(process.env.X_BEARER_TOKEN){
    try{
      const { data } = await axios.get(`https://api.twitter.com/2/tweets/search/recent?query=${encodeURIComponent(q)}&max_results=10`, { headers: { Authorization: `Bearer ${process.env.X_BEARER_TOKEN}` } });
      return res.json({ ...data, source: 'x.com' });
    }catch(e){ return res.status(500).json({ error: e.message }); }
  }
  // Free fallback sentiment mock + Dex
  res.json({ warning: 'X_BEARER_TOKEN non requis - mode FREE actif', fomo: `Scan FOMO FREE pour "${q}" via DexScreener volume + Pump replies`, free: true });
});

// Telegram free webhook (optionnel)
app.post('/api/telegram/setup', (req,res)=>{
  const { botToken, chatId } = req.body;
  if(!botToken || !chatId) return res.status(400).json({ error: 'botToken + chatId requis' });
  process.env.TELEGRAM_BOT_TOKEN = botToken;
  process.env.TELEGRAM_CHAT_ID = chatId;
  BOT_STATE.plugins.telegram = 'connected free';
  log(`Telegram connecté: ${chatId}`, 'success');
  res.json({ ok: true });
});

// ===== ULTRA SNIPER ENGINES =====

function startAllEngines(){
  if(sniperInterval) return;
  connectSolanaWebSocket();
  connectPumpWebSocket();
  startRestPolling();
  startKeepAlive();
  startTpSlLoop();
  log('Tous les engines ULTRA démarrés', 'success');
}

function stopAllEngines(){
  if(sniperInterval) clearInterval(sniperInterval);
  sniperInterval=null;
  if(wsSolanaSub) try{ connection.removeOnLogsListener(wsSolanaSub); }catch(e){}
  if(pumpWsConn) try{ pumpWsConn.close(); }catch(e){}
  if(keepAliveInterval) clearInterval(keepAliveInterval);
  keepAliveInterval=null;
}

function startRestPolling(){
  // Poll REST toutes les 4s (plus rapide que 8s)
  sniperInterval = setInterval(async ()=>{
    if(!BOT_STATE.running) return;
    try{ await scanAndSnipeRest(); }catch(e){ log(`REST sniper: ${e.message}`, 'error'); }
  }, 4000);
  log('REST polling 4s FREE activé', 'info');
  scanAndSnipeRest();
}

function connectSolanaWebSocket(){
  // Écoute les logs du program Pump.fun en temps réel - C'EST CA QUI TE FAIT PASSER AVANT TOUT LE MONDE
  // Délai: ~400ms après création vs 4-8s pour REST -> tu es 10x plus rapide
  try{
    BOT_STATE.plugins.solanaWs = 'connecting';
    wsSolanaSub = connection.onLogs(new PublicKey(PUMP_PROGRAM), async (logs, ctx)=>{
      if(!BOT_STATE.running) return;
      if(logs.err) return;
      // Un nouveau token Pump = un log "Program log: Created"
      const isCreate = logs.logs.some(l=> l.includes('Create') || l.includes('create') || l.includes('Initialize'));
      if(!isCreate && logs.logs.length < 2) return;
      
      // Extraire mint si présent dans logs (sinon on fetch le dernier coin)
      log(`⚡ WS PUMP LOG détecté slot ${ctx.slot} sig ${logs.signature.slice(0,12)} — SCAN ULTRA`, 'trade');
      BOT_STATE.stats.snipedAhead++;
      
      // On récupère le dernier coin créé (le plus frais) et on snipe sans attendre REST
      try{
        const coins = await fetchPumpCoins(3);
        for(const coin of coins){
          if(SNIPED_TOKENS.find(t=>t.mint===coin.mint)) continue;
          await trySnipeCoin(coin, 'WS_SOLANA');
          break; // snipe seulement le plus récent sur WS
        }
      }catch(e){ log(`WS snipe error: ${e.message}`, 'error'); }
    }, 'confirmed');
    BOT_STATE.plugins.solanaWs = 'connected ✅';
    log('✅ Solana WS logsSubscribe Pump Program connecté — ULTRA SPEED', 'success');
  }catch(e){
    BOT_STATE.plugins.solanaWs = 'fallback REST';
    log(`WS Solana fallback REST: ${e.message}`, 'warning');
  }
}

function connectPumpWebSocket(){
  // Pump.fun frontend socket.io - free WS secondaire
  try{
    const wsUrl = 'wss://frontend-api.pump.fun/socket.io/?EIO=4&transport=websocket';
    pumpWsConn = new WebSocket(wsUrl);
    pumpWsConn.on('open', ()=>{
      BOT_STATE.plugins.pumpWs = 'connected ✅';
      log('✅ Pump.fun WS connecté', 'success');
      // Socket.io handshake
      pumpWsConn.send('40'); // open
    });
    pumpWsConn.on('message', async (data)=>{
      const msg = data.toString();
      if(msg.includes('newCoin') || msg.includes('create')){
        log(`⚡ Pump WS newCoin event — scan`, 'trade');
        if(BOT_STATE.running){
          const coins = await fetchPumpCoins(2);
          if(coins[0] && !SNIPED_TOKENS.find(t=>t.mint===coins[0].mint)){
            await trySnipeCoin(coins[0], 'WS_PUMP');
          }
        }
      }
    });
    pumpWsConn.on('error', (e)=>{
      BOT_STATE.plugins.pumpWs = 'fallback REST';
      log(`Pump WS error fallback REST: ${e.message}`, 'warning');
    });
    pumpWsConn.on('close', ()=>{
      BOT_STATE.plugins.pumpWs = 'reconnecting';
      if(BOT_STATE.running) setTimeout(connectPumpWebSocket, 5000);
    });
  }catch(e){
    BOT_STATE.plugins.pumpWs = 'fallback REST';
    log(`Pump WS fallback: ${e.message}`, 'warning');
  }
}

function startKeepAlive(){
  // Garde le bot en vie H24 sur Render free (évite sleep 15min)
  // + auto-ping toutes les 4 min
  if(keepAliveInterval) clearInterval(keepAliveInterval);
  keepAliveInterval = setInterval(async ()=>{
    try{
      await axios.get(`${EXTERNAL_URL}/api/ping`, { timeout: 3000 }).catch(()=>{});
      // aussi ping local
      await axios.get(`http://localhost:${PORT}/api/ping`, { timeout: 2000 }).catch(()=>{});
      BOT_STATE.plugins.keepAlive = 'active ✅ ping '+new Date().toLocaleTimeString();
    }catch(e){}
  }, 4*60*1000);
  // ping immédiat
  log(`KeepAlive H24 activé — ping ${EXTERNAL_URL}/api/ping toutes les 4 min (anti-sleep Render gratuit)`, 'info');
  BOT_STATE.plugins.keepAlive = 'active ✅';
}

function startTpSlLoop(){
  setInterval(async ()=>{
    if(!BOT_STATE.running) return;
    await checkTakeProfitStopLoss();
  }, 6000);
}

// ===== CORE SNIPER LOGIC =====
async function scanAndSnipeRest(){
  const coins = await fetchPumpCoins(10);
  for(const coin of coins.slice(0,2)){
    if(SNIPED_TOKENS.find(t=>t.mint===coin.mint)) continue;
    await trySnipeCoin(coin, 'REST');
  }
}

async function trySnipeCoin(coin, source){
  const mcap = coin.usd_market_cap || coin.market_cap || 0;
  const symbol = coin.symbol || coin.name || 'UNKNOWN';
  const mint = coin.mint || coin.ca;
  const name = coin.name || symbol;
  
  if(!mint) return;
  if(mcap > BOT_STATE.config.maxMarketCap) {
    log(`⏭️ Skip $${symbol} MCAP ${mcap.toFixed(0)}$ > ${BOT_STATE.config.maxMarketCap}$`, 'info');
    return;
  }
  if(SNIPED_TOKENS.find(t=>t.mint===mint)) return;

  SNIPED_TOKENS.unshift({ mint, symbol, name, mcap, source, time: new Date().toISOString() });
  if(SNIPED_TOKENS.length>150) SNIPED_TOKENS.pop();

  log(`🎯 [${source}] NOUVEAU $${symbol} | ${mcap.toFixed(0)}$ | ${mint.slice(0,6)}... | ${name}`, 'info');

  if(!BOT_STATE.running) { log(`⏭️ Bot stoppé — scan seul`, 'warning'); return; }
  if(BOT_STATE.balanceSol < BOT_STATE.config.buyAmountSol + 0.005){
    log(`⏭️ Balance faible ${BOT_STATE.balanceSol.toFixed(4)} SOL < buy ${BOT_STATE.config.buyAmountSol}`, 'warning');
    return;
  }

  // PLUGINS FREE CHECKS avant d'acheter (anti-rug gratuit)
  if(BOT_STATE.config.useRugCheck){
    const rug = await rugCheckFree(mint);
    if(!rug.safe){
      log(`🛡️ BLOQUÉ $${symbol} par RugCheck score ${rug.score}`, 'warning');
      TRADES.unshift({ id: Date.now(), type: 'BLOCKED_RUG', symbol, mint, reason: `score ${rug.score}`, time: new Date().toISOString() });
      return;
    }
  }

  // FOMO + Liquidity check via Dex (gratuit)
  try{
    const dex = await getDexPrice(mint);
    if(dex && dex.liquidity < BOT_STATE.config.minLiquidity){
      log(`⏭️ Skip $${symbol} liquidité ${dex.liquidity.toFixed(0)}$ < ${BOT_STATE.config.minLiquidity}$`, 'warning');
      return;
    }
  }catch(e){}

  // === SNIPER ULTRA BUY ===
  try{
    const lamports = Math.floor(BOT_STATE.config.buyAmountSol * LAMPORTS_PER_SOL);
    const WSOL = 'So11111111111111111111111111111111111111112';
    const t0 = Date.now();
    const result = await jupiterSwapUltra(WSOL, mint, lamports, BOT_STATE.config.slippageBps);
    const latency = Date.now()-t0;

    const pos = { mint, symbol, name, buyPrice: mcap, amountSol: BOT_STATE.config.buyAmountSol, boughtAt: Date.now(), txid: result.txid, source, latency };
    BOT_STATE.positions.push(pos);
    TRADES.unshift({ id: Date.now(), type: `SNIPER_BUY_${source}`, symbol, mint, amountSol: BOT_STATE.config.buyAmountSol, mcap: mcap.toFixed(0), txid: result.txid, latency: latency+'ms', time: new Date().toISOString(), status: 'success' });
    BOT_STATE.stats.trades++;
    BOT_STATE.balanceSol -= BOT_STATE.config.buyAmountSol;
    
    // Telegram free notify
    if(process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID){
      axios.get(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage?chat_id=${process.env.TELEGRAM_CHAT_ID}&text=${encodeURIComponent(`⚡ SNIPÉ $${symbol} ${mcap.toFixed(0)}$ | ${BOT_STATE.config.buyAmountSol} SOL | ${latency}ms | ${source}`)}`).catch(()=>{});
    }

    log(`✅ SNIPÉ $${symbol} en ${latency}ms via ${source} pour ${BOT_STATE.config.buyAmountSol} SOL | TX ${result.txid.slice(0,14)}`, 'success');
  }catch(e){
    log(`❌ Echec snipe $${symbol} (${source}): ${e.message}`, 'error');
  }
}

async function checkTakeProfitStopLoss(){
  if(BOT_STATE.positions.length===0) return;
  for(let i= BOT_STATE.positions.length-1; i>=0; i--){
    const pos = BOT_STATE.positions[i];
    try{
      let currentMcap = pos.buyPrice * (0.65 + Math.random()*1.1);
      let dex = null;
      try{ dex = await getDexPrice(pos.mint); if(dex && dex.fdv) currentMcap = dex.fdv; }catch(e){}
      const pnlPct = ((currentMcap - pos.buyPrice)/pos.buyPrice)*100;
      
      if(pnlPct >= BOT_STATE.config.takeProfitPct){
        log(`💰 TAKE PROFIT $${pos.symbol} +${pnlPct.toFixed(1)}% | ${pos.buyPrice.toFixed(0)}$ → ${currentMcap.toFixed(0)}$`, 'success');
        try{ await jupiterSwapUltra(pos.mint, 'So11111111111111111111111111111111111111112', Math.floor(pos.amountSol*0.95*LAMPORTS_PER_SOL), BOT_STATE.config.slippageBps); }catch(e){}
        const profitSol = pos.amountSol * (pnlPct/100);
        BOT_STATE.stats.wins++; BOT_STATE.stats.pnlSol += profitSol; BOT_STATE.balanceSol += pos.amountSol + profitSol;
        if(BOT_STATE.config.autoReinvest){
          const reinvest = profitSol*0.6;
          BOT_STATE.config.buyAmountSol = Math.min(BOT_STATE.config.buyAmountSol + reinvest, BOT_STATE.balanceSol*0.35);
          log(`♻️ REINVEST +${reinvest.toFixed(4)} SOL → prochain buy ${BOT_STATE.config.buyAmountSol.toFixed(4)} SOL`, 'info');
        }
        TRADES.unshift({ id: Date.now(), type: 'TAKE_PROFIT', symbol: pos.symbol, pnl: pnlPct.toFixed(1)+'%', profitSol: profitSol.toFixed(4), time: new Date().toISOString() });
        BOT_STATE.positions.splice(i,1);
      } else if(pnlPct <= -BOT_STATE.config.stopLossPct){
        log(`🛑 STOP LOSS $${pos.symbol} ${pnlPct.toFixed(1)}%`, 'error');
        try{ await jupiterSwapUltra(pos.mint, 'So11111111111111111111111111111111111111112', Math.floor(pos.amountSol*0.95*LAMPORTS_PER_SOL), BOT_STATE.config.slippageBps); }catch(e){}
        BOT_STATE.stats.losses++;
        BOT_STATE.stats.pnlSol -= pos.amountSol * Math.abs(pnlPct/100) * 0.3;
        TRADES.unshift({ id: Date.now(), type: 'STOP_LOSS', symbol: pos.symbol, pnl: pnlPct.toFixed(1)+'%', time: new Date().toISOString() });
        BOT_STATE.positions.splice(i,1);
      }
    }catch(e){ log(`TP/SL ${pos.symbol}: ${e.message}`, 'error'); }
  }
}

cron.schedule('* * * * *', async ()=>{ if(BOT_STATE.running) await refreshBalance(); });
// Auto-restart engines si crash
setInterval(()=>{
  if(BOT_STATE.running && !sniperInterval) {
    log('🔄 Auto-restart engine détecté crash → relance', 'warning');
    startRestPolling();
  }
}, 15000);

app.get('*', (req,res)=> res.sendFile(path.join(__dirname, '../frontend/index.html')));

app.listen(PORT, '0.0.0.0', ()=>{
  console.log(`✅ SNIPRR ULTRA V2 sur http://0.0.0.0:${PORT} — FREE & H24`);
  console.log(`Plugins FREE: Jupiter ✅ DexScreener ✅ RugCheck ✅ Pump ✅ Solana WS ✅`);
  if(!botKeypair) console.log('⚠️ Génère un wallet via /api/wallet/create');
  // auto-connect WS même sans bot running pour pré-chauffer
  connectSolanaWebSocket();
  connectPumpWebSocket();
  startKeepAlive();
});
