// Service Jupiter V6 - swap live extrait pour modularité
const axios = require('axios');
const { VersionedTransaction } = require('@solana/web3.js');

async function getQuote(inputMint, outputMint, amount, slippageBps=1000){
  const url = `https://quote-api.jup.ag/v6/quote?inputMint=${inputMint}&outputMint=${outputMint}&amount=${amount}&slippageBps=${slippageBps}`;
  const { data } = await axios.get(url);
  return data;
}

async function getSwapTransaction(quoteResponse, userPublicKey){
  const { data } = await axios.post('https://quote-api.jup.ag/v6/swap', {
    quoteResponse,
    userPublicKey,
    wrapAndUnwrapSol: true,
    dynamicComputeUnitLimit: true,
    prioritizationFeeLamports: 10000
  });
  return data; // { swapTransaction: base64 }
}

module.exports = { getQuote, getSwapTransaction };
