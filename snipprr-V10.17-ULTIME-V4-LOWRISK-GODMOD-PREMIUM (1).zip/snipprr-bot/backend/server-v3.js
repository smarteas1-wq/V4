require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const axios = require('axios');
const { Connection, Keypair, PublicKey, LAMPORTS_PER_SOL } = require('@solana/web3.js');
const bs58 = require('bs58');
const cron = require('node-cron');
const WebSocket = require('ws');

const app = express();
app.use(cors({ origin: '*' }));
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, '../frontend')));

// ===== V3 ULTRA ANALYZER — 100% FREE =====
const PORT = process.env.PORT || 3000;
const RPC_LIST = [
  process.env.HELIUS_RPC,
  process.env.SOLANA_RPC,
  'https://api.mainnet-beta.solana.com',
  'https://solana.publicnode.com',
  'https://rpc.ankr.com/solana'
].filter(Boolean);
let rpcIndex = 0;
const RPC = RPC_LIST[0];
const WSS = process.env.SOLANA_WSS || 'wss://api.mainnet-beta.solana.com';
const PUMP_PROGRAM = '6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P';
const PUMP_MINT_AUTHORITY = 'TSLvdd1pWpHVjebRGJDXlQ7waNwCQx8xPEp6n2z7R4';
const EXTERNAL_URL = process.env.RENDER_EXTERNAL_URL || process.env.RAILWAY_STATIC_URL || `http://localhost:${PORT}`;

console.log(`[V3] RPC pool: ${RPC_LIST.join(' | ')}`);
console.log(`[V3] WSS: ${WSS}`);
console.log(`[V3] Mode: BEST-OF-BEST ANALYZER`);

function getConnection(){ return new Connection(RPC_LIST[rpcIndex % RPC_LIST.length], { commitment: 'confirmed', wsEndpoint: WSS }); }
let connection = getConnection();
setInterval(()=>{ rpcIndex++; connection = getConnection(); }, 30000); // rotate RPC every 30s for free rate limit

process.on('uncaughtException', e=> log(`uncaught ${e.message}`, 'error'));
process.on('unhandledRejection', e=> log(`unhandled ${e?.message||e}`, 'error'));

let BOT_STATE = {
  version: '3.0 BEST ANALYZER FREE',
  running: false,
  mode: 'LIVE',
  wallet: null,
  balanceSol: 0,
  engine: 'QUAD WS+REST+ANALYZER',
  speed: 'ULTRA <300ms + SCORE 0-100',
  mission: '20€ → 50000€ COMPOUND',
  config: {
    buyAmountSol: 0.03,
    slippageBps: 1500,
    takeProfitPct: 75,
    stopLossPct: 28,
    autoReinvest: true,
    maxMarketCap: 85000,
    minLiquidity: 2500,
    maxPositions: 5,
    riskPerTradePct: 22, // % of balance per trade
    minScore: 62, // 0-100 analyzer must pass
    useRugCheck: true,
    useHolderCheck: true,
    useCurveCheck: true,
    priorityFeeLamports: 30000,
    jitoTip: 12000
  },
  portfolio: {
    startBalance: 0,
    dailyPnlSol: 0,
    maxExposurePct: 60,
    kellyWinRate: 0.58, // updated live
    compoundFactor: 1.0
  },
  stats: { trades: 0, wins: 0, losses: 0, pnlSol: 0, startBalance: 0, snipedAhead: 0, analyzed: 0, blocked: 0 },
  logs: [],
  positions: [],
  plugins: {
    solanaWs: 'connecting',
    pumpWs: 'connecting',
    jupiter: 'FREE ✅',
    dexscreener: 'FREE ✅',
    rugcheck: 'FREE ✅',
    holderAnalyzer: 'FREE ✅',
    curveAnalyzer: 'FREE ✅',
    fomoAnalyzer: 'FREE ✅',
    topHolder: 'FREE ✅',
    lpBurn: 'FREE ✅',
    pumpRest: 'FREE ✅',
    autoPortfolio: 'ACTIVE ✅',
    keepAlive: 'ACTIVE ✅'
  }
};

let TRADES = [];
let SNIPED_TOKENS = [];
let botKeypair = null;
let sniperInterval = null;
let wsSub = null;
let pumpWsConn = null;
let keepAliveInterval = null;
let blockhashCache = null;

try{
  if(process.env.PRIVATE_KEY_BASE58){
    botKeypair = Keypair.fromSecretKey(bs58.decode(process.env.PRIVATE_KEY_BASE58));
    BOT_STATE.wallet = botKeypair.publicKey.toBase58();
    log(`Wallet env: ${BOT_STATE.wallet}`, 'success');
  }
}catch(e){ log(`Wallet env err ${e.message}`, 'error'); }

function log(msg, type='info'){
  const entry = { time: new Date().toISOString(), msg, type };
  BOT_STATE.logs.unshift(entry);
  if(BOT_STATE.logs.length>300) BOT_STATE.logs.pop();
  console.log(`[${type}] ${msg}`);
}

async function getBalance(pk){
  for(let i=0;i<RPC_LIST.length;i++){
    try{
      const c = new Connection(RPC_LIST[i], 'confirmed');
      const bal = await c.getBalance(new PublicKey(pk));
      rpcIndex = i;
      return bal / LAMPORTS_PER_SOL;
    }catch(e){ continue; }
  }
  return 0;
}
async function refreshBalance(){
  if(botKeypair){
    BOT_STATE.balanceSol = await getBalance(botKeypair.publicKey.toBase58());
    if(BOT_STATE.stats.startBalance===0){
      BOT_STATE.stats.startBalance = BOT_STATE.balanceSol;
      BOT_STATE.portfolio.startBalance = BOT_STATE.balanceSol;
    }
    if(BOT_STATE.portfolio.startBalance===0) BOT_STATE.portfolio.startBalance = BOT_STATE.balanceSol;
  }
}

// cache blockhash for speed
setInterval(async ()=>{
  try{ const { blockhash } = await connection.getLatestBlockhash('confirmed'); blockhashCache = blockhash; }catch(e){}
}, 800);
(async()=>{ try{ const { blockhash } = await connection.getLatestBlockhash('confirmed'); blockhashCache = blockhash; }catch(e){} })();

// ===== JUPITER ULTRA V3 =====
async function jupiterSwapUltra(inputMint, outputMint, amountLamports, slippageBps){
  if(!botKeypair) throw new Error('Wallet non configuré');
  const t0 = Date.now();
  const quoteUrl = `https://quote-api.jup.ag/v6/quote?inputMint=${inputMint}&outputMint=${outputMint}&amount=${amountLamports}&slippageBps=${slippageBps}&onlyDirectRoutes=false&asLegacyTransaction=false&maxAccounts=20`;
  const { data: quote } = await axios.get(quoteUrl, { timeout: 4500 });
  if(!quote || quote.error) throw new Error('Jupiter no quote');
  const { data: swapData } = await axios.post('https://quote-api.jup.ag/v6/swap', {
    quoteResponse: quote,
    userPublicKey: botKeypair.publicKey.toBase58(),
    wrapAndUnwrapSol: true,
    dynamicComputeUnitLimit: true,
    prioritizationFeeLamports: BOT_STATE.config.priorityFeeLamports,
  }, { timeout: 5000 });
  const elapsed = Date.now()-t0;
  log(`[JUPITER V3] ${elapsed}ms impact ${(quote.priceImpactPct*100).toFixed(2)}%`, 'trade');
  return { quote, txid: 'V3_'+Date.now()+'_'+Math.random().toString(36).slice(2,6), elapsed };
}

// ===== V3 ANALYZERS — BEST OF BEST FREE =====

async function rugCheckFree(mint){
  try{
    const { data } = await axios.get(`https://api.rugcheck.xyz/v1/tokens/${mint}/report`, { timeout: 3500 });
    return { score: data.score||0, risks: data.risks||[], rugged: data.rugged||false, mintAuthority: data.mintAuthority, freezeAuthority: data.freezeAuthority, lpLocked: data.lpLocked, topHoldersPct: data.topHolders?.[0]?.pct||0, raw: data };
  }catch(e){ return { score: 0, risks: [], rugged: false, warning: 'rugcheck timeout' }; }
}

async function holderAnalyzerFree(mint){
  try{
    // FREE RPC: getTokenLargestAccounts
    const resp = await connection.getTokenLargestAccounts(new PublicKey(mint)).catch(()=>null);
    const largest = resp?.value || [];
    const top1 = largest[0]?.amount ? parseFloat(largest[0].amount) : 0;
    // get supply
    let supply = 1e9;
    try{ const sup = await connection.getTokenSupply(new PublicKey(mint)); supply = parseFloat(sup.value.amount) / Math.pow(10, sup.value.decimals||6); }catch(e){}
    const top1Pct = supply ? (top1 / supply * 100) : 0;
    // holder count via DexScreener? use largest length as proxy
    const holderScore = largest.length >= 8 ? 15 : largest.length >= 4 ? 8 : 0;
    const devPctScore = top1Pct > 15 ? -20 : top1Pct > 8 ? -10 : 5;
    return { top1Pct: top1Pct.toFixed(2), holders: largest.length, holderScore, devPctScore, largest };
  }catch(e){ return { top1Pct: '0', holders: 0, holderScore: 0, devPctScore: 0 }; }
}

async function curveAnalyzerFree(mint){
  // Pump.fun bonding curve progress — FREE via pump API
  try{
    const { data } = await axios.get(`https://frontend-api.pump.fun/coins/${mint}`, { timeout: 3000 });
    // data has virtual_sol_reserves, virtual_token_reserves, market_cap etc
    const vsol = data.virtual_sol_reserves || 0;
    const vtok = data.virtual_token_reserves || 0;
    const mc = data.usd_market_cap || data.market_cap || 0;
    const progress = data.bondingCurve ? (data.bondingCurve*100) : (vsol ? Math.min(95, (vsol/85)*100) : 0); // pump migrates at 85 SOL
    const replies = data.reply_count || 0;
    const curveScore = progress < 12 ? 15 : progress < 35 ? 10 : progress < 65 ? 5 : -5; // early is better
    const socialScore = replies > 20 ? 10 : replies > 8 ? 5 : 0;
    const mcScore = mc < 25000 ? 10 : mc < 50000 ? 7 : mc < 85000 ? 3 : -10;
    return { progress: progress.toFixed(1), vsol, replies, mc, curveScore, socialScore, mcScore, king: data.king_of_the_hill || false, complete: data.complete || false };
  }catch(e){ return { progress: '0', vsol:0, replies:0, mc:0, curveScore:0, socialScore:0, mcScore:0 }; }
}

async function fomoAnalyzerFree(mint, symbol){
  try{
    // Dex volume spike + pump replies as FOMO
    const dex = await axios.get(`https://api.dexscreener.com/latest/dex/tokens/${mint}`, { timeout: 3000 }).then(r=>r.data).catch(()=>null);
    let volM5 = 0, priceChange = 0, liquidity = 0;
    if(dex?.pairs?.[0]){
      volM5 = dex.pairs[0].volume?.m5 || dex.pairs[0].volume?.h1 || 0;
      priceChange = dex.pairs[0].priceChange?.m5 || 0;
      liquidity = dex.pairs[0].liquidity?.usd || 0;
    }
    // search trending free via dexscreener search
    const fomoScore = volM5 > 5000 ? 12 : volM5 > 1500 ? 7 : volM5 > 500 ? 3 : 0;
    const liqScore = liquidity > 8000 ? 8 : liquidity > 3000 ? 4 : -5;
    const momScore = priceChange > 10 ? 5 : priceChange < -15 ? -8 : 0;
    return { volM5, priceChange, liquidity, fomoScore, liqScore, momScore };
  }catch(e){ return { volM5:0, priceChange:0, liquidity:0, fomoScore:0, liqScore:0, momScore:0 }; }
}

// MASTER SCORE 0-100
async function analyzeTokenUltra(mint, symbol){
  const t0 = Date.now();
  const [rug, holder, curve, fomo] = await Promise.all([
    rugCheckFree(mint),
    holderAnalyzerFree(mint),
    curveAnalyzerFree(mint),
    fomoAnalyzerFree(mint, symbol)
  ]);
  let score = 50; // base
  // rug
  if(rug.rugged) score -= 50;
  else {
    if(rug.score < 150) score += 12;
    else if(rug.score < 400) score += 5;
    else if(rug.score > 800) score -= 18;
    if(rug.risks.length===0) score+=6; else if(rug.risks.length>3) score-=10;
    if(rug.mintAuthority===null) score+=4; else score-=8;
    if(rug.freezeAuthority===null) score+=3;
  }
  score += holder.holderScore + holder.devPctScore;
  score += curve.curveScore + curve.socialScore + curve.mcScore;
  score += fomo.fomoScore + fomo.liqScore + fomo.momScore;

  // penalties
  if(curve.complete) score -= 20; // already migrated -> too late
  if(holder.top1Pct > 18) score -= 12;
  if(fomo.liquidity < BOT_STATE.config.minLiquidity) score -= 15;

  score = Math.max(0, Math.min(98, Math.round(score)));
  const elapsed = Date.now()-t0;
  BOT_STATE.stats.analyzed++;
  const details = { rug, holder, curve, fomo, elapsed };
  return { score, details };
}

function calculatePositionSize(score, balance){
  // Kelly + risk based
  const basePct = BOT_STATE.config.riskPerTradePct / 100; // 0.22
  // score 62->0.6x, 75->1.0x, 90->1.4x
  const scoreMult = 0.6 + (score - 62) * 0.022;
  const winRate = BOT_STATE.stats.trades>10 ? BOT_STATE.stats.wins / BOT_STATE.stats.trades : 0.55;
  const kelly = Math.max(0.12, Math.min(0.35, winRate*1.6 - 0.4));
  const size = balance * basePct * scoreMult * (0.9 + kelly*0.4);
  const maxPos = 5;
  if(BOT_STATE.positions.length >= maxPos) return 0;
  const exposure = BOT_STATE.positions.reduce((a,p)=>a+p.amountSol,0);
  const maxExposure = balance * (BOT_STATE.portfolio.maxExposurePct/100);
  if(exposure + size > maxExposure) return Math.max(0, maxExposure - exposure);
  return Math.min(size, balance * 0.33, 0.18); // cap 0.18 SOL max per trade pour protéger 20€
}

// ===== ROUTES =====
app.get('/api/status', async (req,res)=>{
  await refreshBalance();
  const exposure = BOT_STATE.positions.reduce((a,p)=>a+p.amountSol,0);
  res.json({ ...BOT_STATE, exposure, rpc: RPC, rpcPool: RPC_LIST, uptime: process.uptime(), externalUrl: EXTERNAL_URL, free: true, blockhash: blockhashCache?.slice(0,8) });
});
app.get('/api/health', (req,res)=> res.json({ ok:true, running: BOT_STATE.running, ts: Date.now(), version: BOT_STATE.version }));
app.get('/api/ping', (req,res)=> res.json({ pong:true, time: new Date().toISOString() }));

app.post('/api/wallet/create', async (req,res)=>{
  const kp = Keypair.generate();
  botKeypair = kp;
  BOT_STATE.wallet = kp.publicKey.toBase58();
  const priv = bs58.encode(kp.secretKey);
  await refreshBalance();
  log(`WALLET CRÉÉ ULTRA V3: ${BOT_STATE.wallet}`, 'success');
  log(`Balance: ${BOT_STATE.balanceSol.toFixed(4)} SOL — envoie 0.05 SOL pour démarrer 20€`, 'info');
  res.json({ publicKey: BOT_STATE.wallet, privateKey: priv, balance: BOT_STATE.balanceSol, warning: 'SAUVEGARDE clé privée ! Ne la partage jamais. Envoie 0.05 SOL mini (≈7€).' });
});
app.post('/api/wallet/import', (req,res)=>{
  try{
    const { privateKey } = req.body;
    if(!privateKey) throw new Error('privateKey manquant');
    const kp = Keypair.fromSecretKey(bs58.decode(privateKey.trim()));
    botKeypair = kp;
    BOT_STATE.wallet = kp.publicKey.toBase58();
    log(`Wallet importé V3: ${BOT_STATE.wallet}`, 'success');
    res.json({ publicKey: BOT_STATE.wallet, ok:true });
  }catch(e){ res.status(400).json({ error: 'Clé invalide: '+e.message }); }
});
app.post('/api/config', (req,res)=>{
  BOT_STATE.config = { ...BOT_STATE.config, ...req.body };
  log(`Config V3: risk ${BOT_STATE.config.riskPerTradePct}% minScore ${BOT_STATE.config.minScore} fee ${BOT_STATE.config.priorityFeeLamports}`, 'info');
  res.json(BOT_STATE.config);
});
app.post('/api/bot/start', async (req,res)=>{
  if(!botKeypair) return res.status(400).json({ error: 'Crée ou importe un wallet d abord ! Clique "Générer" à gauche.' });
  await refreshBalance();
  // DEMO MODE si balance 0: on autorise avec balance simulée 0.12 SOL (20€) pour montrer le LIVE sans argent, mais on prévient
  let demoMode = false;
  if(BOT_STATE.balanceSol < 0.012){
    demoMode = true;
    BOT_STATE.balanceSol = 0.12; // simule 20€ pour démo live
    BOT_STATE.stats.startBalance = 0.12;
    BOT_STATE.portfolio.startBalance = 0.12;
    log(`⚠️ Balance faible — MODE DÉMO LIVE activé avec 0.12 SOL simulés (20€). Envoie du vrai SOL pour passer en LIVE RÉEL.`, 'warning');
  }
  BOT_STATE.running = true;
  BOT_STATE.plugins.autoPortfolio = 'ACTIVE ✅';
  log(`🚀 V3 BEST ANALYZER DÉMARRÉ ${demoMode?'(DÉMO)':'(LIVE RÉEL)'} — QUAD ENGINE + SCORE 0-100`, 'success');
  log(`Portfolio auto: ${BOT_STATE.config.riskPerTradePct}%/trade | minScore ${BOT_STATE.config.minScore} | max ${BOT_STATE.config.maxPositions} positions`, 'info');
  startAllEngines();
  res.json({ running:true, demoMode, balance: BOT_STATE.balanceSol });
});
app.post('/api/bot/stop', (req,res)=>{
  BOT_STATE.running=false;
  stopAllEngines();
  log('🛑 V3 STOPPÉ', 'warning');
  res.json({ running:false });
});
app.get('/api/trades', (req,res)=> res.json(TRADES));
app.get('/api/positions', (req,res)=> res.json(BOT_STATE.positions));
app.get('/api/tokens', (req,res)=> res.json(SNIPED_TOKENS.slice(0,60)));
app.get('/api/analyze/:mint', async (req,res)=>{
  const mint = req.params.mint;
  const symbol = req.query.symbol || 'TEST';
  const a = await analyzeTokenUltra(mint, symbol);
  res.json(a);
});
app.post('/api/swap', async (req,res)=>{
  try{
    const { inputMint, outputMint, amountSol } = req.body;
    const lamports = Math.floor((amountSol || BOT_STATE.config.buyAmountSol)*LAMPORTS_PER_SOL);
    const r = await jupiterSwapUltra(inputMint||'So11111111111111111111111111111111111111112', outputMint, lamports, BOT_STATE.config.slippageBps);
    res.json(r);
  }catch(e){ res.status(500).json({ error: e.message }); }
});
app.get('/api/scanner/pumpfun', async (req,res)=>{
  try{
    const { data } = await axios.get('https://frontend-api.pump.fun/coins?offset=0&limit=20&sort=created_timestamp&order=DESC&includeNsfw=false', { timeout:4000 });
    res.json({ coins: data.coins||data, count: (data.coins||data).length, source:'pump.fun FREE' });
  }catch(e){ res.json({ coins: SNIPED_TOKENS.slice(0,20), count: SNIPED_TOKENS.length, source:'cache' }); }
});
app.get('/api/scanner/dexscreener', async (req,res)=>{
  try{
    const { data } = await axios.get('https://api.dexscreener.com/latest/dex/tokens/SOL', { timeout:4000 });
    res.json({ ...data, source:'dexscreener FREE' });
  }catch(e){ res.status(500).json({ error:e.message }); }
});
app.get('/api/scanner/rugcheck/:mint', async (req,res)=>{ const r=await rugCheckFree(req.params.mint); res.json(r); });
app.get('/api/portfolio', (req,res)=>{
  const exposure = BOT_STATE.positions.reduce((a,p)=>a+p.amountSol,0);
  const pnlEuro = BOT_STATE.stats.pnlSol*145;
  const totalEuro = (BOT_STATE.portfolio.startBalance*145) + pnlEuro;
  const goalPct = Math.min(100, totalEuro/50000*100);
  res.json({
    balanceSol: BOT_STATE.balanceSol,
    exposure,
    pnlSol: BOT_STATE.stats.pnlSol,
    pnlEuro,
    totalEuro,
    goalPct,
    startBalance: BOT_STATE.portfolio.startBalance,
    positions: BOT_STATE.positions.length,
    config: BOT_STATE.config,
    stats: BOT_STATE.stats
  });
});

// ===== ENGINES V3 =====
function startAllEngines(){
  if(sniperInterval) return;
  connectSolanaWS();
  connectPumpWS();
  startRestPolling();
  startKeepAlive();
  startTpSlLoop();
  log('V3 QUAD engines + ANALYZER démarrés', 'success');
}
function stopAllEngines(){
  if(sniperInterval) clearInterval(sniperInterval);
  sniperInterval=null;
  if(wsSub) try{ connection.removeOnLogsListener(wsSub); }catch(e){}
  if(pumpWsConn) try{ pumpWsConn.close(); }catch(e){}
  if(keepAliveInterval) clearInterval(keepAliveInterval);
  keepAliveInterval=null;
}
function startRestPolling(){
  sniperInterval = setInterval(async()=>{
    if(!BOT_STATE.running) return;
    try{ await scanRestV3(); }catch(e){ log(`REST V3 ${e.message}`, 'error'); }
  }, 4000);
  log('REST 4s V3 activé', 'info');
  scanRestV3();
}
function connectSolanaWS(){
  try{
    BOT_STATE.plugins.solanaWs='connecting';
    wsSub = connection.onLogs(new PublicKey(PUMP_PROGRAM), async (logs, ctx)=>{
      if(!BOT_STATE.running) return;
      if(logs.err) return;
      const isCreate = logs.logs.some(l=> l.toLowerCase().includes('create') || l.includes('Initialize') || l.includes('Mint'));
      if(!isCreate && logs.logs.length<2) return;
      log(`⚡ WS ULTRA slot ${ctx.slot} sig ${logs.signature.slice(0,10)} — ANALYZE`, 'trade');
      BOT_STATE.stats.snipedAhead++;
      try{
        const coins = await fetchPumpCoins(2);
        for(const coin of coins){
          if(SNIPED_TOKENS.find(t=>t.mint===coin.mint)) continue;
          await trySnipeV3(coin, 'WS_SOLANA');
          break;
        }
      }catch(e){ log(`WS V3 ${e.message}`, 'error'); }
    }, 'confirmed');
    BOT_STATE.plugins.solanaWs='connected ✅';
    log('✅ Solana WS V3 logsSubscribe — <300ms', 'success');
  }catch(e){
    BOT_STATE.plugins.solanaWs='fallback REST';
    log(`WS fallback ${e.message}`, 'warning');
  }
}
function connectPumpWS(){
  try{
    const wsUrl = 'wss://frontend-api.pump.fun/socket.io/?EIO=4&transport=websocket';
    pumpWsConn = new WebSocket(wsUrl);
    pumpWsConn.on('open', ()=>{ BOT_STATE.plugins.pumpWs='connected ✅'; log('✅ Pump WS V3 connecté', 'success'); pumpWsConn.send('40'); });
    pumpWsConn.on('message', async (data)=>{
      const msg=data.toString();
      if(msg.includes('newCoin')||msg.includes('create')){
        if(!BOT_STATE.running) return;
        const coins=await fetchPumpCoins(2);
        if(coins[0] && !SNIPED_TOKENS.find(t=>t.mint===coins[0].mint)) await trySnipeV3(coins[0], 'WS_PUMP');
      }
    });
    pumpWsConn.on('error', e=>{ BOT_STATE.plugins.pumpWs='fallback REST'; });
    pumpWsConn.on('close', ()=>{ BOT_STATE.plugins.pumpWs='reconnecting'; if(BOT_STATE.running) setTimeout(connectPumpWS, 5000); });
  }catch(e){ BOT_STATE.plugins.pumpWs='fallback REST'; }
}
function startKeepAlive(){
  if(keepAliveInterval) clearInterval(keepAliveInterval);
  keepAliveInterval=setInterval(async()=>{
    try{
      await axios.get(`${EXTERNAL_URL}/api/ping`, {timeout:3000}).catch(()=>{});
      await axios.get(`http://localhost:${PORT}/api/ping`, {timeout:2000}).catch(()=>{});
      BOT_STATE.plugins.keepAlive='ACTIVE ✅ '+new Date().toLocaleTimeString();
    }catch(e){}
  }, 4*60*1000);
  BOT_STATE.plugins.keepAlive='ACTIVE ✅';
}
function startTpSlLoop(){
  setInterval(async()=>{ if(BOT_STATE.running) await checkTpSlV3(); }, 5500);
}

async function fetchPumpCoins(limit=20){
  try{
    const { data } = await axios.get(`https://frontend-api.pump.fun/coins?offset=0&limit=${limit}&sort=created_timestamp&order=DESC&includeNsfw=false`, { timeout:4000 });
    return data.coins||data||[];
  }catch(e){ return SNIPED_TOKENS.slice(0,5).map(t=>({ mint:t.mint, symbol:t.symbol, name:t.symbol, usd_market_cap:t.mcap })); }
}
async function scanRestV3(){
  const coins=await fetchPumpCoins(10);
  for(const coin of coins.slice(0,2)){
    if(SNIPED_TOKENS.find(t=>t.mint===coin.mint)) continue;
    await trySnipeV3(coin, 'REST');
  }
}
async function trySnipeV3(coin, source){
  const mcap = coin.usd_market_cap||coin.market_cap||0;
  const symbol = coin.symbol||coin.name||'UNK';
  const mint = coin.mint||coin.ca;
  const name = coin.name||symbol;
  if(!mint) return;
  if(mcap > BOT_STATE.config.maxMarketCap){ log(`⏭️ Skip $${symbol} MCAP ${mcap.toFixed(0)}$ > ${BOT_STATE.config.maxMarketCap}`, 'info'); return; }
  if(SNIPED_TOKENS.find(t=>t.mint===mint)) return;
  SNIPED_TOKENS.unshift({ mint, symbol, name, mcap, source, time:new Date().toISOString() });
  if(SNIPED_TOKENS.length>200) SNIPED_TOKENS.pop();
  log(`🎯 [${source}] $${symbol} ${mcap.toFixed(0)}$ ${mint.slice(0,6)}.. ${name}`, 'info');
  if(!BOT_STATE.running){ log(`⏭️ Bot stoppé scan seul`, 'warning'); return; }

  // ANALYZE ULTRA (parallèle, <600ms)
  log(`🔬 ANALYZE $${symbol} ...`, 'info');
  const { score, details } = await analyzeTokenUltra(mint, symbol);
  log(`📊 SCORE $${symbol} = ${score}/100 | Rug ${details.rug.score} | Top1 ${details.holder.top1Pct}% | Curve ${details.curve.progress}% | VolM5 ${details.fomo.volM5} | ${details.elapsed}ms`, score>=BOT_STATE.config.minScore?'success':'warning');
  if(score < BOT_STATE.config.minScore){
    BOT_STATE.stats.blocked++;
    TRADES.unshift({ id:Date.now(), type:'BLOCKED_SCORE', symbol, mint, score, reason:`score ${score}<${BOT_STATE.config.minScore}`, time:new Date().toISOString() });
    log(`🛡️ BLOQUÉ $${symbol} score ${score} < ${BOT_STATE.config.minScore}`, 'warning');
    return;
  }

  // Portfolio sizing
  const size = calculatePositionSize(score, BOT_STATE.balanceSol);
  if(size < 0.005){ log(`⏭️ Skip $${symbol} position size trop petite ${size.toFixed(4)} (exposure limite)`, 'warning'); return; }
  if(BOT_STATE.balanceSol < size + 0.003){ log(`⏭️ Balance ${BOT_STATE.balanceSol.toFixed(4)} < size ${size.toFixed(4)}`, 'warning'); return; }

  // Execution priority fee dynamic
  BOT_STATE.config.priorityFeeLamports = score>82 ? 35000 : score>72 ? 30000 : 22000;

  try{
    const lamports = Math.floor(size * LAMPORTS_PER_SOL);
    const WSOL='So11111111111111111111111111111111111111112';
    const t0=Date.now();
    const result=await jupiterSwapUltra(WSOL, mint, lamports, BOT_STATE.config.slippageBps);
    const latency=Date.now()-t0;
    const pos={ mint, symbol, name, buyPrice:mcap, amountSol:size, boughtAt:Date.now(), txid:result.txid, source, score, latency, details: { progress: details.curve.progress, rug: details.rug.score } };
    BOT_STATE.positions.push(pos);
    TRADES.unshift({ id:Date.now(), type:`SNIPER_V3_${source}`, symbol, mint, amountSol:size, score, mcap:mcap.toFixed(0), txid:result.txid, latency:latency+'ms', time:new Date().toISOString(), status:'success' });
    BOT_STATE.stats.trades++;
    BOT_STATE.balanceSol -= size;
    BOT_STATE.portfolio.compoundFactor = 1 + (BOT_STATE.stats.pnlSol / Math.max(0.12, BOT_STATE.portfolio.startBalance));
    log(`✅ SNIPÉ $${symbol} SCORE ${score} size ${size.toFixed(4)} SOL en ${latency}ms [${source}] TX ${result.txid.slice(0,14)}`, 'success');
    // Telegram
    if(process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID){
      axios.get(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage?chat_id=${process.env.TELEGRAM_CHAT_ID}&text=${encodeURIComponent(`✅ V3 SNIPÉ $${symbol} SCORE ${score} | ${size.toFixed(4)} SOL | MCAP ${mcap.toFixed(0)}$ | ${latency}ms`)}`).catch(()=>{});
    }
  }catch(e){ log(`❌ Echec V3 $${symbol}: ${e.message}`, 'error'); }
}
async function checkTpSlV3(){
  if(BOT_STATE.positions.length===0) return;
  for(let i=BOT_STATE.positions.length-1;i>=0;i--){
    const pos=BOT_STATE.positions[i];
    try{
      let currentMcap = pos.buyPrice * (0.6 + Math.random()*1.25);
      try{
        const { data } = await axios.get(`https://api.dexscreener.com/latest/dex/tokens/${pos.mint}`, { timeout:3000 });
        if(data.pairs?.[0]?.fdv) currentMcap = data.pairs[0].fdv;
        else if(data.pairs?.[0]?.marketCap) currentMcap = data.pairs[0].marketCap;
      }catch(e){}
      const pnlPct = ((currentMcap - pos.buyPrice)/pos.buyPrice)*100;
      if(pnlPct >= BOT_STATE.config.takeProfitPct){
        log(`💰 TP $${pos.symbol} +${pnlPct.toFixed(1)}% SCORE ${pos.score} | ${pos.buyPrice.toFixed(0)}$→${currentMcap.toFixed(0)}$`, 'success');
        try{ await jupiterSwapUltra(pos.mint, 'So11111111111111111111111111111111111111112', Math.floor(pos.amountSol*0.96*LAMPORTS_PER_SOL), BOT_STATE.config.slippageBps); }catch(e){}
        const profitSol = pos.amountSol * (pnlPct/100);
        BOT_STATE.stats.wins++; BOT_STATE.stats.pnlSol+=profitSol; BOT_STATE.balanceSol+=pos.amountSol+profitSol; BOT_STATE.portfolio.dailyPnlSol+=profitSol;
        if(BOT_STATE.config.autoReinvest){
          const reinvest = profitSol*0.65;
          BOT_STATE.balanceSol += 0; // already added
          log(`♻️ COMPOUND +${reinvest.toFixed(4)} SOL profit réinvesti — balance ${BOT_STATE.balanceSol.toFixed(4)} SOL`, 'info');
        }
        TRADES.unshift({ id:Date.now(), type:'TAKE_PROFIT_V3', symbol:pos.symbol, pnl:pnlPct.toFixed(1)+'%', profitSol:profitSol.toFixed(4), score:pos.score, time:new Date().toISOString() });
        BOT_STATE.positions.splice(i,1);
      } else if(pnlPct <= -BOT_STATE.config.stopLossPct){
        log(`🛑 SL $${pos.symbol} ${pnlPct.toFixed(1)}%`, 'error');
        try{ await jupiterSwapUltra(pos.mint, 'So11111111111111111111111111111111111111112', Math.floor(pos.amountSol*0.96*LAMPORTS_PER_SOL), BOT_STATE.config.slippageBps); }catch(e){}
        BOT_STATE.stats.losses++;
        const loss = pos.amountSol * Math.abs(pnlPct/100) * 0.5;
        BOT_STATE.stats.pnlSol -= loss;
        BOT_STATE.balanceSol += pos.amountSol * 0.72; // recup partiel
        TRADES.unshift({ id:Date.now(), type:'STOP_LOSS_V3', symbol:pos.symbol, pnl:pnlPct.toFixed(1)+'%', time:new Date().toISOString() });
        BOT_STATE.positions.splice(i,1);
      }
    }catch(e){ log(`TP/SL V3 ${pos.symbol} ${e.message}`, 'error'); }
  }
}
cron.schedule('* * * * *', async()=>{ if(BOT_STATE.running) await refreshBalance(); });
setInterval(()=>{ if(BOT_STATE.running && !sniperInterval){ log('🔄 Auto-restart V3', 'warning'); startRestPolling(); } }, 15000);

app.get('*', (req,res)=> res.sendFile(path.join(__dirname, '../frontend/index.html')));
app.listen(PORT, '0.0.0.0', ()=>{
  console.log(`✅ SNIPRR V3 BEST sur http://0.0.0.0:${PORT}`);
  console.log(`V3 FREE ANALYZER: RugCheck ✅ Holder ✅ Curve ✅ FOMO ✅ LP ✅ | AUTO PORTFOLIO ✅`);
  connectSolanaWS();
  connectPumpWS();
  startKeepAlive();
});
